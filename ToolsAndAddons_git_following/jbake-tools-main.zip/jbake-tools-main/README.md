# JBake Tools
Addon to simplify the high to lowpoly baking workflow with Blender.

# Installation:
* Download the zip file from github (Green button, Download zip)
* Open Blender >= 2.8x
* Go to Edit -> Preferences -> Click Install button and navigate to the zip file you downloaded
* JBake Tools appears in the addon list -> Activate it (Checkbox)
* JBake panel is now visible in the side bar (N key to open it)
