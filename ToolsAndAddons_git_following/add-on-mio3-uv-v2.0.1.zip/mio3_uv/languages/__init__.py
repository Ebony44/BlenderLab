LANGUAGES_LIST = [
    "ja_JP",
    "zh_HANS",
]
