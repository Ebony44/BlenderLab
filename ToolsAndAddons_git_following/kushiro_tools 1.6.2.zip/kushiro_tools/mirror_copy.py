# ##### BEGIN GPL LICENSE BLOCK #####
#
#  This program is free software; you can redistribute it and/or
#  modify it under the terms of the GNU General Public License
#  as published by the Free Software Foundation; either version 2
#  of the License, or (at your option) any later version.
#
#  This program is distributed in the hope that it will be useful,
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#  GNU General Public License for more details.
#
#  You should have received a copy of the GNU General Public License
#  along with this program; if not, write to the Free Software Foundation,
#  Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301, USA.
#
# ##### END GPL LICENSE BLOCK #####
# Created by Kushiro

import math
from operator import indexOf

import bpy
import bmesh
import bmesh.utils

from mathutils import Matrix, Vector, Quaternion, Euler

import mathutils
import time


import math
from bpy.props import (
    FloatProperty,
    IntProperty,
    BoolProperty,
    EnumProperty,
    FloatVectorProperty,
    StringProperty
)

from pprint import pprint
# from . import gui


def get_face(e):
    fs = []
    for p1 in e.link_loops:
        f1 = p1.face
        a = f1.calc_area()
        fs.append((p1, a))
    if len(fs) == 0:
        return None
    p1, a = max(fs, key=lambda x: x[1])
    return p1



def get_axis(bm, rotation):
    selhistory = bm.select_history
    hedges = [e for e in selhistory if isinstance(e, bmesh.types.BMEdge)]
    if len(hedges) == 0:
        return None, None, None
    e0 = hedges[-1]
    p1 = get_face(e0)
    if p1 is None:
        return None, None, None
    a = p1.vert
    b = p1.edge.other_vert(a)
    flast = p1.face    
    m1 = b.co - a.co
    m1.normalize()
    sn = flast.normal
    m3 = m1.cross(sn)    
    m3.normalize()
    center = a.co
    mat = Matrix([m1, m3, sn]).transposed()

    rot1 = math.radians(rotation)
    qua = Quaternion(Vector((1,0,0)), rot1).to_matrix()
    return mat, center, qua


def copy1(bm, rotation, merge, merge_dis, re_normal):
    mat, center, qua = get_axis(bm, rotation)
    if mat is None:
        return True
    # use api to duplicate selected geometry    
    bm.select_flush(True)
    vs = [v for v in bm.verts if v.select]
    es = [e for e in bm.edges if e.select]
    fs = [f for f in bm.faces if f.select]

    fs_other = [f for f in bm.faces if not f.select]

    geom = vs + es + fs    
    res = bmesh.ops.duplicate(bm, geom=geom)
    vs2 = [v for v in res['geom'] if isinstance(v, bmesh.types.BMVert)]
    mat2 = mat.inverted()    

    for v1 in vs2:
        co = mat2 @ (v1.co - center)
        co.y = co.y * -1
        co = qua @ co
        v1.co = mat @ co + center

    bm.normal_update()

    if merge:
        vs3 = vs + vs2
        bmesh.ops.remove_doubles(bm, verts=vs3, dist=merge_dis)        
    
    if re_normal:
        gfs = [f for f in bm.faces if f not in fs_other]
        bmesh.ops.recalc_face_normals(bm, faces=gfs)



class MirrorCopyOperator(bpy.types.Operator):
    """Tooltip"""
    bl_idname = "mesh.mirror_copy_operator"
    bl_label = "Mirror Copy"
    bl_options = {"REGISTER", "UNDO"}
    #, "GRAB_CURSOR", "BLOCKING"


    prop_plen: FloatProperty(
        name="Rotation",
        description="Rotation around the axis edge",
        default=0.0,
        step=20,
    )    

    prop_merge: BoolProperty(
        name="Merge verts",
        description="Merge the vertices",
        default=True,
    )    

    prop_dis: FloatProperty(
        name="Merge distance",
        description="Merge distance",
        default=0.0001,
        step=0.2,
    )    

    prop_normal: BoolProperty(
        name="Recalc normals",
        description="Recalculate normals",
        default=True,
    )    


    def draw(self, context):
        layout = self.layout
        layout.prop(self, "prop_plen")
        layout.prop(self, "prop_normal")
        layout.separator()
        layout.prop(self, "prop_merge")
        layout.prop(self, "prop_dis")
        
        


    def get_bm(self):
        obj = bpy.context.active_object
        me = obj.data
        bm = bmesh.from_edit_mesh(me)
        return bm

      

    def process(self, context):
        bm = self.get_bm() 

        ret = copy1(bm, self.prop_plen, self.prop_merge, self.prop_dis, self.prop_normal)
        if ret:
            self.report({'ERROR'}, "There is no 'axis' edge in selection history ! \nYou can set axis edge by : Hold Shift key to de-select an edge then re-select it.")

        obj = bpy.context.active_object                
        me = bpy.context.active_object.data
        bmesh.update_edit_mesh(me)  


    def execute(self, context):
        self.process(context)      
        return {'FINISHED'}    

    
    @classmethod
    def poll(cls, context):
        active_object = context.active_object
        selecting = active_object is not None and active_object.type == 'MESH'        
        editing = context.mode == 'EDIT_MESH' 
        is_vert_mode, is_edge_mode, is_face_mode = context.tool_settings.mesh_select_mode
        return selecting and editing 


    def invoke(self, context, event): 
        self.prop_plen = 0                    
                
        if context.edit_object:
            self.process(context)
            return {'FINISHED'} 
        else:
            return {'CANCELLED'}





