# ##### BEGIN GPL LICENSE BLOCK #####
#
#  This program is free software; you can redistribute it and/or
#  modify it under the terms of the GNU General Public License
#  as published by the Free Software Foundation; either version 2
#  of the License, or (at your option) any later version.
#
#  This program is distributed in the hope that it will be useful,
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#  GNU General Public License for more details.
#
#  You should have received a copy of the GNU General Public License
#  along with this program; if not, write to the Free Software Foundation,
#  Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301, USA.
#
# ##### END GPL LICENSE BLOCK #####
# Created by Kushiro

import math
from operator import indexOf

import bpy
import bmesh
import bmesh.utils

from mathutils import Matrix, Vector, Quaternion, Euler

import mathutils
import time


import math
from bpy.props import (
    FloatProperty,
    IntProperty,
    BoolProperty,
    EnumProperty,
    FloatVectorProperty,
    StringProperty
)

from pprint import pprint
# from . import gui

import itertools
import numpy as np


def get_end(vs, es):
    ends = []
    for v in vs:
        linke = [e for e in v.link_edges if e in es]
        if len(linke) == 1:
            ends.append(v)
    return ends            

def get_path(v, es):
    path = []
    v1 = v
    added_edges = []
    while True:
        if v1 in path:
            break
        path.append(v1)
        linke = [e for e in v1.link_edges if (e in es) and (e not in added_edges)]        
        if len(linke) == 0:
            break
        e = linke[0]
        added_edges.append(e)
        v1 = e.other_vert(v1)
    return path


def get_vs(es):
    vs = []
    for e in es:
        vs.append(e.verts[0])
        vs.append(e.verts[1])
    return list(set(vs))


def get_ve(v1, es):
    es2 = [e for e in v1.link_edges if e in es]
    return es2

def get_angle(v1, e1, e2):
    v2 = e1.other_vert(v1)
    v3 = e2.other_vert(v1)
    v1v2 = v2.co - v1.co
    v1v3 = v3.co - v1.co
    angle = v1v2.angle(v1v3)
    return angle


def split_path(path, es, offset):
    ds = []
    for i, v in enumerate(path):
        elink = get_ve(v, es)
        if len(elink) != 2:
            continue
        deg = get_angle(v, elink[0], elink[1])
        ds.append((deg, i))

    ds = sorted(ds, key=lambda x: x[0])

    # shift array to left
    ds = ds[offset:] + ds[:offset]

    d1, d2, d3 = ds[0][1], ds[1][1], ds[2][1]
    d1, d2, d3 = sorted([d1, d2, d3])
    # print(d1, d2, d3)
    ps1 = path[d1:d2+1]
    ps2 = path[d2:d3+1]
    ps3 = path[d3:] + path[:d1+1]
    return [ps1, ps2, ps3]
    


def split_path_two(path, es):
    ds = []
    for i, v in enumerate(path):
        elink = get_ve(v, es)
        if len(elink) != 2:
            continue
        deg = get_angle(v, elink[0], elink[1])
        ds.append((deg, i))

    ds = sorted(ds, key=lambda x: x[0])
    d1 = ds[0][1]
    
    # print(d1, d2, d3)
    ps1 = path[:d1+1]
    ps2 = path[d1:]
    return [ps1, ps2]



def vs_select(bm, vs):
    for v in bm.verts:
        v.select = False
    for v in vs:
        v.select = True


def get_paxis(ps1, ps2):
    m1 = ps1[1].co - ps1[0].co
    m2 = ps2[1].co - ps2[0].co
    m1 = m1.normalized() 
    m2 = m2.normalized() * -1
    m3 = m2.cross(m1).normalized()
    return m3



def get_near_point(segments):
    P_sum = np.zeros((3, 3))
    b_sum = np.zeros(3)
    for segment in segments:
        p0 = segment[0]
        p1 = segment[1]
        d_i = p1 - p0
        norm_d_i = np.linalg.norm(d_i)
        if norm_d_i == 0.0:            
            continue
        d_i_norm = d_i / norm_d_i
        P_i = np.eye(3) - np.outer(d_i_norm, d_i_norm)
        P_sum += P_i
        b_sum += P_i @ p0

    cond_number = np.linalg.cond(P_sum)
    if cond_number > 1e12:        
        return None
    try:
        x = np.linalg.solve(P_sum, b_sum)
        return Vector(x)
    except np.linalg.LinAlgError:        
        return None
    

def calc_arrow_center(ps1, ps2, ps3, pcen):
    if len(ps1) % 2 != 1 or len(ps2) % 2 != 1 or len(ps3) % 2 != 1:
        return None
    mid1 = len(ps1)//2
    mid2 = len(ps2)//2
    mid3 = len(ps3)//2
    mp1 = ps1[mid1].co
    mp2 = ps2[mid2].co
    mp3 = ps3[mid3].co
    cen = (mp1 + mp2 + mp3) / 3
    mc1 = mp1 - pcen
    mc2 = mp2 - pcen
    mc3 = mp3 - pcen
    mg = (mc1.length + mc2.length + mc3.length) / 3
    res = (cen - pcen).normalized() * mg
    return res




def get_sharing(v1, pps):
    a = None
    b = None
    for ps in pps:
        if v1 == ps[0]:
            b = ps
        if v1 == ps[-1]:
            a = ps
    return [a, b]
            

def halflist(ps):
    return ps[:len(ps)//2 + 1]


def divide_path(bm, p1, p2, ct):
    m1 = p2 - p1
    m2 = m1 / (ct-1)
    ps = []
    for i in range(ct):
        if i == 0 or i == ct - 1:
            continue
        p = p1 + m2 * i
        ps.append( bm.verts.new(p) )
    return ps

def divide_edges(bm, pmids, k1, k2):    
    pmid_tmp = [k1] + pmids + [k2]
    for a, b in zip(pmid_tmp[:-1], pmid_tmp[1:]):
        e1 = bm.edges.new([a, b])   


def fill_verts(bm, acen, ps1, ps2):
    last2 = ps2[-1]
    pmids = divide_path(bm, last2.co, acen.co, len(ps1))    

    ct = len(ps1)
    pmid_ss = []
    
    for a, b in zip(ps1[1:-1], pmids):
        mids3 = divide_path(bm, a.co, b.co, ct)
        pmid_ss.append(mids3)

    return (pmids, pmid_ss)



def cs_edge(bm, cs):    
    for a, b in zip(cs[:-1], cs[1:]):        
        v1 = bm.edges.new([a, b])        


def make_edges(bm, cs1, cs2, acen):
    ((pmids, pmid_ss), ps1, ps2) = cs1
    ((pmids2, pmid_ss2), ps3, ps4) = cs2

    cs_edge(bm, [ps2[-1]] + pmids + [acen])
    
    for s1, v1, pm in zip(pmid_ss, ps1[1:-1], pmids):
        cs_edge(bm, [v1] + s1 + [pm])

    ss = [ps4[1:]] + pmid_ss2 + [pmids] 

    for a, b in zip(ss[:-1], ss[1:]):
        for a1, b1 in zip(a, b):
            bm.edges.new([a1, b1])  

    return pmid_ss + [pmids]



def set_distance(p, pcen, plen):
    m1 = p.co - pcen
    m1.normalize()
    m1 = m1 * plen
    p.co = pcen + m1


def adjust_height(tx2, arrow):
    for step in range(100):
        pmap = {}
        for p in tx2:
            es = p.link_edges
            # if len(es) != 4:
            #     continue
            cen = Vector((0, 0, 0))
            for e in es:
                cen += e.other_vert(p).co
            cen = cen / len(es)
            pmap[p] = cen
        
        for p in pmap:
            p.co = pmap[p] * 0.1 + p.co * 0.9



def curve_core(u, k, i, t):
    if k == 0:
        return np.where((u[i] <= t) & (t <= u[i+1]), 1.0, 0.0)
    else:
        denom1 = u[i+k] - u[i]
        denom2 = u[i+k+1] - u[i+1]
        term1 = np.zeros_like(t, dtype=np.float64)
        term2 = np.zeros_like(t, dtype=np.float64)
        if denom1 > 0:
            term1 = ((t - u[i]) / denom1) * curve_core(u, k-1, i, t)
        if denom2 > 0:
            term2 = ((u[i+k+1] - t) / denom2) * curve_core(u, k-1, i+1, t)
        return term1 + term2


def curve(control_points, degree, t_values):
    n = len(control_points) - 1
    U = np.concatenate((
        np.zeros(degree),
        np.linspace(0, 1, n - degree + 2),
        np.ones(degree)
    ))
    locations = np.zeros((len(t_values), 3))
    N_all = np.zeros((len(t_values), n + 1))
    for i in range(n + 1):
        N_all[:, i] = curve_core(U, degree, i, t_values)
    for idx in range(len(t_values)):
        result_location = np.zeros(3)
        for i in range(n + 1):
            result_location += N_all[idx, i] * control_points[i]
        locations[idx] = result_location
    return locations




def find_control_point(P0, P2, curve_points, degree):
    n = 2
    U = np.concatenate((
        np.zeros(degree),
        np.linspace(0, 1, n - degree + 2),
        np.ones(degree)
    ))
    t_values = np.linspace(U[degree], U[-degree-1], len(curve_points))
    N_all = np.zeros((len(t_values), n + 1))
    for i in range(n + 1):
        N_all[:, i] = curve_core(U, degree, i, t_values)

    B = curve_points - (N_all[:, 0:1] * P0) - (N_all[:, 2:3] * P2)
    N1 = N_all[:, 1:2]  

    P1 = np.zeros(3)
    for dim in range(3):
        B_dim = B[:, dim]
        N1_dim = N1[:, 0]
        N1_matrix = N1_dim.reshape(-1, 1)
        P1_dim, residuals, rank, s = np.linalg.lstsq(N1_matrix, B_dim, rcond=None)
        P1[dim] = P1_dim[0]
    
    return P1


def get_re_pcen(ps):
    # p1 = s1a[0].co
    # p3 = s1a[-1].co
    # ps = [a.co[:] for a in s1a]
    ps = np.array(ps)
    p1 = ps[0]
    p3 = ps[-1]
    p2 = find_control_point(p1, p3, ps, 2)
    return Vector(p2)


# def plotline(cp):
#     cp = np.array(cp)
#     # ts = np.array([0.25, 0.75])
#     ts = np.linspace(0, 1, 20)
#     curve_points = curve(cp, 2, ts)
#     for p in curve_points:
#         # bm.verts.new(p)
#         draw_point(p)  


def get_plot(cp, ts):
    cp = np.array(cp)
    # ts = np.array([0.25, 0.75])
    curve_points = curve(cp, 2, ts)
    return curve_points


def get_uncap(vs1, vs2, remap):
    s1a, s1b = vs1
    cap1 = remap[s1a[0]]
    cap2 = remap[s1b[0]]
    v1 = s1b[0]
    k1 = v1.co + (cap1 - v1.co) + (cap2 - v1.co)
    s2a, s2b = vs2
    cap3 = remap[s2b[0]]
    capt = remap[s2a[0]]
    v2 = s2b[0]
    k2 = v2.co + (cap3 - v2.co) + (capt - v2.co)    
    km = (k1 + k2) / 2
    cp = [cap2, km, cap3]
    cp = np.array(cp)
    ts = np.array([0.5])
    curve_points = curve(cp, 2, ts)
    mk1 = curve_points[0]
    return Vector(mk1)


def get_mid_line(vs1, vs2, cen):
    s1a, s1b = vs1
    s2a, s2b = vs2
    mp2 = s2b[len(s2b)//2].co
    # draw_point(mp2)
    v1 = s1b[0]
    # plotline([v1.co, cen, mp2])
    ts = np.linspace(0.5, 1, len(s1b)//2 + 1)
    pp = get_plot([v1.co, cen, mp2], ts)    
    return pp


# def slice_cap(bm, cen, vs1, vs2):
#     pp1 = get_mid_line(vs1, vs2, cen)
#     s1a, s1b = vs1
#     s2a, s2b = vs2
#     ct = len(s1a)//2
#     mss = []
#     vss = set()
#     # draw_point(s1a[0].co)
#     for a, b, c in zip(s2a[ct+1:-1], pp1[1:-1], reversed(s1a[1:ct])):
#         kp = get_re_pcen([a.co, b, c.co])
#         mids = get_plot([a.co, kp, c.co], np.linspace(0, 1, len(s1a)))
#         # mss.append(mids)
#         row = []
#         for p in mids[1:ct+1]:
#             # draw_point(p)
#             v1 = bm.verts.new(p)
#             row.append(v1)
#             vss.add(v1)
#         mss.append(row)
#         for a, b in zip(row[:-1], row[1:]):
#             e1 = bm.edges.new([a, b])            

#     for a, b in zip(mss[1:], mss[:-1]):
#         for a1, b1 in zip(a, b):
#             bm.edges.new([a1, b1])
    
#     for a, b in zip(mss, s2a[ct+1:-1]):
#         bm.edges.new([a[0], b])

#     if len(mss) > 0:
#         for a, b in zip(s2b[1:ct+1], mss[-1]):
#             bm.edges.new([a, b])

#     return mss, pp1[0], vss


def make_lines(bm, pp):
    vs = []
    for p in pp:
        v = bm.verts.new(p)    
        vs.append(v)
    for a, b in zip(vs[:-1], vs[1:]):
        e1 = bm.edges.new([a, b])
        e1.select = True


def make_point(bm, p):
    make_lines(bm, [p + Vector((0.1, 0, 0)), p - Vector((0.1, 0, 0))])
    make_lines(bm, [p + Vector((0, 0.1, 0)), p - Vector((0, 0.1, 0))])


def slice_cap(bm, cen, vs1, vs2):
    pp1 = get_mid_line(vs1, vs2, cen)
    s1a, s1b = vs1
    s2a, s2b = vs2
    ct = len(s1a)//2
    mss = []
    vss = set()

    # make_lines(bm, [Vector((10, 10, 10)), s1b[0].co])
    # make_lines(bm, [Vector((10, 10, 10)), s2b[0].co])
    
    avg_block = []
    # draw_point(s1a[0].co)
    for a, b, c in zip(s2a[ct+1:-1], pp1[1:-1], reversed(s1a[1:ct])):
        kp = get_re_pcen([a.co, b, c.co])
        mids = get_plot([a.co, kp, c.co], np.linspace(0, 1, len(s1a)))
        # mss.append(mids)
        row = []
        avg_row = []
        # for i, p in enumerate(mids[1:ct+1]):
        for i, p in enumerate(mids[1:-1]):
            if i < ct:
                v1 = bm.verts.new(p)
                row.append(v1)
                vss.add(v1)
                # make_lines(bm, [Vector((10, 10, 10)), v1.co])
            else:             
                avg_row.append(p)

        mss.append(row)
        avg_block.append(avg_row)

        for a, b in zip(row[:-1], row[1:]):
            e1 = bm.edges.new([a, b])            

    for a, b in zip(mss[1:], mss[:-1]):
        for a1, b1 in zip(a, b):
            bm.edges.new([a1, b1])
    
    for a, b in zip(mss, s2a[ct+1:-1]):
        bm.edges.new([a[0], b])

    if len(mss) > 0:
        for a, b in zip(s2b[1:ct+1], mss[-1]):
            bm.edges.new([a, b])

    return mss, pp1[0], vss, avg_block  


def merge_block(bm, ms1, ms2, avg1, avg2):
    mk1 = np.array(ms1, dtype=object)
    mk2 = np.array(ms2, dtype=object)
    elen = len(ms1)
    mk1 = mk1[:, :elen]
    mk2 = mk2[:, :elen]

    mk1 = mk1.T[::-1]
    mk2 = mk2.T[::-1]
    ak1 = np.array(avg1, dtype=object)
    ak2 = np.array(avg2, dtype=object)
    mk1 = mk1.flatten()
    mk2 = mk2.flatten()
    ak1 = ak1.reshape(-1, 3)
    ak2 = ak2.reshape(-1, 3)    

    for a, b in zip(ak1, mk2):
        a = Vector(a)
        b.co = (b.co + a) / 2
        
    


def ms_merge(bm, ms1, ms2, cen):
    if len(ms1) == 0 or len(ms2) == 0:
        return
    for i in range(len(ms1)):
        v1 = ms1[-1-i][-1]
        v2 = ms2[0][i]
        bm.edges.new([v1, v2])
    k1 = ms1[0][-1]
    bm.edges.new([k1, cen])

    for a, b in zip(ms1[:-1], ms1[1:]):
        for a1, a2, b1, b2 in zip(a[:-1], a[1:], b[:-1], b[1:]):
            # p = [a1, a2, b2, b1]
            p = [b1, b2, a2, a1]
            f1 = bm.faces.new(p)
            f1.select = True

    for i in range(len(ms1)-1):
        v1 = ms1[-1-i][-1]
        v2 = ms2[0][i]
        k = i + 1
        v3 = ms1[-1-k][-1]
        v4 = ms2[0][k]        
        f1 = bm.faces.new([v1, v2, v4, v3])
        f1.select = True




def fill_fs(bm, pss, vss, ms1, ms2, cen):
    for a, b in zip(pss[1:-1], pss[2:]):
        ps = a.link_edges
        c = None
        d = None
        for p in ps:
            v2 = p.other_vert(a)
            if v2 in vss:
                c = v2
                break
        ps2 = b.link_edges
        for p in ps2:
            v2 = p.other_vert(b)
            if v2 in vss:
                d = v2
                break
        # bound
        if c is not None and d is not None:
            # f1 = bm.faces.new([a, c, d, b])
            f1 = bm.faces.new([b, d, c, a])
            f1.select = True

    a = pss[0]
    b = pss[1]
    c = None
    d = None
    ps = b.link_edges
    for p in ps:
        v2 = p.other_vert(b)
        if v2 in vss:
            c = v2
            break
    if c is not None:
        ps = c.link_edges
        for p in ps:
            v2 = p.other_vert(c)
            if v2 not in vss:
                if v2 != a:
                    d = v2
                    break
        if d is not None:
            # f1 = bm.faces.new([a, d, c, b])
            f1 = bm.faces.new([b, c, d, a])
            f1.select = True

    if len(ms1) == 0 or len(ms2) == 0:
        return        
    else:
        fc1 = [ms1[0][-1], cen, ms2[0][-1], ms1[0][-2]]
        f1 = bm.faces.new(fc1)
        f1.select = True


def small_fill(bm, ps1, ps2, cen):
    v1 = ps1[0]
    v2 = ps1[1]
    v3 = ps2[1]
    f1 = bm.faces.new([v1, v3, cen, v2])
    f1.select = True


def slicing(bm, self, ps1, ps2, ps3):
    v1 = ps1[0]
    v2 = ps2[0]
    v3 = ps3[0]
    pall = [ps1, ps2, ps3]
    vs1 = get_sharing(v1, pall)
    vs2 = get_sharing(v2, pall)
    vs3 = get_sharing(v3, pall)

    if None in vs1 or None in vs2 or None in vs3:
        self.report({'ERROR'}, 'Input parsing error')
        return

    # vs3 = [vs3[1], vs3[0]]
    # pc2 = get_re_pcen(ps1, ps2, ps3, pcen)
    # uncap(vs1, vs2, vs3, pcen, acen)

    remap = {}
    for ps in [ps1, ps2, ps3]:
        co = [p.co[:] for p in ps]
        re = get_re_pcen(co)
        remap[ps[0]] = re

    cap1 = get_uncap(vs1, vs2, remap)
    cap2 = get_uncap(vs2, vs3, remap)
    cap3 = get_uncap(vs3, vs1, remap)
    cap = (cap1 + cap2 + cap3) / 3
    
    ms1,cen1,vss1,avg1 = slice_cap(bm, cap, vs1, vs2)
    ms2,cen2,vss2,avg2 = slice_cap(bm, cap, vs2, vs3)
    ms3,cen3,vss3,avg3 = slice_cap(bm, cap, vs3, vs1)

    cen = (cen1 + cen2 + cen3) / 3
    cen = bm.verts.new(cen)

    vss = vss1 | vss2 | vss3

    vss = list(vss)
    if len(ps1) == 3 or len(ps2) == 3 or len(ps3) == 3:
        small_fill(bm, ps1, ps3, cen)
        small_fill(bm, ps2, ps1, cen)
        small_fill(bm, ps3, ps2, cen)
    else:
        merge_block(bm, ms1, ms2, avg1, avg2)
        merge_block(bm, ms2, ms3, avg2, avg3)
        merge_block(bm, ms3, ms1, avg3, avg1)

        ms_merge(bm, ms1, ms2, cen)
        ms_merge(bm, ms2, ms3, cen)
        ms_merge(bm, ms3, ms1, cen)

        fill_fs(bm, ps1, vss, ms1, ms3, cen)
        fill_fs(bm, ps2, vss, ms2, ms1, cen)
        fill_fs(bm, ps3, vss, ms3, ms2, cen)

    # for v in vss:
    #     v.select = True
    bm.normal_update()
    sel = [f for f in bm.faces if f.select]
    bmesh.ops.recalc_face_normals(bm, faces=sel)



def triangle_list(num):
    res = []
    if num - 2 < 0:
        return []
    num_layers = num // 2
    for layer in range(num_layers):        
        for side in range(3):            
            for i in range(layer * 2 + 2):
                p = {'layer': layer, 'side': side, 'i': i}
                res.append(p)
    return res





def build_reg1(bm, pss, self):
    ps1, ps2, ps3 = pss
    if len(ps1) < 2 or len(ps2) < 2 or len(ps3) < 2:
        self.report({'ERROR'}, 'Please select at least 2 vertices for each edge-group')
        return
    slicing(bm, self, ps1, ps2, ps3)


def check_open_path(ps):
    for v in ps:
        es = v.link_edges
        vs2 = []
        for e1 in es:
            v2 = e1.other_vert(v)
            if v2 in ps:
                vs2.append(v2)
        if len(vs2) == 1:
            # draw_point(v.co)
            return v
    return None
            

def path_length(ps):
    l = 0
    for a, b in zip(ps[:-1], ps[1:]):
        l += (a.co - b.co).length
    return l


def get_axis(ps):
    for i in range(len(ps) - 3):
        a = ps[i]
        b = ps[i+1]
        c = ps[i+2]
        m1 = a.co - b.co
        m2 = c.co - b.co
        m1.normalize()
        m2.normalize()
        if m1.dot(m2) < 0.99:
            return m1
        


def get_limited_path(v, vstops, es, exclude):
    path = []
    v1 = v
    added_edges = []
    while True:
        if v1 in path:
            break
        if v1 in vstops:
            path.append(v1)
            return path
        path.append(v1)
        linke = [e for e in v1.link_edges if (e in es) and (e not in added_edges)]   
        linke2 = []
        for e in linke:
            v2 = e.other_vert(v1)
            if v2 in vstops:
                path.append(v2)
                return path
            if v2 in exclude:
                continue
            linke2.append(e)

        if len(linke2) == 0:
            break
        e = linke2[0]
        added_edges.append(e)
        v1 = e.other_vert(v1)        
    return path


def get_len_path(v, es, total, exclude, vstops):
    path = []
    v1 = v
    added_edges = []
    while True:
        if v1 in path:
            break

        path.append(v1)
        if len(path) > total:
            break

        linke = [e for e in v1.link_edges if (e in es) and (e not in added_edges)]   
        linke2 = []
        for e in linke:
            v2 = e.other_vert(v1)

            if v2 in vstops:
                path.append(v2)
                return path

            if v2 in exclude:
                continue
            linke2.append(e)

        if len(linke2) == 0:
            break
        e = linke2[0]
        added_edges.append(e)
        v1 = e.other_vert(v1)   
    return path

def filling(bm, self):
    es = [e for e in bm.edges if e.select]
    if len(es) < 2:
        # report error to blender
        self.report({'ERROR'}, 'Please select at least 2 edges')        
        return
    vs = get_vs(es)

    end1 = check_open_path(vs)
    if end1 is not None:
        self.report({'ERROR'}, 'Open path detected. Please select edges in closed loop')
        return
    
    ps1 = get_path(vs[0], es)    
    pss = split_path(ps1, es, self.prop_plen)

    if len(pss[0]) != len(pss[1]) or len(pss[1]) != len(pss[2]):
        elen = len(es)
        if elen % 3 != 0:
            self.report({'ERROR'}, 'Please select 3 edges-groups with same number of edges')
            return
        
        grouplen = elen // 3
        ps1 = get_len_path(vs[0], es, grouplen, [], [])
        ps2 = get_len_path(ps1[-1], es, grouplen, ps1, [])
        ps3 = get_len_path(ps2[-1], es, grouplen, ps1 + ps2, [ps1[0], ps2[0]])

        # pprint(ps1)
        # pprint(ps2)
        # pprint(ps3)

        pss = [ps1, ps2, ps3]

    
    if len(pss[0]) % 2 == 0 or len(pss[1]) % 2 == 0 or len(pss[2]) % 2 == 0:
        self.report({'ERROR'}, 'Please select even number of edges (for each edge-group). eg: 2, 4, 6, 8')
        return
    # pprint(pss)
    build_reg1(bm, pss, self)
    # vs_select(bm, pss[2])




class QuickFilletOperator(bpy.types.Operator):
    """Tooltip"""
    bl_idname = "mesh.quick_fillet_operator"
    bl_label = "Quick Fillet"
    bl_options = {"REGISTER", "UNDO"}
    #, "GRAB_CURSOR", "BLOCKING"


    # prop_plen: FloatProperty(
    #     name="Expand size",
    #     description="Expand size",
    #     default=0.05,
    #     step=0.2,
    #     min=0
    # )    

    prop_plen: IntProperty(
        name="Offset",
        description="Offset index for 3 edge-groups",
        default=0,
    )    




    def get_bm(self):
        obj = bpy.context.active_object
        me = obj.data
        bm = bmesh.from_edit_mesh(me)
        return bm

       

    def process(self, context):
        bm = self.get_bm() 
        # gui.lines = []  
        filling(bm, self)

        obj = bpy.context.active_object                
        me = bpy.context.active_object.data
        bmesh.update_edit_mesh(me)  


    def execute(self, context):
        self.process(context)      
        return {'FINISHED'}    

    
    @classmethod
    def poll(cls, context):
        active_object = context.active_object
        selecting = active_object is not None and active_object.type == 'MESH'        
        editing = context.mode == 'EDIT_MESH' 
        is_vert_mode, is_edge_mode, is_face_mode = context.tool_settings.mesh_select_mode
        return selecting and editing and (is_edge_mode, is_vert_mode)


    def invoke(self, context, event): 
        # self.operation_mode = 'None'       
        self.prop_plen = 0                 
                
        if context.edit_object:
            self.process(context)
            return {'FINISHED'} 
        else:
            return {'CANCELLED'}



