Copy from https://github.com/yichen0831/opencc-python/tree/master/opencc
opencc-python-reimplemented 0.1.7