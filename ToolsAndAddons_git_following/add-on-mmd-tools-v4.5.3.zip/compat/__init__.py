# Copyright 2025 MMD Tools authors
# This file is part of MMD Tools.
