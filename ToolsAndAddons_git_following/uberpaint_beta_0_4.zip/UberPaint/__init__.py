bl_info = {
    "name": "UberPaint Beta",
    "location": "N-Panel",
    "blender": (4, 3, 0),
    "category": "Material",
    "author": "Forest Stook",
    "version": (0, 4, 0),
    "description": "Quickly paint PBR materials using vertex colors or textures",
    "warning": "UberPaint is still in development. Please report bugs to iotbot2010@gmail.com or theworkshopwarrior on Discord.",
}

links = {"Discord" : 'https://discord.gg/NQ68E2y26P',
         "Gumroad" : "https://theworkshopwarrior.gumroad.com/",
         }
         
#_TODO:_
# Improve stability by preventing user from going too fast?

# _DONE:_
# Remove unused displace sockets (currently causes error)
# Add image texture masking suppourt
# Switch layer when entering paint mode if already in paint mode
# Implement mixer tweaking (color ramp, opacity, etc.)
# Add displacement settings
# Fix duplicate image textures
# Fix vertex color removal on reposition or update (use UP_MaterialEntry)
# Actually use correct attribute when paint mode
# Various UI improvements
# Add noise texture/displacement map edge blending
# Fix displacement mode / layer props reset on update
# Fix error on no target
# Add support me panel
# Disable buttons during operations
# Fix crash on remove all materials
# Remove vertex colors even in image tex mode
# Fix incorrect painting in texture mode
# Improve undo stability

# _ROADMAP:_
# Add displacement height offset
# Add Blender 4.0 support

import bpy, mathutils

from bpy import context
from bl_ui.generic_ui_list import draw_ui_list
from bpy.props import (IntProperty,
                       BoolProperty,
                       StringProperty,
                       CollectionProperty,
                       PointerProperty)
from bpy.types import (Operator,
                       Panel,
                       PropertyGroup,
                       UIList)
                       
from .utils.insult_engine import goofy_insult
from .utils import up_materials

# Reloading - dev only #####################
from importlib import reload
reload(up_materials)
# #########################################

from .utils.up_materials import (
    up_mixer_node_group,
    up_blendmat_node_group, 
    material_to_group
)

bpy.types.Scene.target = bpy.props.PointerProperty(type=bpy.types.Object)

# --- SETTINGS ---
up_version = 0.4
up_info = "Beta"
#---------------

###########################################################
# Classes
###########################################################

class UP_PT_MainPanel(bpy.types.Panel):
    bl_label = "UberPaint " + up_info + " V" + str(up_version)
    bl_idname = "UP_PT_MainPanel"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = 'UberPaint'

    def draw(self, context):
        layout = self.layout
        scene = context.scene
        obj = context.scene.target
        
        # if not obj:
            # return
        row = layout.row()
        row.prop_search(context.scene, "target", context.scene, "objects", text="Target Object")
        row.operator("ll.set_target", text="", icon="MOD_LINEART")
        
        if obj:
            layout.label(text="Layers:")   
            
            row = layout.row()
            
            row.template_list("UP_UL_MaterialList", "", obj, "ll_materials", obj, "ll_material_index")
            
            col = row.column(align=True)
            col.enabled = bpy.context.object.mode == "OBJECT"
            
            col.operator("ll.manage_material", icon='ADD', text="").action = 'ADD'
            col.operator("ll.manage_material", icon='REMOVE', text="").action = 'REMOVE'
            #col.separator()
            #col.menu("MATERIAL_MT_context_menu", icon='DOWNARROW_HLT', text="")
            col.separator()
            col.operator("ll.manage_material", icon='TRIA_UP', text="").action = 'UP'
            col.operator("ll.manage_material", icon='TRIA_DOWN', text="").action = 'DOWN'
            
            if not scene.target.has_mask:
                layout.label(text="Mask Target:")
                layout.prop(obj, "ll_blend_mode", text="")
            
            # Layer generation button
            row = layout.row()
            row.enabled = bpy.context.object.mode == "OBJECT"
            row.scale_y = 1.5
            
            if scene.target.has_mask:
                row.operator("ll.generate_material", text="Update Blend Material", icon="FILE_REFRESH").action = True
            else:
                row.operator("ll.generate_material", text="Generate Blend Material", icon="SHADERFX").action = False
                _settings_menu = row.operator("wm.settingsmenu", text="", icon="PREFERENCES")
                #_settings_menu.enabled = not(scene.target.has_mask)
            #------------------------------------
            
            # Layer deletion button
            row = layout.row()
            row.enabled = scene.target.has_mask and bpy.context.object.mode == "OBJECT"
            row.operator("ll.remove_material", text="Remove Blend Material", icon="TRASH")
            
            layout.separator()
            if scene.target.has_mask:
                layout.prop(obj, "ll_disp_mode", text="Displacement Mode")

    
class UP_PT_PropsPanel(bpy.types.Panel):
    bl_label = "Layer Properties"
    bl_idname = "UP_PT_PropsPanel"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = 'UberPaint'
    
    def draw(self, context):
        layout = self.layout
        scene = context.scene
        obj = context.scene.target
        active_layer = get_active_layer(context)
        if obj and obj.has_mask:
            box = layout.box()
            row = box.row()
            mgroup = active_layer.mixer_group
            
            opacity_node = mgroup.nodes["Opacity"]
            socket = opacity_node.inputs[0]
            row.label(text="Opacity")
            socket.draw(context, row, opacity_node, socket.name) # Opacity Slider
            
            box = layout.box()
            box.label(text="Mask Controls:")
            mgroup.nodes["Color Ramp"].draw_buttons(context, box) # Color Ramp
            
            box = layout.box()
            # tex = context.texture
            # layout.template_image(active_layer, "image", tex.image_user)
            
            box.label(text="Displacement Blending")
            fx_node = mgroup.nodes["_up_mask_fx"]
            disp_node = mgroup.nodes["Displacement Mask"]
            
            disp_node.draw_buttons(context, layout)
            for input_socket in fx_node.inputs:
                if not input_socket.is_linked:
                    layout.prop(input_socket, "default_value", text=input_socket.name)
            
            
        else:
            box=layout.box()
            box.label(text="Please generate a blend material.  "+goofy_insult(), icon="ERROR")


class UP_PT_PreferencesPanel(bpy.types.AddonPreferences):
    bl_idname = __name__
    bg_color: bpy.props.FloatVectorProperty(name="Base Layer Color", subtype='COLOR', size=3, default=[0.1, 1, 0.0])
    use_goofy_insults: bpy.props.BoolProperty(name="Use Goofy Insults", default=True)
    def draw(self, context):
        layout = self.layout
        #layout.label(text='Default Layer Color')
        row = layout.row()
        row.prop(self, 'bg_color')
        
        row = layout.row()
        row.prop(self, 'use_goofy_insults')
        if self.use_goofy_insults:
            row.label(text="E.G. " + goofy_insult())
        else:
            row.label(text="E.G. " + "404 brain not found.")
            
        layout.separator()
        
        box = layout.box()
        box.label(text="If you've found this addon useful, please consider donating.", icon="FUND")
        row = box.row()
        op = row.operator('wm.url_open', text="My Gumroad", icon="URL")
        op.url = links.get("Gumroad")       
        op = row.operator('wm.url_open', text="Discord Server", icon="URL")
        op.url = links.get("Discord")


class UP_PT_SupportPanel(bpy.types.Panel):
    bl_label = "Support"
    bl_idname = "UP_PT_SupportPanel"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = 'UberPaint'
    
    def draw(self, context):
        layout = self.layout
        scene = context.scene

        box = layout.box()
        box.label(text="Thank you for using UberPaint!")
        row = box.row()
        op = row.operator('wm.url_open', text="My Gumroad", icon="URL")
        op.url = links.get("Gumroad")       
        op = row.operator('wm.url_open', text="Discord Server", icon="URL")
        op.url = links.get("Discord")


class UP_OT_GenerateMaterial(bpy.types.Operator):
    """Generate a blend material for the target object"""
    bl_idname = "ll.generate_material"
    bl_label = "Generate Layer Material"
    # bl_options = {'REGISTER', 'UNDO'}
    
    action: bpy.props.BoolProperty(False) # False for generation, true for updates
    
    def execute(self, context):
        wm = bpy.context.window_manager
        wm.progress_begin(0, 100)
        
        scene = context.scene
        active_object = bpy.context.scene.target
        blend_mode = context.scene.target.ll_blend_mode
        materials = [entry.material for entry in scene.target.ll_materials if entry.material]       
        mesh_dat = active_object.data

        if self.action == True: 
            bpy.ops.ll.remove_material(isupdate=True)
            
        # Preliminary checks to avoid disaster
        if active_object.type != "MESH":
            self.report({'WARNING'}, "Target object is not a mesh.  " + goofy_insult())
            return {'CANCELLED'}
        if len(materials) < 2:
            self.report({'WARNING'}, "Please select at least two materials.  " + goofy_insult())
            return {'CANCELLED'}
            
        # Select and activate target; This may be removed soon.         
        active_object.select_set(True)
        bpy.context.view_layer.objects.active = active_object
        bpy.ops.object.select_all(action='DESELECT')
        active_object.select_set(True)
        
        # -----Create Blend Material-----
        blend_mat_name = active_object.name + " Blend Mat"
        
        # Check if this object already has a material
        if any(mat and mat.name == blend_mat_name for mat in active_object.data.materials):
            self.report({'WARNING'}, "This object already has a blend material.  " + goofy_insult())
            return {'CANCELLED'}
         
        mask_res = scene.ll_texture_resolution
        # Ready to go?  Check if we're using an image or a vertex texture and add attributes accordingly.     
        obj_image_textures =[]
        obj_vgroups = []
        if blend_mode == "TEXTURE":
            if '_upm_paintUVs' not in active_object.data.uv_layers:
                tex_UVs = active_object.data.uv_layers.new(name="_upm_paintUVs")
                mesh_dat.uv_layers.active = mesh_dat.uv_layers["_upm_paintUVs"]
                active_object.select_set(True)
                bpy.ops.object.mode_set(mode='EDIT')
                bpy.ops.mesh.select_mode(type="FACE")
                bpy.ops.mesh.select_all(action='SELECT')
                bpy.ops.uv.smart_project(angle_limit=66, island_margin=0.03)
                bpy.ops.object.mode_set(mode='OBJECT')
            
            i = 0
            images = []
            for mat in materials:
                attr_name = "_upm: "+mat.name
                images.append(attr_name)
                i += 1
                
            rep=0
            for i in materials:
                attr_name = "_upm: "+i.name
                if not bpy.data.images.get(attr_name):
                    image_tex = bpy.data.images.new(attr_name, width=mask_res, height=mask_res)
                    
                    if rep == len(materials)-1 and not self.action:
                        image_tex.pixels = [1.0, 1.0, 1.0, 1.0] * (mask_res * mask_res)
                    else:
                        image_tex.pixels = [0.0, 0.0, 0.0, 1.0] * (mask_res * mask_res)
                    image_tex.pack()
                    print(image_tex)
                    obj_image_textures.append(image_tex)
                    active_object.ll_materials[rep].image_texture = image_tex
                    print("Added:" +image_tex.name)
                print(active_object.ll_materials[rep].image_texture)
                rep+=1
                          
        elif blend_mode == "VERTEX":          
            i = 0    
            for mat in materials:
                attr_name = "_upm: "+mat.name
                active_object.ll_materials[i].color_attr = attr_name
                i += 1
            
            i = 0 
            ngroups = active_object.data.vertex_colors
            valid_vcols = [vcol.name for vcol in ngroups if vcol.name.startswith('_upm: ')]      
            vcols_to_add = {mat.color_attr for mat in active_object.ll_materials}

            for vcol in vcols_to_add:
                if (vcol not in valid_vcols):
                    avc = active_object.data.vertex_colors.new(name=vcol)  
                    # Set vertex colors to black on all but bottom layer
                    for loop in mesh_dat.loops:
                        avc.data[loop.index].color = (0, 0, 0, 1.0) 
                if not self.action:
                    if active_object.ll_materials[len(materials)-1].color_attr == vcol:
                        avc = mesh_dat.vertex_colors[vcol]
                        for loop in mesh_dat.loops:
                            avc.data[loop.index].color = (1, 1, 1, 1.0)   
                i+=1
            
        wm.progress_update(50)
        ##############################################
        # This is where the magic happens.  Adding the node groups to the material
        mixer_groups = []
        converted_mats = []
        blend_mat = bpy.data.materials.new(blend_mat_name)
        blend_mat.use_nodes = True
        blend_mat.displacement_method = active_object.ll_disp_mode
        
        is_tex = True if blend_mode == "TEXTURE" else (False if blend_mode == "VERTEX" else None)
        rep=0
        
        for m in materials:
            mixer_name = "_up_"+m.name + "_mixer"   
            mixer_groups.append(up_mixer_node_group(mixer_name, is_tex, "_upm: "+m.name, "_upm_paintUVs", active_object.ll_materials[rep].image_texture))
            layer_group = material_to_group(m)
            converted_mats.append(layer_group)
            active_object.ll_materials[rep].mixer_group = mixer_groups[rep]
            get_active_layer(context).mixer_group
            
            rep+=1
        
        bg_col = context.preferences.addons[__name__].preferences.bg_color
        up_blendmat_node_group(blend_mat, converted_mats, mixer_groups, bg_col)
            
        scene.target.has_mask = True
        blend_mat.use_nodes = True
        active_object.data.materials.append(blend_mat)
        
        scene.target.ll_blend_material = blend_mat
        
        wm.progress_update(100)
        wm.progress_end()
        bpy.ops.ed.undo_push()        
        self.report({'INFO'}, "Material Created Successfully")        
        return {'FINISHED'}


class UP_OT_ManageMaterials(bpy.types.Operator):
    bl_idname = "ll.manage_material"
    bl_label = "Manage Material"
    action: bpy.props.EnumProperty(
        items=[
            ('ADD', "Add", "Add a new material"),
            ('REMOVE', "Remove", "Remove selected material"),
            ('UP', "Move Up", "Move material up"),
            ('DOWN', "Move Down", "Move material down")
        ]
    )

    def execute(self, context):
        scene = context.scene
        materials = scene.target.ll_materials
        index = scene.target.ll_material_index
        if self.action == 'ADD':
            new_mat = materials.add()
            new_mat.material = None
            scene.target.ll_material_index = len(materials) - 1
        elif self.action == 'REMOVE' and index >= 0:
            materials.remove(index)
            scene.target.ll_material_index = max(0, index - 1)
        elif self.action == 'UP' and index > 0:
            materials.move(index, index - 1)
            scene.target.ll_material_index -= 1
        elif self.action == 'DOWN' and index < len(materials) - 1:
            materials.move(index, index + 1)
            scene.target.ll_material_index += 1
        
        if scene.target.has_mask and self.action != 'ADD':
            bpy.ops.ll.generate_material(action=True)
        
        return {'FINISHED'}


class UP_OT_RemoveMaterial(bpy.types.Operator):
    """Remove and clean up the target object's blend materal"""
    bl_idname = "ll.remove_material"
    bl_label = "Remove Blend Material"
    
    isupdate: bpy.props.BoolProperty(False) # False for full removal, true for updates
    
    def execute(self, context):
        scene = context.scene
        active_object = bpy.context.scene.target
        blend_mode = context.scene.target.ll_blend_mode
        materials = [entry.material for entry in scene.target.ll_materials if entry.material]
        isupdate = self.isupdate
        
        # Check if the target already has a blend mat
        if scene.target.has_mask == False:
            return {'CANCELLED'}
        
        active_object.select_set(True)
        bpy.context.view_layer.objects.active = active_object
        bpy.ops.object.select_all(action='DESELECT')
        active_object.select_set(True)
        
        m = active_object.ll_blend_material
        if not m:
            self.report({'WARNING'}, "We couldn't find the blend material. Did you delete it? Try regenerating.")
            scene.target.has_mask = False
            bpy.ops.object.material_slot_remove()
            return {'CANCELLED'}
        
        
        bpy.data.materials.remove(m)
        bpy.ops.object.material_slot_remove()
        
        # Remove UVs :D
        if not(isupdate) and '_upm_paintUVs' in active_object.data.uv_layers:
            uv_layer = active_object.data.uv_layers['_upm_paintUVs']
            active_object.data.uv_layers.remove(layer=uv_layer)
        
        # Remove Image Textures
        upm_images = [img for img in bpy.data.images if img.name.startswith("_upm: ")]
        obj_texs = [entry.image_texture for entry in active_object.ll_materials if entry.image_texture] 
        if upm_images:
            if isupdate:
                for img in upm_images:
                    if not img.users:  # Check if the image has no real users
                        bpy.data.images.remove(img)  # Remove the image
            else:
                for img in bpy.data.images:
                    if img.name.startswith('_upm: '):
                        bpy.data.images.remove(img)
        
        # # Remove Color Attributes :D
        vcol_layers = active_object.data.vertex_colors
        vcols = [vcol for vcol in vcol_layers if vcol.name.startswith('_upm: ')]      
        if hasattr(active_object.data, "vertex_colors") and len(vcols)>0: # and active_object.ll_blend_mode == "VERTEX":
            obj_clrs = [entry.color_attr for entry in active_object.ll_materials if entry.color_attr] 
            vcols = []
            for color_attr in obj_clrs:
                vcols.append(active_object.data.vertex_colors[color_attr])
            vcols.reverse()
            
            vt_colors = active_object.data.vertex_colors
            
            if isupdate:  
                rep = 0
                for vcol in vcols:
                    if vcol not in list(vt_colors):
                        vt_colors.remove(vcol)
                        rep+=1
            else:
                vcol_layers = active_object.data.vertex_colors
                vcols = [vcol for vcol in vcol_layers if vcol.name.startswith('_upm: ')]
                vcols.reverse() # Do this or else strange things happen
                for vcol in vcols:
                    vt_colors.remove(vcol)
                        
        # Remove node groups
        ngroups = bpy.data.node_groups
        ngroups_to_remove = [ngroup for ngroup in ngroups if ngroup.name.startswith('_up_')]      
        valid_mixer_groups = {mat.mixer_group.name for mat in bpy.context.object.ll_materials if mat.mixer_group}
        
        for ngroup in ngroups_to_remove:
            if not isupdate or (ngroup.name not in valid_mixer_groups and ngroup.name!="_up_mask_fx"):
                bpy.data.node_groups.remove(ngroup)       
        
        # Finalize Transaction
        if not isupdate:
            bpy.ops.ed.undo_push()  
            
        scene.target.has_mask = False
        self.report({'INFO'}, "Material Removed Successfully")
        return {'FINISHED'}


class UP_OT_PaintMode(bpy.types.Operator):
    """Toggle painting mode for this layer"""
    bl_idname = "ll.enter_paint_mode"
    bl_label = "Paint Layer"
    
    input_index : IntProperty(default=0)
    def execute(self, context):
        scene = context.scene
        active_object = bpy.context.scene.target
        blend_mode = scene.target.ll_blend_mode
        materials = [entry.material for entry in scene.target.ll_materials if entry.material]
        aod = active_object.data
        input_index = self.input_index
        current_layer = 0
        
    # Toggle painting vs. object mode
        if blend_mode == "TEXTURE":
            if bpy.context.object.mode == 'OBJECT':
                bpy.ops.object.mode_set(mode='TEXTURE_PAINT')
                bpy.context.scene.tool_settings.image_paint.canvas = active_object.ll_materials[input_index].image_texture
                bpy.context.scene.tool_settings.image_paint.mode = 'IMAGE'

                
            elif bpy.context.object.mode == 'TEXTURE_PAINT':
                if input_index == active_object.ll_material_index:
                    bpy.ops.object.mode_set(mode='OBJECT')
                else:
                    bpy.context.scene.tool_settings.image_paint.canvas = active_object.ll_materials[input_index].image_texture
        elif blend_mode == "VERTEX":
            if bpy.context.object.mode == 'OBJECT':
                aod.vertex_colors.active = aod.vertex_colors[active_object.ll_materials[input_index].color_attr]
                bpy.ops.object.mode_set(mode='VERTEX_PAINT')
                
            elif bpy.context.object.mode == 'VERTEX_PAINT':
                if input_index == active_object.ll_material_index:
                    bpy.ops.object.mode_set(mode='OBJECT')
                else:
                    aod.vertex_colors.active = aod.vertex_colors[active_object.ll_materials[input_index].color_attr]
                    
        current_layer = input_index
        active_object.ll_material_index = input_index # Select the layer we're painting
        return {'FINISHED'}


class UP_OT_SetTargetObject(bpy.types.Operator):
    """Set the UberPaint target object to the active object in viewport"""
    bl_idname = "ll.set_target"
    bl_label = "Set Target Object"
    def execute(self, context):
        scene = context.scene
        scene.target = context.active_object
        self.report({'INFO'}, "Target object set to active object")
        return {'FINISHED'}


class UP_UL_MaterialList(bpy.types.UIList):
    def draw_item(self, context, layout, data, item, icon, active_data, active_propname, index):
        
    # Add seperate icons for texture vs. vertex painting
        scene = context.scene
        blend_mode = scene.target.ll_blend_mode
        mode_icon = None
        
        if blend_mode == "TEXTURE":
            mode_icon = "TPAINT_HLT"
        elif blend_mode == "VERTEX":
            mode_icon = "VPAINT_HLT"
        if (bpy.context.object.mode == "TEXTURE_PAINT" or bpy.context.object.mode == "VERTEX_PAINT") and scene.target.ll_material_index == index:  # Are we in texture paint mode and is the active layer selected?
            mode_icon = "BRUSH_DATA"
    # Draw layers UIlist  
        if index == scene.target.ll_material_index:
            layout.label(text="", icon="RADIOBUT_ON")
        else:
            layout.label(text="", icon="RADIOBUT_OFF")
            
        layergroup = item
        layout.prop(layergroup, "material", text="")
        
        row = layout.row()
        has_blend_mat = scene.target.has_mask
        
        if has_blend_mat == True:
            row.enabled = True
        elif has_blend_mat == False:
            row.enabled = False
            
        # layout.prop(layergroup, "opacity", text="Opacity", slider=True)   
        op = row.operator("ll.enter_paint_mode", icon = mode_icon, text="")
        op.input_index = index


class WM_OT_SettingsMenu(bpy.types.Operator):
    """Open generation settings"""
    bl_label = "Paint Mask Texture Settings"
    bl_idname = "wm.settingsmenu"
    
    
    #res_x : bpy.props.IntProperty(name="Resolution", default = 1024)
    
    def draw(self, context):
        layout = self.layout
        scene = context.scene
        
        warning_size = 512

        layout.prop(scene, "ll_blend_mode", text="")
        mask_res = layout.prop(scene, "ll_texture_resolution", text = "Mask Texture Size")
        settings_overview = str(scene.ll_texture_resolution) + " x " + str(scene.ll_texture_resolution)
        layout.label(text=settings_overview)
        if scene.ll_texture_resolution > warning_size:
            layout.label(icon="ERROR", text="Sizes over "+str(warning_size)+"px are usually uneccasary and can result in lag when painting.")

    def execute(self, context):
       # mask_width = res_x
        return {'FINISHED'}
    
    def invoke(self, context, event):     
        return context.window_manager.invoke_props_dialog(self)


class UP_MaterialEntry(bpy.types.PropertyGroup):
    material: bpy.props.PointerProperty(type=bpy.types.Material)
    image_texture: bpy.props.PointerProperty(type=bpy.types.Image)
    color_attr: StringProperty(default="")
    mixer_group: bpy.props.PointerProperty(type=bpy.types.ShaderNodeTree) 
    opacity: bpy.props.FloatProperty(name="opacity", default=1, min=0, max=1)


###########################################################
# Functions
###########################################################

def get_active_layer(context):
    """Retrieve the currently active layer based on index."""
    scene = context.scene
    target = scene.target 
    if hasattr(target, "ll_materials") and len(target.ll_materials) > target.ll_material_index:
        return target.ll_materials[target.ll_material_index]
    return None

def update_tweaks(self, context):
    scene = context.scene
    material = self.material
    bpy.data.node_groups["_up_Cracked Asphalt_mixer"].nodes["Math"].inputs[1].default_value = active_layer.opacity 
    
###########################################################
# Registration
###########################################################

classes = [
    UP_UL_MaterialList,
    UP_PT_MainPanel,
    UP_PT_PropsPanel,
    UP_OT_ManageMaterials,
    UP_OT_GenerateMaterial,
    UP_OT_RemoveMaterial,
    UP_MaterialEntry,
    WM_OT_SettingsMenu,
    UP_OT_PaintMode,
    UP_PT_PreferencesPanel,
    UP_OT_SetTargetObject,
    UP_PT_SupportPanel
]

def register():
    for cls in classes:
        bpy.utils.register_class(cls)
    bpy.types.Object.ll_materials = bpy.props.CollectionProperty(type=UP_MaterialEntry)
    bpy.types.Object.ll_material_index = bpy.props.IntProperty(default=0)
    
    bpy.types.Object.ll_blend_material = bpy.props.PointerProperty(type=bpy.types.Material)
    
    bpy.types.Scene.ll_texture_resolution = bpy.props.IntProperty(default=256) # scene var
    bpy.types.Object.ll_blend_mode = bpy.props.EnumProperty(
        name="Blend Mode",
        description="Choose blending method",
        items=[
            ('VERTEX', "Vertex Colors", "Use vertex colors for blending"),
            ('TEXTURE', "Image Textures", "Use image textures for blending")
        ],
        default='VERTEX'
    )
    
    bpy.types.Object.ll_disp_mode = bpy.props.EnumProperty(
    name="Displacement Mode",
    description="Choose shader displacement method",
    items=[
        ('BUMP', "Bump Only", ""),
        ('DISPLACEMENT', "Displacement Only", ""),
        ('BOTH', "Displacement and Bump", "")
    ],
    default='BUMP'
    )
    
    bpy.types.Object.has_mask = bpy.props.BoolProperty(
    name="Has Mask",
    description="Indicates whether this object has a mask",
    default=False)

def unregister():
    for cls in reversed(classes):
        bpy.utils.unregister_class(cls)
    del bpy.types.Object.ll_materials
    del bpy.types.Object.ll_material_index
    del bpy.types.Object.ll_blend_mode

  