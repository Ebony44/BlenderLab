import bpy
import mathutils


def up_blendmat_node_group(mat, converted_mats, mixer_groups, bg_color):
    converted_mats.reverse()
    mixer_groups.reverse()
    if not(mat or orginal_mat):
        return none
        
    mat.use_nodes = True
    up_blendmat = mat.node_tree

    #start with a clean node tree
    for node in up_blendmat.nodes:
        up_blendmat.nodes.remove(node)
    up_blendmat.color_tag = 'NONE'
    up_blendmat.description = ""
    up_blendmat.default_group_node_width = 140
    
    material_output = up_blendmat.nodes.new("ShaderNodeOutputMaterial")
    material_output.name = "Material Output"
    material_output.is_active_output = True
    material_output.target = 'ALL'   
    
    base_shader = up_blendmat.nodes.new("ShaderNodeBsdfDiffuse")
    
    _vertical_height = 200
    
    base_shader.location = (-220, -200)
    
    loop_counter = 0
    prev_mixer_node = mixer_groups[0]
    material_output_y_offset = 0
    #loop_clipper = 2
    
    for _mixer in mixer_groups:
        # Skip the first two loops, because we already added those groups >:(
        # if loop_clipper > 0:
            # loop_clipper -= 1
            # continue
        
        # Create the new nodes: mixer, and group
        mixer_node = up_blendmat.nodes.new("ShaderNodeGroup")
        mixer_node.node_tree = _mixer
        
        #initialize up_blendmat links
        if loop_counter == 0:
            up_blendmat.links.new(base_shader.outputs[0], mixer_node.inputs[1])
            # up_blendmat.links.new(base_shader.outputs[1], mixer_node.inputs[3])
        
        group_a = up_blendmat.nodes.new("ShaderNodeGroup")
        group_a.node_tree = converted_mats[loop_counter]

        #Set locations
        
        mixer_node.location = (120, _vertical_height*loop_counter)
        group_a.location = (-220.0, _vertical_height*loop_counter)

        # Connect groups to mixers
        up_blendmat.links.new(group_a.outputs[0], mixer_node.inputs[0])
        if len(group_a.outputs) != 1: # Sometimes people are too lazy to use displacement
            up_blendmat.links.new(group_a.outputs[1], mixer_node.inputs[2]) 
        
        # Connect mixers to mixers >:D
        if loop_counter != 0:
            up_blendmat.links.new(prev_mixer_node.outputs[0], mixer_node.inputs[1])
            up_blendmat.links.new(prev_mixer_node.outputs[1], mixer_node.inputs[3])
        
        material_output_y_offset = _vertical_height*loop_counter
        
        prev_mixer_node = mixer_node   
        loop_counter += 1
        
    #group.Shader -> material_output.Surface
    up_blendmat.links.new(mixer_node.outputs[0], material_output.inputs[0])
    up_blendmat.links.new(mixer_node.outputs[1], material_output.inputs[2])
    
    material_output.location = (350, material_output_y_offset)
    base_shader.inputs[0].default_value = (*bg_color, 1)
    
    return up_blendmat

###########################################################

def material_to_group(original_mat): 
    if not original_mat.node_tree:
        return None

    # Create new node group
    group_name = f"_up_{original_mat.name}"
    group = bpy.data.node_groups.new(group_name, 'ShaderNodeTree')
    group_nodes = group.nodes
    group_links = group.links

    # Create Group Output node
    group_output_node = group_nodes.new('NodeGroupOutput')
    group_output_node.location = (300, 0)
    
    # Track original nodes and links
    original_nodes = original_mat.node_tree.nodes
    original_links = original_mat.node_tree.links
    original_output_node = next((n for n in original_nodes if n.type == 'OUTPUT_MATERIAL'), None)

    if not original_output_node:
        return group

    # Map original nodes to new group nodes (excluding Material Output)
    node_map = {}

    # This is a bit of a yucky scenario.  We have to copy over all the original node's properties.  (e.g. transforms on a vector mapping node)


    for node in original_nodes:
        if node == original_output_node:
            continue

        # Create the new node
        new_node = group_nodes.new(node.bl_idname)
        node_map[node] = new_node

        # Copy simple attributes
        new_node.location = node.location
        new_node.name = node.name
        new_node.label = node.label

        # Dynamically copy all properties
        for prop in node.bl_rna.properties:
            prop_name = prop.identifier
            
            # Skip read-only properties and already-copied attributes
            if prop.is_readonly or prop_name in {"name", "label", "location"}:
                continue

            # Ensure both nodes have the property
            if hasattr(node, prop_name) and hasattr(new_node, prop_name):
                try:
                    value = getattr(node, prop_name)

                    # Handle special Blender types
                    if isinstance(value, bpy.types.Image):  # Copy images (Texture nodes)
                        setattr(new_node, prop_name, value)
                    
                    elif isinstance(value, bpy.types.NodeTree):  # Copy node groups
                        setattr(new_node, prop_name, value)
                    
                    elif hasattr(value, "to_tuple"):  # Handle Vectors, Colors, Matrices
                        setattr(new_node, prop_name, value.to_tuple())
                    
                    elif isinstance(value, (int, float, bool, str)):  # Handle standard types
                        setattr(new_node, prop_name, value)

                except (AttributeError, TypeError):
                    pass

        for input_socket, new_input_socket in zip(node.inputs, new_node.inputs):
            if input_socket.type in {'VALUE', 'VECTOR', 'RGBA'}:  # Only copy numerical data
                new_input_socket.default_value = input_socket.default_value

        for output_socket, new_output_socket in zip(node.outputs, new_node.outputs):
            if output_socket.type in {'VALUE', 'VECTOR', 'RGBA'}:
                new_output_socket.default_value = output_socket.default_value

    for link in original_links:
        if link.to_node == original_output_node or link.from_node == original_output_node:
            continue  # Skip connections to the original output node

        from_node = node_map.get(link.from_node)
        to_node = node_map.get(link.to_node)
        
        if from_node and to_node:
            from_socket = next((s for s in from_node.outputs if s.name == link.from_socket.name), None)
            to_socket = next((s for s in to_node.inputs if s.name == link.to_socket.name), None)
            
            if from_socket and to_socket:
                group_links.new(from_socket, to_socket)

    # Second loop: Handle connections to the original output node separately
    for link in original_links:
        if link.to_node == original_output_node:
            socket_name = link.to_socket.name
            original_from_socket = link.from_socket
            group_from_node = node_map.get(link.from_node)

            if group_from_node:
                socket_type = link.to_socket.bl_idname  
                
                # Create a single output socket with the correct type and name
                group_output_socket = group.interface.new_socket(
                    name=socket_name,
                    in_out='OUTPUT',
                    socket_type=socket_type
                )
                
                group_from_socket = next(
                    (s for s in group_from_node.outputs if s.name == original_from_socket.name),
                    None
                )
                
                if group_from_socket:
                    # Connect the grouped node's output to the new group output socket
                    group_links.new(group_from_socket, group_output_node.inputs[socket_name])

    return group
    
###########################################################
    
def up_mixer_node_group(name: str, istexture: bool, attr_name: str, uv_name: str, image_tex):
    
    if name in bpy.data.node_groups:
        return bpy.data.node_groups[name]
        
    _up_mixer = bpy.data.node_groups.new(type = 'ShaderNodeTree', name=name)

    _up_mixer.color_tag = 'SCRIPT'
    _up_mixer.description = ""
    _up_mixer.default_group_node_width = 160
    

    #_up_mixer interface
    #Socket Shader
    shader_socket = _up_mixer.interface.new_socket(name = "Shader", in_out='OUTPUT', socket_type = 'NodeSocketShader')
    shader_socket.attribute_domain = 'POINT'

    #Socket Displacement
    displacement_socket = _up_mixer.interface.new_socket(name = "Displacement", in_out='OUTPUT', socket_type = 'NodeSocketVector')
    displacement_socket.default_value = (0.0, 0.0, 0.0)
    displacement_socket.min_value = -3.4028234663852886e+38
    displacement_socket.max_value = 3.4028234663852886e+38
    displacement_socket.subtype = 'NONE'
    displacement_socket.attribute_domain = 'POINT'

    #Socket Shader A
    shader_a_socket = _up_mixer.interface.new_socket(name = "Shader A", in_out='INPUT', socket_type = 'NodeSocketShader')
    shader_a_socket.attribute_domain = 'POINT'

    #Socket Shader B
    shader_b_socket = _up_mixer.interface.new_socket(name = "Shader B", in_out='INPUT', socket_type = 'NodeSocketShader')
    shader_b_socket.attribute_domain = 'POINT'

    #Socket Displacement A
    displacement_a_socket = _up_mixer.interface.new_socket(name = "Displacement A", in_out='INPUT', socket_type = 'NodeSocketVector')
    displacement_a_socket.default_value = (0.0, 0.0, 0.0)
    displacement_a_socket.min_value = -3.4028234663852886e+38
    displacement_a_socket.max_value = 3.4028234663852886e+38
    displacement_a_socket.subtype = 'NONE'
    displacement_a_socket.attribute_domain = 'POINT'
    displacement_a_socket.hide_value = True

    #Socket Displacement B
    displacement_b_socket = _up_mixer.interface.new_socket(name = "Displacement B", in_out='INPUT', socket_type = 'NodeSocketVector')
    displacement_b_socket.default_value = (0.0, 0.0, 0.0)
    displacement_b_socket.min_value = -3.4028234663852886e+38
    displacement_b_socket.max_value = 3.4028234663852886e+38
    displacement_b_socket.subtype = 'NONE'
    displacement_b_socket.attribute_domain = 'POINT'
    displacement_b_socket.hide_value = True


    #initialize _up_mixer nodes
    #node Group Output
    group_output = _up_mixer.nodes.new("NodeGroupOutput")
    group_output.name = "Group Output"
    group_output.is_active_output = True

    #node Group Input
    group_input = _up_mixer.nodes.new("NodeGroupInput")
    group_input.name = "Group Input"

    #node Mix Shader
    mix_shader = _up_mixer.nodes.new("ShaderNodeMixShader")
    mix_shader.name = "Mix Shader"
    
    

    #node Color Ramp
    color_ramp = _up_mixer.nodes.new("ShaderNodeValToRGB")
    color_ramp.label = "Color Adjustments"
    color_ramp.name = "Color Ramp"
    color_ramp.color_ramp.color_mode = 'RGB'
    color_ramp.color_ramp.hue_interpolation = 'NEAR'
    color_ramp.color_ramp.interpolation = 'LINEAR'

    #initialize color ramp elements
    color_ramp.color_ramp.elements.remove(color_ramp.color_ramp.elements[0])
    color_ramp_cre_0 = color_ramp.color_ramp.elements[0]
    color_ramp_cre_0.position = 0.0
    color_ramp_cre_0.alpha = 1.0
    color_ramp_cre_0.color = (0.0, 0.0, 0.0, 1.0)

    color_ramp_cre_1 = color_ramp.color_ramp.elements.new(1.0)
    color_ramp_cre_1.alpha = 1.0
    color_ramp_cre_1.color = (1.0, 1.0, 1.0, 1.0)


    #node Math
    math = _up_mixer.nodes.new("ShaderNodeMix")
    math.label = "Opacity"
    math.name = "Opacity"
    math.blend_type = 'MIX'
    math.clamp_factor = True
    math.clamp_result = False
    math.data_type = 'FLOAT'
    math.factor_mode = 'UNIFORM'
    math.inputs[0].default_value = 1
    
    image_texture = _up_mixer.nodes.new("ShaderNodeTexImage")
    uv_map = _up_mixer.nodes.new("ShaderNodeUVMap")
    color_attribute = _up_mixer.nodes.new("ShaderNodeVertexColor")
    
    if istexture:
        #node Image Texture
        image_texture.label = "Mask"
        image_texture.name = attr_name
        image_texture.extension = 'REPEAT'
        image_texture.image_user.tile = 0
        image_texture.interpolation = 'Cubic'
        image_texture.projection = 'FLAT'
        image_texture.projection_blend = 0.0
        if image_tex:
            image_texture.image = image_tex
        
        uv_map.uv_map = uv_name
    
    else:
        #node Color Attribute
        color_attribute.label = "Mask"
        color_attribute.name = "Color Attribute"
        color_attribute.layer_name = attr_name

    #node Map Range
    map_range = _up_mixer.nodes.new("ShaderNodeMapRange")
    map_range.name = "Map Range"
    map_range.clamp = True
    map_range.data_type = 'FLOAT'
    map_range.interpolation_type = 'LINEAR'
    #From Min
    map_range.inputs[1].default_value = 0.0
    #From Max
    map_range.inputs[2].default_value = 1.0
    #To Min
    map_range.inputs[3].default_value = 1.0
    #To Max
    map_range.inputs[4].default_value = 0.0

    #node Mix
    mix = _up_mixer.nodes.new("ShaderNodeMix")
    mix.name = "Mix"
    mix.blend_type = 'MIX'
    mix.clamp_factor = True
    mix.clamp_result = False
    mix.data_type = 'FLOAT'
    mix.factor_mode = 'UNIFORM'
    #Factor_Float
    mix.inputs[0].default_value = 1
    
    #  Displacement map blending
    disp_mask = _up_mixer.nodes.new("ShaderNodeTexImage")
    disp_mask.name = "Displacement Mask"
    disp_mask.extension = 'REPEAT'
    disp_mask.image_user.frame_current = 0
    disp_mask.image_user.frame_duration = 100
    disp_mask.image_user.frame_offset = 0
    disp_mask.image_user.frame_start = 1
    disp_mask.image_user.tile = 0
    disp_mask.image_user.use_auto_refresh = False
    disp_mask.image_user.use_cyclic = False
    disp_mask.interpolation = 'Linear'
    disp_mask.projection = 'FLAT'
    disp_mask.projection_blend = 0.0
    #Vector
    disp_mask.inputs[0].default_value = (0.0, 0.0, 0.0)
    
    up_mask_fx = _up_mixer.nodes.new("ShaderNodeGroup")
    up_mask_fx.node_tree = _up_mask_fx_node_group()
    up_mask_fx.name = "_up_mask_fx"
    ##############################################################
    
    #node Frame
    frame = _up_mixer.nodes.new("NodeFrame")
    frame.label = "Invert Mask"
    frame.name = "Frame"
    frame.use_custom_color = True
    frame.color = (0.48100608587265015, 0.0, 0.010056587867438793)
    frame.label_size = 15
    frame.shrink = True

    #node Frame.001
    frame_001 = _up_mixer.nodes.new("NodeFrame")
    frame_001.label = "Adjustments"
    frame_001.name = "Frame.001"
    frame_001.use_custom_color = True
    frame_001.color = (0.1411742866039276, 0.38431480526924133, 0.513721227645874)
    frame_001.label_size = 25
    frame_001.shrink = True

    #node Frame.002
    frame_002 = _up_mixer.nodes.new("NodeFrame")
    frame_002.label = "Mask Input"
    frame_002.name = "Frame.002"
    frame_002.use_custom_color = True
    frame_002.color = (0.47451215982437134, 0.27451279759407043, 0.1137266531586647)
    frame_002.label_size = 20
    frame_002.shrink = True

    #node Frame.003
    frame_003 = _up_mixer.nodes.new("NodeFrame")
    frame_003.label = "Output"
    frame_003.name = "Frame.003"
    frame_003.use_custom_color = True
    frame_003.color = (0.16862842440605164, 0.39608046412467957, 0.16862842440605164)
    frame_003.label_size = 20
    frame_003.shrink = True

    #node Frame.004
    frame_004 = _up_mixer.nodes.new("NodeFrame")
    frame_004.label = "DO NOT MODIFY UNLESS YOU ARE ABSOLUTELY SURE YOU KNOW WHAT"
    frame_004.name = "Frame.004"
    frame_004.label_size = 20
    frame_004.shrink = True

    #node Frame.005
    frame_005 = _up_mixer.nodes.new("NodeFrame")
    frame_005.label = "YOU ARE DOING"
    frame_005.name = "Frame.005"
    frame_005.label_size = 20
    frame_005.shrink = True
    
    ##############################################################

    #node Mix.001
    mix_001 = _up_mixer.nodes.new("ShaderNodeMix")
    mix_001.name = "Mix.001"
    mix_001.blend_type = 'MIX'
    mix_001.clamp_factor = True
    mix_001.clamp_result = False
    mix_001.data_type = 'VECTOR'
    mix_001.factor_mode = 'UNIFORM'

    #node Reroute
    reroute = _up_mixer.nodes.new("NodeReroute")
    reroute.name = "Reroute"
    reroute.socket_idname = "NodeSocketFloat"
    #node Frame.006
    frame_006 = _up_mixer.nodes.new("NodeFrame")
    frame_006.label = "Originally from UberPaint by Forest Stook"
    frame_006.name = "Frame.006"
    frame_006.use_custom_color = True
    frame_006.color = (0.43670257925987244, 0.3156389594078064, 0.11718340963125229)
    frame_006.label_size = 15
    frame_006.shrink = True

    #Set parents
    group_output.parent = frame_003
    group_input.parent = frame_003
    mix_shader.parent = frame_003
    color_ramp.parent = frame_001
    math.parent = frame_001
    image_texture.parent = frame_002
    color_attribute.parent = frame_002
    map_range.parent = frame
    mix.parent = frame
    frame.parent = frame_001
    mix_001.parent = frame_003
    reroute.parent = frame_003

    group_output.location = (700.0, 0.0)
    group_input.location = (220.0, 0.0)
    mix_shader.location = (480.0, 100.0)
    color_ramp.location = (-720.0, -20.0)
    math.location = (-420.0, -20.0)
    image_texture.location = (-1060.0, -140.0)
    uv_map.location = (-1260.0, -140.0)
    color_attribute.location = (-1060.0, 0.0)
    map_range.location = (-220.0, -100.0)
    mix.location = (-40.0, 80.0)
    frame.location = (0.0, 0.0)
    frame_001.location = (0.0, 0.0)
    frame_002.location = (0.0, 0.0)
    frame_003.location = (498.0, 20.0)
    frame_004.location = (-48.0, 403.0)
    frame_005.location = (-48.0, 343.0)
    mix_001.location = (480.0, -60.0)
    reroute.location = (220.0, -200.0)
    frame_006.location = (760.0, -240.0)
    up_mask_fx.location = (480.0, 100.0)
    disp_mask.location = (200.0, -140.0)
    
    #Set dimensions
    group_output.width, group_output.height = 140.0, 100.0
    group_input.width, group_input.height = 140.0, 100.0
    mix_shader.width, mix_shader.height = 140.0, 100.0
    color_ramp.width, color_ramp.height = 240.0, 100.0
    math.width, math.height = 140.0, 100.0
    image_texture.width, image_texture.height = 240.0, 100.0
    color_attribute.width, color_attribute.height = 140.0, 100.0
    map_range.width, map_range.height = 140.0, 100.0
    mix.width, mix.height = 140.0, 100.0
    frame.width, frame.height = 380.0, 484.75
    frame_001.width, frame_001.height = 910.0, 561.0
    frame_002.width, frame_002.height = 300.0, 406.0
    frame_003.width, frame_003.height = 688.0, 427.0
    frame_004.width, frame_004.height = 733.375732421875, 54.1676025390625
    frame_005.width, frame_005.height = 733.375732421875, 54.1676025390625
    mix_001.width, mix_001.height = 140.0, 100.0
    reroute.width, reroute.height = 16.0, 100.0
    frame_006.width, frame_006.height = 325.2783203125, 46.64691162109375

    #initialize _up_mixer links
    #group_input.Shader A -> mix_shader.Shader
    _up_mixer.links.new(group_input.outputs[0], mix_shader.inputs[1])
    #group_input.Shader B -> mix_shader.Shader
    _up_mixer.links.new(group_input.outputs[1], mix_shader.inputs[2])
    #mix_shader.Shader -> group_output.Shader
    _up_mixer.links.new(mix_shader.outputs[0], group_output.inputs[0])
    #mix.Result -> mix_shader.Fac
    _up_mixer.links.new(up_mask_fx.outputs[0], mix_shader.inputs[0])
    #color_ramp.Color -> math.Value
    _up_mixer.links.new(color_ramp.outputs[0], math.inputs[3])
    #color_attribute.Color -> color_ramp.Fac
    _up_mixer.links.new(uv_map.outputs[0], image_texture.inputs[0])
    #####  Dynamically link texture inputs or attribute inputs depending on specified input.
    if istexture:
        _up_mixer.links.new(image_texture.outputs[0], color_ramp.inputs[0])
    else: 
        _up_mixer.links.new(color_attribute.outputs[0], color_ramp.inputs[0])
       
    _up_mixer.links.new(mix.outputs[0], up_mask_fx.inputs[2])
    _up_mixer.links.new(disp_mask.outputs[0], up_mask_fx.inputs[3])
    #math.Value -> map_range.Value
    _up_mixer.links.new(math.outputs[0], map_range.inputs[0])
    #math.Value -> mix.A
    _up_mixer.links.new(math.outputs[0], mix.inputs[2])
    #map_range.Result -> mix.B
    _up_mixer.links.new(map_range.outputs[0], mix.inputs[3])
    #group_input.Displacement A -> mix_001.A
    _up_mixer.links.new(group_input.outputs[2], mix_001.inputs[4])
    #group_input.Displacement B -> mix_001.B
    _up_mixer.links.new(group_input.outputs[3], mix_001.inputs[5])
    #mix_001.Result -> group_output.Displacement
    _up_mixer.links.new(mix_001.outputs[1], group_output.inputs[1])
    #reroute.Output -> mix_001.Factor
    _up_mixer.links.new(reroute.outputs[0], mix_001.inputs[0])
    #mix.Result -> reroute.Input
    _up_mixer.links.new(up_mask_fx.outputs[0], reroute.inputs[0])
    return _up_mixer
    
###################################################################

def _up_mask_fx_node_group():
    
    if "_up_mask_fx" in bpy.data.node_groups:
        return bpy.data.node_groups["_up_mask_fx"]
        
    _up_mask_fx = bpy.data.node_groups.new(type = 'ShaderNodeTree', name = "_up_mask_fx")

    _up_mask_fx.color_tag = 'CONVERTER'
    _up_mask_fx.description = ""
    _up_mask_fx.default_group_node_width = 140
    

    #_up_mask_fx interface
    #Socket Mask Output
    mask_output_socket = _up_mask_fx.interface.new_socket(name = "Mask Output", in_out='OUTPUT', socket_type = 'NodeSocketFloat')
    mask_output_socket.default_value = 0.0
    mask_output_socket.min_value = -3.4028234663852886e+38
    mask_output_socket.max_value = 3.4028234663852886e+38
    mask_output_socket.subtype = 'NONE'
    mask_output_socket.attribute_domain = 'POINT'

    #Socket Use Displacement Blending
    use_displacement_blending_socket = _up_mask_fx.interface.new_socket(name = "Use Displacement Blending", in_out='INPUT', socket_type = 'NodeSocketBool')
    use_displacement_blending_socket.default_value = False
    use_displacement_blending_socket.attribute_domain = 'POINT'

    #Socket Is Opacity Mask
    is_opacity_mask_socket = _up_mask_fx.interface.new_socket(name = "Is Opacity Mask", in_out='INPUT', socket_type = 'NodeSocketBool')
    is_opacity_mask_socket.default_value = False
    is_opacity_mask_socket.attribute_domain = 'POINT'
    is_opacity_mask_socket.description = "Overrides Use Displacement"

    #Socket Mask Input
    mask_input_socket = _up_mask_fx.interface.new_socket(name = "Mask Input", in_out='INPUT', socket_type = 'NodeSocketFloat')
    mask_input_socket.default_value = 1.0
    mask_input_socket.min_value = -10000.0
    mask_input_socket.max_value = 10000.0
    mask_input_socket.subtype = 'NONE'
    mask_input_socket.attribute_domain = 'POINT'

    #Socket Displacement
    displacement_socket = _up_mask_fx.interface.new_socket(name = "Displacement", in_out='INPUT', socket_type = 'NodeSocketFloat')
    displacement_socket.default_value = 0.0
    displacement_socket.min_value = 0.0
    displacement_socket.max_value = 1.0
    displacement_socket.subtype = 'FACTOR'
    displacement_socket.attribute_domain = 'POINT'

    #Socket Offset
    offset_socket = _up_mask_fx.interface.new_socket(name = "Offset", in_out='INPUT', socket_type = 'NodeSocketFloat')
    offset_socket.default_value = -2.5
    offset_socket.min_value = -2
    offset_socket.max_value = 2
    offset_socket.subtype = 'NONE'
    offset_socket.attribute_domain = 'POINT'

    #Socket Intensity
    intensity_socket = _up_mask_fx.interface.new_socket(name = "Intensity", in_out='INPUT', socket_type = 'NodeSocketFloat')
    intensity_socket.default_value = 5
    intensity_socket.min_value = -100.0
    intensity_socket.max_value = 100.0
    intensity_socket.subtype = 'NONE'
    intensity_socket.attribute_domain = 'POINT'

    #Socket Hardness
    hardness_socket = _up_mask_fx.interface.new_socket(name = "Hardness", in_out='INPUT', socket_type = 'NodeSocketFloat')
    hardness_socket.default_value = -0.5
    hardness_socket.min_value = -20.0
    hardness_socket.max_value = 0.0
    hardness_socket.subtype = 'NONE'
    hardness_socket.attribute_domain = 'POINT'
    hardness_socket.description = "Usually a negative value"


    #initialize _up_mask_fx nodes
    #node Group Output
    group_output = _up_mask_fx.nodes.new("NodeGroupOutput")
    group_output.name = "Group Output"
    group_output.is_active_output = True

    #node Group Input
    group_input = _up_mask_fx.nodes.new("NodeGroupInput")
    group_input.name = "Group Input"

    #node Map Range
    map_range = _up_mask_fx.nodes.new("ShaderNodeMapRange")
    map_range.name = "Map Range"
    map_range.clamp = True
    map_range.data_type = 'FLOAT'
    map_range.interpolation_type = 'LINEAR'
    #To Min
    map_range.inputs[3].default_value = -2.9800000190734863
    #To Max
    map_range.inputs[4].default_value = 1.0

    #node Brightness/Contrast
    brightness_contrast = _up_mask_fx.nodes.new("ShaderNodeBrightContrast")
    brightness_contrast.name = "Brightness/Contrast"

    #node Invert Color
    invert_color = _up_mask_fx.nodes.new("ShaderNodeInvert")
    invert_color.name = "Invert Color"
    #Fac
    invert_color.inputs[0].default_value = 0.0

    #node Mix
    mix = _up_mask_fx.nodes.new("ShaderNodeMix")
    mix.name = "Mix"
    mix.blend_type = 'MIX'
    mix.clamp_factor = True
    mix.clamp_result = False
    mix.data_type = 'FLOAT'
    mix.factor_mode = 'UNIFORM'

    #node Reroute
    reroute = _up_mask_fx.nodes.new("NodeReroute")
    reroute.name = "Reroute"
    reroute.socket_idname = "NodeSocketBool"
    #node Reroute.001
    reroute_001 = _up_mask_fx.nodes.new("NodeReroute")
    reroute_001.name = "Reroute.001"
    reroute_001.socket_idname = "NodeSocketBool"
    #node Frame
    frame = _up_mask_fx.nodes.new("NodeFrame")
    frame.name = "Frame"
    frame.label_size = 20
    frame.shrink = True

    #node Reroute.002
    reroute_002 = _up_mask_fx.nodes.new("NodeReroute")
    reroute_002.name = "Reroute.002"
    reroute_002.socket_idname = "NodeSocketFloat"
    #node Reroute.003
    reroute_003 = _up_mask_fx.nodes.new("NodeReroute")
    reroute_003.name = "Reroute.003"
    reroute_003.socket_idname = "NodeSocketFloat"
    #node Mix.001
    mix_001 = _up_mask_fx.nodes.new("ShaderNodeMix")
    mix_001.name = "Mix.001"
    mix_001.blend_type = 'MIX'
    mix_001.clamp_factor = True
    mix_001.clamp_result = False
    mix_001.data_type = 'FLOAT'
    mix_001.factor_mode = 'UNIFORM'

    #node Reroute.004
    reroute_004 = _up_mask_fx.nodes.new("NodeReroute")
    reroute_004.name = "Reroute.004"
    reroute_004.socket_idname = "NodeSocketBool"
    #node Reroute.006
    reroute_006 = _up_mask_fx.nodes.new("NodeReroute")
    reroute_006.name = "Reroute.006"
    reroute_006.socket_idname = "NodeSocketFloatFactor"
    #node Reroute.007
    reroute_007 = _up_mask_fx.nodes.new("NodeReroute")
    reroute_007.name = "Reroute.007"
    reroute_007.socket_idname = "NodeSocketBool"
    #node Reroute.008
    reroute_008 = _up_mask_fx.nodes.new("NodeReroute")
    reroute_008.name = "Reroute.008"
    reroute_008.socket_idname = "NodeSocketFloatFactor"
    #node Reroute.009
    reroute_009 = _up_mask_fx.nodes.new("NodeReroute")
    reroute_009.name = "Reroute.009"
    reroute_009.socket_idname = "NodeSocketColor"
    #node Reroute.010
    reroute_010 = _up_mask_fx.nodes.new("NodeReroute")
    reroute_010.name = "Reroute.010"
    reroute_010.socket_idname = "NodeSocketFloat"
    #node Math
    math = _up_mask_fx.nodes.new("ShaderNodeMath")
    math.name = "Math"
    math.operation = 'MULTIPLY'
    math.use_clamp = False

    #node Invert Color.002
    invert_color_002 = _up_mask_fx.nodes.new("ShaderNodeInvert")
    invert_color_002.name = "Invert Color.002"
    #Fac
    invert_color_002.inputs[0].default_value = 1.0

    #node Invert Color.003
    invert_color_003 = _up_mask_fx.nodes.new("ShaderNodeInvert")
    invert_color_003.name = "Invert Color.003"
    #Fac
    invert_color_003.inputs[0].default_value = 1.0

    #Set parents
    group_output.parent = frame
    map_range.parent = frame
    brightness_contrast.parent = frame
    invert_color.parent = frame
    mix.parent = frame
    reroute_002.parent = frame
    reroute_003.parent = frame
    mix_001.parent = frame
    reroute_004.parent = frame
    reroute_006.parent = frame
    reroute_007.parent = frame
    reroute_008.parent = frame
    reroute_009.parent = frame
    reroute_010.parent = frame
    math.parent = frame
    invert_color_002.parent = frame
    invert_color_003.parent = frame

    #Set locations
    group_output.location = (1222.0, 236.0)
    group_input.location = (-320.0, 100.0)
    map_range.location = (222.0, 78.0)
    brightness_contrast.location = (39.9999885559082, -80.0)
    invert_color.location = (-120.0, -80.0)
    mix.location = (582.0, 58.0)
    reroute.location = (-120.0, 140.0)
    reroute_001.location = (380.0, 140.0)
    frame.location = (-2.0, 4.0)
    reroute_002.location = (380.0, 120.0)
    reroute_003.location = (-120.0, 120.0)
    mix_001.location = (1062.0, 238.0)
    reroute_004.location = (-98.0, 278.0)
    reroute_006.location = (-98.0, 158.0)
    reroute_007.location = (982.0, 276.0)
    reroute_008.location = (502.0, 158.0)
    reroute_009.location = (182.0, 96.0)
    reroute_010.location = (-78.0, 36.0)
    math.location = (582.0, 218.0)
    invert_color_002.location = (22.0, 116.0)
    invert_color_003.location = (742.0, 218.0)

    #Set dimensions
    group_output.width, group_output.height = 140.0, 100.0
    group_input.width, group_input.height = 140.0, 100.0
    map_range.width, map_range.height = 140.0, 100.0
    brightness_contrast.width, brightness_contrast.height = 140.0, 100.0
    invert_color.width, invert_color.height = 140.0, 100.0
    mix.width, mix.height = 140.0, 100.0
    reroute.width, reroute.height = 16.0, 100.0
    reroute_001.width, reroute_001.height = 16.0, 100.0
    frame.width, frame.height = 1550.0, 545.0
    reroute_002.width, reroute_002.height = 16.0, 100.0
    reroute_003.width, reroute_003.height = 16.0, 100.0
    mix_001.width, mix_001.height = 140.0, 100.0
    reroute_004.width, reroute_004.height = 16.0, 100.0
    reroute_006.width, reroute_006.height = 16.0, 100.0
    reroute_007.width, reroute_007.height = 16.0, 100.0
    reroute_008.width, reroute_008.height = 16.0, 100.0
    reroute_009.width, reroute_009.height = 16.0, 100.0
    reroute_010.width, reroute_010.height = 16.0, 100.0
    math.width, math.height = 140.0, 100.0
    invert_color_002.width, invert_color_002.height = 140.0, 100.0
    invert_color_003.width, invert_color_003.height = 140.0, 100.0

    #initialize _up_mask_fx links
    #group_input.Mask Input -> map_range.Value
    _up_mask_fx.links.new(group_input.outputs[2], map_range.inputs[0])
    #invert_color.Color -> brightness_contrast.Color
    _up_mask_fx.links.new(invert_color.outputs[0], brightness_contrast.inputs[0])
    #group_input.Offset -> brightness_contrast.Bright
    _up_mask_fx.links.new(group_input.outputs[4], brightness_contrast.inputs[1])
    #group_input.Intensity -> brightness_contrast.Contrast
    _up_mask_fx.links.new(group_input.outputs[5], brightness_contrast.inputs[2])
    #group_input.Displacement -> invert_color.Color
    _up_mask_fx.links.new(group_input.outputs[3], invert_color.inputs[1])
    #reroute_001.Output -> mix.Factor
    _up_mask_fx.links.new(reroute_001.outputs[0], mix.inputs[0])
    #group_input.Use Displacement Blending -> reroute.Input
    _up_mask_fx.links.new(group_input.outputs[0], reroute.inputs[0])
    #reroute.Output -> reroute_001.Input
    _up_mask_fx.links.new(reroute.outputs[0], reroute_001.inputs[0])
    #reroute_002.Output -> mix.A
    _up_mask_fx.links.new(reroute_002.outputs[0], mix.inputs[2])
    #reroute_003.Output -> reroute_002.Input
    _up_mask_fx.links.new(reroute_003.outputs[0], reroute_002.inputs[0])
    #group_input.Mask Input -> reroute_003.Input
    _up_mask_fx.links.new(group_input.outputs[2], reroute_003.inputs[0])
    #brightness_contrast.Color -> map_range.From Max
    _up_mask_fx.links.new(brightness_contrast.outputs[0], map_range.inputs[2])
    #map_range.Result -> mix.B
    _up_mask_fx.links.new(map_range.outputs[0], mix.inputs[3])
    #group_input.Hardness -> map_range.From Min
    _up_mask_fx.links.new(group_input.outputs[6], map_range.inputs[1])
    #mix.Result -> mix_001.A
    _up_mask_fx.links.new(mix.outputs[0], mix_001.inputs[2])
    #group_input.Is Opacity Mask -> reroute_004.Input
    _up_mask_fx.links.new(group_input.outputs[1], reroute_004.inputs[0])
    #group_input.Displacement -> reroute_006.Input
    _up_mask_fx.links.new(group_input.outputs[3], reroute_006.inputs[0])
    #reroute_007.Output -> mix_001.Factor
    _up_mask_fx.links.new(reroute_007.outputs[0], mix_001.inputs[0])
    #reroute_004.Output -> reroute_007.Input
    _up_mask_fx.links.new(reroute_004.outputs[0], reroute_007.inputs[0])
    #invert_color_002.Color -> reroute_009.Input
    _up_mask_fx.links.new(invert_color_002.outputs[0], reroute_009.inputs[0])
    #group_input.Mask Input -> reroute_010.Input
    _up_mask_fx.links.new(group_input.outputs[2], reroute_010.inputs[0])
    #mix_001.Result -> group_output.Mask Output
    _up_mask_fx.links.new(mix_001.outputs[0], group_output.inputs[0])
    #invert_color_003.Color -> mix_001.B
    _up_mask_fx.links.new(invert_color_003.outputs[0], mix_001.inputs[3])
    #reroute_009.Output -> math.Value
    _up_mask_fx.links.new(reroute_009.outputs[0], math.inputs[1])
    #reroute_008.Output -> math.Value
    _up_mask_fx.links.new(reroute_008.outputs[0], math.inputs[0])
    #reroute_010.Output -> invert_color_002.Color
    _up_mask_fx.links.new(reroute_010.outputs[0], invert_color_002.inputs[1])
    #reroute_006.Output -> reroute_008.Input
    _up_mask_fx.links.new(reroute_006.outputs[0], reroute_008.inputs[0])
    #math.Value -> invert_color_003.Color
    _up_mask_fx.links.new(math.outputs[0], invert_color_003.inputs[1])
    return _up_mask_fx

