'''
Copyright (C) 2024 CG Cookie
http://cgcookie.com
hello@cgcookie.com

Created by Jonathan Denning, Jonathan Lampel

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''

import blf
import bmesh
import bpy
import gpu
import os
from bmesh.types import BMVert, BMEdge, BMFace
from bpy_extras.view3d_utils import location_3d_to_region_2d
from mathutils import Vector, Matrix
from mathutils.bvhtree import BVHTree

import math
import time
from typing import List
from enum import Enum

from ..rftool_base import RFTool_Base
from ..common.bmesh import get_bmesh_emesh, NearestBMVert
from ..common.icons import get_path_to_blender_icon
from ..common.operator import invoke_operator, execute_operator, RFOperator, RFRegisterClass, chain_rf_keymaps, wrap_property
from ..common.raycast import raycast_point_valid_sources
from ..common.maths import view_forward_direction
from ...addon_common.common import bmesh_ops as bmops
from ...addon_common.common.blender_cursors import Cursors
from ...addon_common.common.resetter import Resetter
from ...addon_common.common.blender import get_path_from_addon_common
from ...addon_common.common import gpustate
from ...addon_common.common.colors import Color4
from ...addon_common.common.maths import clamp
from ...addon_common.common.utils import iter_pairs

from ..rfoperators.transform import RFOperator_Translate_ScreenSpace

from ..rfpanels.mesh_cleanup_panel import draw_cleanup_panel
from ..rfpanels.tweaking_panel import draw_tweaking_panel
from ..rfpanels.display_panel import draw_display_panel
from ..common.interface import draw_line_separator

from .polypen_logic import PP_Logic


class PolyPen_Insert_Modes:
    insert_modes = [
        # (identifier, name, description, icon, number)  or  (identifier, name, description, number)
        # must have number?
        # None is a separator
        ("VERT-ONLY", "Vertex", "Insert vertices only",           1),
        ("EDGE-ONLY", "Edge", "Insert edges only",                2),
        ("TRI-ONLY",  "Triangle",  "Insert triangles only",            3),  # 'MESH_DATA'
        ("TRI/QUAD",  "Tri/Quad",  "Insert triangles then quads", 0),
        ("QUAD-ONLY", "Quad", "Insert quads only",                4),
    ]
    insert_mode = 0

    rf_keymaps = []

    @staticmethod
    def generate_operators():
        ops_insert = []
        def gen_insert_mode(idname, label, value):
            nonlocal ops_insert
            rf_idname = f'retopoflow.polypen_setinsertmode_{idname.lower()}'
            rf_label = label
            class RFTool_OT_PolyPen_SetInsertMode(RFRegisterClass, bpy.types.Operator):
                bl_idname = rf_idname
                bl_label = rf_label
                bl_description = f'Set PolyPen Insert Mode to {label}'
                def execute(self, context):
                    PolyPen_Insert_Modes.set_insert_mode(None, value)
                    context.area.tag_redraw()
                    return {'FINISHED'}
            RFTool_OT_PolyPen_SetInsertMode.__name__ = f'RFTool_OT_PolyPen_SetInsertMode_{idname}'
            ops_insert += [(rf_idname, rf_label)]

        class VIEW3D_MT_PIE_PolyPen(RFRegisterClass, bpy.types.Menu):
            bl_label = 'Select PolyPen Insert Mode'

            def draw(self, context):
                nonlocal ops_insert
                layout = self.layout
                pie = layout.menu_pie()
                for bl_idname, bl_label in ops_insert:
                    pie.operator(bl_idname, text=bl_label) # icon='OBJECT_DATAMODE'
                # # 4 - LEFT
                # # 6 - RIGHT
                # # 2 - BOTTOM
                # # 8 - TOP
                # # 7 - TOP - LEFT
                # # 9 - TOP - RIGHT
                # # 1 - BOTTOM - LEFT
                # # 3 - BOTTOM - RIGHT
                # pie.separator()

        class RFTool_OT_Show_PolyPen_Pie(RFRegisterClass, bpy.types.Operator):
            bl_idname = 'retopoflow.polypen_setinsertmode_piemenu'
            bl_label = 'PolyPen Insert Mode Pie Menu'
            def execute(self, context):
                bpy.ops.wm.call_menu_pie(name="VIEW3D_MT_PIE_PolyPen")
                return {'FINISHED'}

        # gen_insert_mode('VertOnly', 'Vert-Only', 1)
        gen_insert_mode('EdgeOnly', 'Edge-Only', 2)
        gen_insert_mode('TriOnly',  'Tri-Only',  3)
        gen_insert_mode('TriQuad',  'Tri/Quad',  0)
        gen_insert_mode('QuadOnly', 'Quad-Only', 4)

        PolyPen_Insert_Modes.rf_keymaps += [
            (RFTool_OT_Show_PolyPen_Pie.bl_idname, {'type': 'ACCENT_GRAVE', 'shift': True, 'value': 'PRESS'}, None),
            (RFTool_OT_Show_PolyPen_Pie.bl_idname, {'type': 'Q', 'value': 'PRESS'}, None),
        ]

    @staticmethod
    def get_insert_mode(self): return PolyPen_Insert_Modes.insert_mode
    @staticmethod
    def set_insert_mode(self, v): PolyPen_Insert_Modes.insert_mode = v

# TODO: DO NOT CALL THIS HERE!  SHOULD ONLY GET CALLED ONCE
#       COULD POTENTIALLY CREATE MULTIPLE OPERATORS WITH SAME NAME
PolyPen_Insert_Modes.generate_operators()


class RFOperator_PolyPen(RFOperator):
    bl_idname = "retopoflow.polypen"
    bl_label = 'PolyPen'
    bl_description = 'Create complex topology on vertex-by-vertex basis'
    bl_space_type = "VIEW_3D"
    bl_region_type = "TOOLS"
    bl_options = set()

    rf_keymaps = [
        (bl_idname, {'type': 'LEFT_CTRL',  'value': 'PRESS'}, None),
        (bl_idname, {'type': 'RIGHT_CTRL', 'value': 'PRESS'}, None),
        # below is needed to handle case when CTRL is pressed when mouse is initially outside area
        (bl_idname, {'type': 'MOUSEMOVE', 'value': 'ANY', 'ctrl': True}, None),
    ]
    rf_status = ['LMB: Insert', 'MMB: (nothing)', 'RMB: (nothing)']

    insert_mode: wrap_property(
        PolyPen_Insert_Modes, 'insert_mode', 'enum',
        name='Insert Mode',
        description='Insertion mode for PolyPen',
        items=PolyPen_Insert_Modes.insert_modes,
    )
    quad_stability: bpy.props.FloatProperty(
        name='Quad Stability',
        description='Stability of parallel edges',
        min=0.00,
        max=1.00,
        default=1.00,
    )

    def init(self, context, event):
        # print(f'STARTING POLYPEN')
        self.logic = PP_Logic(context, event)
        self.tickle(context)
        self.done = False

    def reset(self):
        self.logic.reset()

    def update(self, context, event):
        if not event.ctrl:
            self.done = True
        if self.done:
            if not self.is_active():
                # wait until we're active (could happen when transforming)
                return {'PASS_THROUGH'}
            self.logic.cleanup()
            return {'FINISHED'}

        self.logic.update(context, event, self.insert_mode, self.quad_stability)

        if event.type == 'LEFTMOUSE' and event.value == 'PRESS':
            self.logic.commit(context, event)
            return {'RUNNING_MODAL'}

        if event.type == 'MOUSEMOVE':
            context.area.tag_redraw()
            # must return RUNNING_MODAL, otherwise PP will get started over and over
            # again due to CTRL+MOUSEMOVE is a keymap to launch PP
            return {'RUNNING_MODAL'}

        return {'PASS_THROUGH'} # allow other operators, such as UNDO!!!

    def draw_postpixel(self, context):
        if not self.RFCore.is_current_area(context): return
        self.logic.draw(context)



class RFTool_PolyPen(RFTool_Base):
    bl_idname = "retopoflow.polypen"
    bl_label = "Poly Pen"
    bl_description = "Create complex topology on vertex-by-vertex basis"
    bl_icon = get_path_to_blender_icon('polypen')
    bl_widget = None
    bl_operator = 'retopoflow.polypen'

    bl_keymap = chain_rf_keymaps(
        RFOperator_PolyPen,
        RFOperator_Translate_ScreenSpace,
        PolyPen_Insert_Modes,
    )

    def draw_settings(context, layout, tool):
        props_polypen = tool.operator_properties(RFOperator_PolyPen.bl_idname)

        if context.region.type == 'TOOL_HEADER':
            layout.prop(props_polypen, 'insert_mode', text='Insert')
            if props_polypen.insert_mode == 'QUAD-ONLY':
                layout.prop(props_polypen, 'quad_stability', slider=True)
            draw_line_separator(layout)
            layout.popover('RF_PT_TweakCommon')
            row = layout.row(align=True)
            row.popover('RF_PT_MeshCleanup', text='Clean Up')
            row.operator("retopoflow.meshcleanup", text='', icon='PLAY')
            layout.popover('RF_PT_Display', text='', icon='OPTIONS')

        else:
            header, panel = layout.panel(idname='polypen_insert_panel', default_closed=False)
            header.label(text="Insert")
            if panel:
                panel.prop(props_polypen, 'insert_mode', text='Method')
                if props_polypen.insert_mode == 'QUAD-ONLY':
                    panel.prop(props_polypen, 'quad_stability', slider=True)
            draw_tweaking_panel(context, layout)
            draw_cleanup_panel(context, layout)
            draw_display_panel(context, layout)

    @classmethod
    def activate(cls, context):
        # TODO: some of the following might not be needed since we are creating our
        #       own transform operators
        cls.resetter = Resetter("PolyPen")
        cls.resetter['context.tool_settings.use_mesh_automerge'] = True
        # cls.resetter['context.tool_settings.double_threshold'] = 0.01
        # cls.resetter['context.tool_settings.snap_elements_base'] = {'VERTEX'}
        cls.resetter.store('context.tool_settings.snap_elements_base')
        cls.resetter['context.tool_settings.snap_elements_individual'] = {'FACE_PROJECT', 'FACE_NEAREST'}
        cls.resetter['context.tool_settings.mesh_select_mode'] = [True, True, False]

    @classmethod
    def deactivate(cls, context):
        cls.resetter.reset()
