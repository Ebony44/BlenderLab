'''MIT License

Copyright (c) 2026 Dean Zarkov

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.'''

import bpy
import bpy.utils.previews
import os
import json
from textwrap import wrap
from random import uniform, randint
from bpy.app.handlers import persistent
from .shp_modifier_data import SHP_DATA as sd
from .shp_tips_data import SHP_TIPS as st
from .shp_tutorial_data import SHP_TUTORIAL_STEPS as sts
from .shp_node_groups import SHP_NODE_GROUPS as sng


# ADD-ON PARAMETERS
shp_modifier_name = "Stylized Hair PRO v4"
shp_shades_group_name = "SHP Shades"
shp_required_blender_version = [5, 2, 0]
shp_addon_version = [4, 3, 1]
shp_preview_collections = {}    # Icons preview collection
shp_last_active_obj = None      # Active object cache for handler optimization
shp_last_mode = 'OBJECT'        # Mode cache for handler optimization
shp_user_presets = []           # List with all user defined presets
shp_inputs_count_change = 2     # Number of sockets added/remove from the shp modifier in this version
dt_main_panel = 'DT_PT_geo_tools'

tutorial_step_items = []        # Tutorial steps list for the 'tutorial_steps' custom prop
for step_index, step in enumerate(sts):
    tutorial_step_items.append((f'STEP_{step_index}', f"Step {step_index}: {step[0]}", ""))


# SETUP FUNCTIONS
def shp_get_spline_count(curve):
    spline_count = 0
    if curve:
        if curve.type == 'CURVE':
            spline_count = len(curve.data.splines)
        elif curve.type == 'CURVES':
            spline_count = len(curve.data.curves)
    return spline_count

def shp_add_setup(all=True, set_scale=True):
    shp_props = bpy.context.scene.shp_addon
    
    # Halt the "Set modifier Active" function
    halt_setting = shp_props.halt_set_active_modifier_function
    shp_props.halt_set_active_modifier_function = True
    
    # If hair curve, set it's radius to 1.0
    obj = bpy.context.object
    if obj:
        if obj.type == 'CURVES':
            for curve in obj.data.curves:
                for point in curve.points:
                    point.radius = 1.0

    # Assets Path
    blend_file_path = os.path.join(os.path.dirname(__file__), "SHP_assets.blend")

    # Append the GN node group
    if shp_modifier_name not in bpy.data.node_groups:
        with bpy.data.libraries.load(blend_file_path, link=False) as (data_from, data_to):
            if shp_modifier_name in data_from.node_groups:
                data_to.node_groups = [shp_modifier_name]

    # Append the SHADER node group
    if shp_shades_group_name not in bpy.data.node_groups:
        with bpy.data.libraries.load(blend_file_path, link=False) as (data_from, data_to):
            if shp_shades_group_name in data_from.node_groups:
                data_to.node_groups = [shp_shades_group_name]
    
    # Set fake user
    if shp_modifier_name in bpy.data.node_groups:
        bpy.data.node_groups[shp_modifier_name].use_fake_user = True
    if shp_shades_group_name in bpy.data.node_groups:
        bpy.data.node_groups[shp_shades_group_name].use_fake_user = True

    # Check if the node group modifier exists in bpy.context.object.modifiers
    if all:
        for hair_curve in bpy.context.selected_objects:
            bpy.context.view_layer.objects.active = hair_curve # Set the curve as the active object
            if shp_modifier_name not in hair_curve.modifiers:
                # Check if the active object is a curve
                if hair_curve and hair_curve.type in {'CURVE', 'CURVES'}:
                    bpy.ops.object.modifier_add(type='NODES')
                    hair_curve.modifiers.active.name = shp_modifier_name
                    hair_curve.modifiers.active.node_group = bpy.data.node_groups[shp_modifier_name]
                    hair_curve.modifiers.active.show_group_selector = False
                    hair_curve.modifiers.active.show_expanded = False
                    if set_scale and shp_get_spline_count(hair_curve):
                        scale_factor = shp_get_curve_avg_length(hair_curve)
                        shp_set_value('internal_utils', 'iu_scale_factor', scale_factor, hair_curve)
                        
                else:
                    print("The active object is not a curve. Select a curve object.")
            else:
                print(f"The node group modifier '{shp_modifier_name}' already exists.")
    else:
        hair_curve = bpy.context.object
        if hair_curve:
            if shp_modifier_name not in hair_curve.modifiers:
            # Check if the active object is a curve
                if hair_curve.type in {'CURVE', 'CURVES'}:
                    bpy.ops.object.modifier_add(type='NODES')
                    hair_curve.modifiers.active.name = shp_modifier_name
                    hair_curve.modifiers.active.node_group = bpy.data.node_groups[shp_modifier_name]
                    hair_curve.modifiers.active.show_group_selector = False
                    if set_scale and shp_get_spline_count(hair_curve):
                        scale_factor = shp_get_curve_avg_length(hair_curve)
                        shp_set_value('internal_utils', 'iu_scale_factor', scale_factor, hair_curve)
    
    # Restore the Halt "Set modifier Active" function setting value
    shp_props.halt_set_active_modifier_function = halt_setting

def shp_remove_setup():
    for hair_curve in bpy.context.selected_objects:
        bpy.context.view_layer.objects.active = hair_curve # Set the curve as the active object
        if hair_curve and hair_curve.type in {'CURVE', 'CURVES'} and shp_modifier_name in hair_curve.modifiers:
            bpy.ops.object.modifier_remove(modifier=shp_modifier_name)

def shp_add_curve(length_factor, points_count, context):
    if context.object and not context.object.hide_get()and not context.object.hide_viewport:
        bpy.ops.object.mode_set(mode='OBJECT')
        if context.object.type == 'MESH':
            size = list(context.object.dimensions)
            scale = list(context.object.scale)
            dims = [size[i]/scale[i] for i in range(3)]
            average_size = (sum(dims) - max(dims)) / 2
            bpy.ops.object.curves_empty_hair_add(align='WORLD', location=(0, 0, 0), scale=(1, 1, 1))
            context.object.name = "Hair Strand"
            for modifier in context.object.modifiers:   # Remove "Surface Deform" Modifier
                bpy.ops.object.modifier_remove(modifier=modifier.name)

        if context.object.type == 'CURVES':
            bpy.ops.object.mode_set(mode='SCULPT_CURVES')
            bpy.ops.wm.tool_set_by_id(name="builtin_brush.add", space_type='VIEW_3D')
            
            brush = bpy.context.tool_settings.curves_sculpt.brush.curves_sculpt_settings

            brush.use_length_interpolate = False
            brush.use_radius_interpolate = False
            brush.use_point_count_interpolate = False
            brush.curve_length = round(average_size * length_factor, 2) # 1.618
            brush.curve_radius = 1.0
            brush.points_per_curve = points_count

def shp_add_presets_file():
    file_path = bpy.utils.user_resource('SCRIPTS', path="presets")
    
    # Create the full path for the new folder
    presets_folder_path = os.path.join(file_path, "shp_hair_presets")
    
    # Create the directory if it doesn't exist
    if not os.path.exists(presets_folder_path):
        os.makedirs(presets_folder_path)
        
    presets_file_path = os.path.join(presets_folder_path, "shp_presets_user_defined.json")
    data = []

    if not os.path.exists(presets_file_path):
        with open(presets_file_path, 'w') as f:
            json.dump(data, f, indent=4)

def shp_remove_all_groups():
    for group_name in sng:
        try:
            bpy.data.node_groups.remove(bpy.data.node_groups[group_name])
        except Exception:
            pass

def shp_get_objects():
    shp_objects = []
    for obj in bpy.data.objects:
        if shp_modifier_name in obj.modifiers:
            shp_objects.append(obj)
    return shp_objects

def shp_get_node_tree_version(output_type='LIST'):
    if shp_modifier_name in bpy.data.node_groups:
        version_string = bpy.data.node_groups[shp_modifier_name].description
        if not version_string:
            version_string = "v4.0.0"
        if output_type == 'STR':
            return version_string.strip("v")
        elif output_type == 'INT':
            return int(version_string.strip("v").replace(".", ""))
        elif output_type == 'LIST':
            return [int(num) for num in version_string.strip("v").split(".")]

            
# VALUE FUNCTIONS
def get_ui_width():
    width = 0
    for area in bpy.context.screen.areas:
        if area.type == 'VIEW_3D':
            for region in area.regions:
                if region.type == 'UI':
                    width = region.width
    return width

def split_string(text, max_length=40, first_line_subtract=0):
    first_line = wrap(text, width=max(max_length - first_line_subtract, 1))[0]

    remaining_text = text[len(first_line):].lstrip()
    remaining_lines = wrap(remaining_text, width=40)

    return [first_line] + remaining_lines

def remap_value(value, from_min, from_max, to_min, to_max, clamp=False):
    mapped_value = (value - from_min) / (from_max - from_min) * (to_max - to_min) + to_min
    return max(to_min, min(mapped_value, to_max)) if clamp else mapped_value


# UI/DRAW FUNCTIONS
def shp_input(identifier):
    return f'["{bpy.utils.escape_identifier(identifier)}"]'

def shp_draw(space, section, setting, label, icon='NONE', expand=False, toggle=False):
    obj = bpy.context.object
    modf = obj.modifiers[shp_modifier_name]
    modf_inputs = modf.properties.inputs
    socket_id = sd[section][setting][0]
    socket_prop = getattr(modf_inputs, socket_id)
    if hasattr(socket_prop, "value"):
        space.prop(socket_prop, "value", text=label, icon=icon, expand=expand, toggle=toggle)

def shp_draw_global(space, setting, label, icon='NONE', icon_value=0, expand=False, toggle=False):
    space.prop(bpy.data.node_groups[shp_modifier_name].nodes['shp_shell'].inputs[sd['global_settings'][setting][0]], "default_value", text=label, icon=icon, icon_value=icon_value, expand=expand, toggle=toggle)

def shp_draw_split_global(space, setting, label, label_width, text="", enabled=True):
    row = space.row(align=False)
    row.enabled = enabled
    sub = row.row()
    sub.alignment='RIGHT'
    sub.ui_units_x = label_width
    sub.label(text=label)
    sub = row.row()
    shp_draw_global(sub, setting, text)

def shp_draw_double_row(space, section, label, setting1, setting2, label_width=1.0, enable_1=True, enable_2=True):
    # obj = bpy.context.object
    row = space.row(align=False)
    sub = row.row()
    sub.alignment = 'RIGHT'
    sub.ui_units_x = label_width
    sub.enabled = enable_1 or enable_2
    sub.label(text=label)
    sub2 = row.row()
    sub2.enabled = enable_1
    shp_draw(sub2, section, setting1, label="")
    # sub2.prop(obj.modifiers[shp_modifier_name], shp_input(sd[section][setting1][0]), text="")
    sub3 = row.row()
    sub3.enabled = enable_2
    shp_draw(sub3, section, setting2, label="")
    # sub3.prop(obj.modifiers[shp_modifier_name], shp_input(sd[section][setting2][0]), text="")

def shp_draw_double_label(space, label1, label2, head_width=1.0):
    row = space.row(align=False)
    sub = row.row()
    sub.alignment = 'RIGHT'
    sub.ui_units_x = head_width
    sub.label(text="")
    sub2 = row.row()
    sub2.label(text=label1)
    sub3 = row.row()
    sub3.label(text=label2)

def shp_draw_sub_row(space, section, setting1, setting2, label1, label2, enabled=True):
    # obj = bpy.context.object
    row = space.row(align=False)
    row.enabled = enabled
    shp_draw(row, section, setting1, label=label1)
    # row.prop(obj.modifiers[shp_modifier_name], shp_input(sd[section][setting1][0]), text=label1)
    sub = row.row(align=False)
    sub.scale_x = 0.7
    shp_draw(sub, section, setting2, label=label2)
    # sub.prop(obj.modifiers[shp_modifier_name], shp_input(sd[section][setting2][0]), text=label2)

def shp_draw_split(space, section, setting, label, label_width, text="", enabled=True, expand=False, toggle=False, hl=None):
    # obj = bpy.context.object
    row = space.row(align=False)
    row.enabled = enabled
    sub = row.row()
    sub.alignment='RIGHT'
    sub.ui_units_x = label_width
    sub.label(text=label)
    sub = row.row()
    shp_draw(sub, section, setting, label=text, expand=expand, toggle=toggle)
    # sub.prop(obj.modifiers[shp_modifier_name], shp_input(sd[section][setting][0]), text=text, expand=expand, toggle=toggle)

def shp_draw_prop_search(space, section, setting, data_type, data_search=None, text="", split_label=False, label="", label_width=3, icon='AUTO'):
    obj = bpy.context.object
    modf = obj.modifiers[shp_modifier_name]
    modf_inputs = modf.properties.inputs
    socket_id = sd[section][setting][0]
    socket_prop = getattr(modf_inputs, socket_id)
    
    prop_space = space
    if split_label:
        row = space.row(align=False)
        sub = row.row()
        sub.alignment='RIGHT'
        sub.ui_units_x = label_width
        sub.label(text=label)
        prop_space = row.row()
    if data_type == 'MAT':
        prop_space.prop_search(socket_prop, "value", bpy.data if not data_search else data_search, "materials", text=text, icon='MATERIAL' if icon == 'AUTO' else icon)
    elif data_type == 'COL':
        prop_space.prop_search(socket_prop, "value", bpy.data if not data_search else data_search, "collections", text=text, icon='OUTLINER_COLLECTION' if icon == 'AUTO' else icon)
    elif data_type == 'OBJ':
        prop_space.prop_search(socket_prop, "value", bpy.data if not data_search else data_search, "objects", text=text, icon='OBJECT_DATAMODE' if icon == 'AUTO' else icon)
    elif data_type == 'UV':
        prop_space.prop_search(socket_prop, "value", bpy.data if not data_search else data_search, "uv_layers", text=text, icon='GROUP_UVS' if icon == 'AUTO' else icon)
        
def shp_draw_shape_factor(space, section, setting, label1="Shape Factor", label2="Contrast"):
    obj = bpy.context.object
    sf_setting = f"{setting}_shape_factor"
    c_setting = f"{setting}_contrast"
    
    row = space.row(align=False)
    sub = row.column(align=True)
    sub.label(text=f"{label1}:")
    shp_draw(sub, section, sf_setting, label="Root ⟷ Tip")
    # sub.prop(obj.modifiers[shp_modifier_name], shp_input(sd[section][sf_setting][0]), text="Root ⟷ Tip")
    sub = row.column(align=True)
    sub.scale_x = 0.7
    sub.label(text=f"{label2}:")
    shp_draw(sub, section, c_setting, label="")
    # sub.prop(obj.modifiers[shp_modifier_name], shp_input(sd[section][c_setting][0]), text="")

def shp_draw_random_seed(space, section, setting, label, text="Off ⟷ Max"):
    obj = bpy.context.object
    rnd_setting = f"{setting}_random"
    seed_setting = f"{setting}_seed"
        
    row = space.row(align=False)
    sub = row.column(align=True)
    sub.label(text=label)
    shp_draw(sub, section, rnd_setting, label=text)
    # sub.prop(obj.modifiers[shp_modifier_name], shp_input(sd[section][rnd_setting][0]), text=text)
    sub = row.column(align=True)
    sub.scale_x = 0.7
    sub.label(text="Seed")
    shp_draw(sub, section, seed_setting, label="")
    # sub.prop(obj.modifiers[shp_modifier_name], shp_input(sd[section][seed_setting][0]), text="")

def shp_draw_main_section_header(space, section, text, randomize=False, hl_1=False, hl_2=False):
    pcoll = shp_preview_collections["main"]
    
    flow = space.grid_flow(row_major=True, columns=2, even_columns=True, even_rows=True, align=False)
    row = flow.row(align=False)
    if randomize:
        row.operator("wm.shp_randomize_section", text="", icon_value=pcoll["shp_icon_random"].icon_id).settings_set = section
    row.label(text=f"{text}:")
    row = flow.row(align=False)
    sub = row.row(align=False)
    sub.alert = hl_1
    sub.operator("wm.shp_copy_section", text="Copy", icon_value=pcoll["shp_icon_copy_section"].icon_id).sec_id = section
    sub = row.row(align=False)
    sub.alert = hl_2
    sub.operator("wm.shp_reset_sections", text="Reset", icon_value=pcoll["shp_icon_refresh_settings"].icon_id).section = section

def shp_draw_sub_section_header(space, sub_section, text, randomize=False, hl_1=False, hl_2=False):
    pcoll = shp_preview_collections["main"]
    
    flow = space.grid_flow(row_major=True, columns=2, even_columns=True, even_rows=True, align=False)
    row = flow.row(align=False)
    if randomize:
        row.operator("wm.shp_randomize_section", text="", icon_value=pcoll["shp_icon_random"].icon_id).settings_set = sub_section
    row.label(text=f"{text}:")
    row = flow.row(align=False)
    sub = row.row(align=False)
    sub.alert = hl_1
    sub.operator("wm.shp_copy_sub_section", text="Copy", icon_value=pcoll["shp_icon_copy_section"].icon_id).sec_id = sub_section
    sub = row.row(align=False)
    sub.alert = hl_2
    sub.operator("wm.shp_reset_section", text="Reset", icon_value=pcoll["shp_icon_refresh_settings"].icon_id).section = sub_section

def shp_draw_multiline_text(text, space, max_chars=40, first_line_subtract=0, enabled=False, y_scale=1.0, icon=None):
    text_col = space.column(align=True)
    text_col.enabled = enabled
    text_col.scale_y = y_scale

    text_list = split_string(text, max_chars, first_line_subtract)
    
    for label_index, label in enumerate(text_list):
        if label_index == 0:
            text_col.label(text=label, icon=icon if icon else 'NONE')
        else:
            text_col.label(text=label)

def shp_draw_tips(space, tip_id):
    # ui_width = get_ui_width()
    # max_chars = max(30, round(ui_width / 15))
    max_chars = 40
    
    col = space.column(align=True)
    col.enabled = False
    label_index = 0
    tip_text = split_string(f"TIP:  {st[tip_id]}", max_chars)
    for label in tip_text:
        if label_index == 0:
            col.label(text=label, icon='INFO')
        else:
            col.label(text=label)
        label_index += 1
    # col.label(text=f"Character per line: {max_chars}")

def shp_show_info_popup(title="Stylized Hair PRO", text="", icon='INFO'):
    bpy.context.window_manager.popup_menu(
        lambda self, context: self.layout.label(text=text),
        title=title,
        icon=icon
    )


# READ/WRITE FUNCTIONS
def shp_read_value(section, setting, curve):
    if curve and shp_modifier_name in curve.modifiers:
        modf = curve.modifiers[shp_modifier_name]
        modf_inputs = modf.properties.inputs
        socket_id = sd[section][setting][0]
        socket_prop = getattr(modf_inputs, socket_id)
        socket_value = getattr(socket_prop, "value")
        return socket_value
        # return curve.modifiers[shp_modifier_name][sd[section][setting][0]]

def shp_read_value_global(setting):
    if shp_modifier_name in bpy.data.node_groups:
        if shp_get_node_tree_version(output_type='INT') < 415:
            return bpy.data.node_groups[shp_modifier_name].nodes['shp_shell'].inputs[sd['global_settings'][setting][0] - shp_inputs_count_change].default_value
        else:
            return bpy.data.node_groups[shp_modifier_name].nodes['shp_shell'].inputs[sd['global_settings'][setting][0]].default_value

def shp_set_value(section, setting, value, curve):
    if curve and shp_modifier_name in curve.modifiers:
        modf = curve.modifiers[shp_modifier_name]
        modf_inputs = modf.properties.inputs
        socket_id = sd[section][setting][0]
        socket_prop = getattr(modf_inputs, socket_id)
        setattr(socket_prop, "value", value)
        # curve.modifiers[shp_modifier_name][sd[section][setting][0]] = value

def shp_set_value_global(setting, value):
    if shp_modifier_name in bpy.data.node_groups:
        if shp_get_node_tree_version(output_type='INT') < 415:
            bpy.data.node_groups[shp_modifier_name].nodes['shp_shell'].inputs[sd['global_settings'][setting][0] - shp_inputs_count_change].default_value = value
        else:
            bpy.data.node_groups[shp_modifier_name].nodes['shp_shell'].inputs[sd['global_settings'][setting][0]].default_value = value

def shp_reset_section(section, curve):
    if shp_modifier_name in curve.modifiers:
        if section in sd.keys():
            for setting in sd[section].keys():
                value = sd[section][setting][1]
                shp_set_value(section, setting, value, curve)
                # curve.modifiers[shp_modifier_name][sd[section][setting][0]] = sd[section][setting][1]

def shp_reset_multiple_sections(sections, curve, all_sections=False):
    if shp_modifier_name in curve.modifiers:
        if all_sections:
            for section_group in sd['sub_sections'].keys():
                for section in sd['sub_sections'][section_group]:
                    for setting in sd[section].keys():
                        value = sd[section][setting][1]
                        shp_set_value(section, setting, value, curve)
                        # curve.modifiers[shp_modifier_name][sd[section][setting][0]] = sd[section][setting][1]
        else:
            if sections in sd['sub_sections'].keys():
                for section in sd['sub_sections'][sections]:
                    for setting in sd[section].keys():
                        value = sd[section][setting][1]
                        shp_set_value(section, setting, value, curve)
                        # curve.modifiers[shp_modifier_name][sd[section][setting][0]] = sd[section][setting][1]

def shp_randomize_setting(section, setting, curve, min=0.0, max=1.0, int=False):
    current_value = shp_read_value(section, setting, curve)
    set_value = current_value
    
    if int:
        set_value = randint(min, max)
    else:
        set_value = uniform(min, max)
    
    shp_set_value(section, setting, set_value, curve)

def shp_get_inputs(object):
    if shp_modifier_name in object.modifiers:
        modifier = object.modifiers[shp_modifier_name]
        input_sockets = {}
        for item in bpy.data.node_groups[shp_modifier_name].interface.items_tree:
            if item.item_type == 'SOCKET':
                if item.in_out == 'INPUT':
                    if item.socket_type != 'NodeSocketGeometry':
                        modf_input = getattr(modifier.properties.inputs, item.identifier, None)
                        if item.socket_type in {'NodeSocketVector', 'NodeSocketColor'}:
                            input_sockets[item.identifier] = list(modf_input.value)
                        else:
                            input_sockets[item.identifier] = modf_input.value
        return input_sockets

def shp_set_inputs(object, inputs):
    if shp_modifier_name in object.modifiers:
        modf = object.modifiers[shp_modifier_name]
        modf_inputs = modf.properties.inputs
        for input in inputs.keys():
            socket_id = input
            socket_prop = getattr(modf_inputs, socket_id)
            setattr(socket_prop, "value", inputs[input])
            
            # modifier[input] = inputs[input]


# PRESETS FUNCTIONS
def shp_get_sections_to_preset(include_all, context):
    shp_props = context.scene.shp_addon
    if include_all:
        preset_sections = ['shape', 'twist', 'bumps', 'curls', 'braid', 'frizz', 'profile', 'ornaments', 'dynamics', 'shading', 'settings', 'utilities']
    else:
        preset_sections = [
            name for attr, name in [
                (shp_props.sec_shape, "shape"),
                (shp_props.sec_twist, "twist"),
                (shp_props.sec_bumps, "bumps"),
                (shp_props.sec_curls, "curls"),
                (shp_props.sec_braid, "braid"),
                (shp_props.sec_frizz, "frizz"),
                (shp_props.sec_profile, "profile"),
                (shp_props.sec_ornaments, "ornaments"),
                (shp_props.sec_dynamics, "dynamics"),
                (shp_props.sec_shading, "shading"),
                (shp_props.sec_settings, "settings"),
                (shp_props.sec_utilities, "utilities"),
            ] if attr
        ]
    return preset_sections

def shp_select_all_sections(value, context):
    shp_props = context.scene.shp_addon
    shp_props.sec_shape = value
    shp_props.sec_twist = value
    shp_props.sec_bumps = value
    shp_props.sec_curls = value
    shp_props.sec_braid = value
    shp_props.sec_frizz = value
    shp_props.sec_profile = value
    shp_props.sec_ornaments = value
    shp_props.sec_dynamics = value
    shp_props.sec_shading = value
    shp_props.sec_settings = value
    shp_props.sec_utilities = value

def shp_save_preset(context):
    shp_props = context.scene.shp_addon
    obj = context.active_object
    preset_name = shp_props.preset_name
    all_sections = shp_props.sec_all
    
    if obj:
        if preset_name:
            if shp_modifier_name in obj.modifiers:
                file_path = bpy.utils.user_resource('SCRIPTS', path="presets")
                presets_folder_path = os.path.join(file_path, "shp_hair_presets")
                presets_file_path = os.path.join(presets_folder_path, "shp_presets_user_defined.json")
                
                new_entry = {"preset_name": preset_name}
                sec_groups = shp_get_sections_to_preset(include_all=all_sections, context=context)  # Sections to include
                for sec_group in sec_groups:
                    for sub_sec in sd['sub_sections'][sec_group]:
                        for setting in sd[sub_sec].keys():
                            if sd[sub_sec][setting][4]:     # Setting is preset-able
                                setting_socket = sd[sub_sec][setting][0]
                                setting_value = shp_read_value(sub_sec, setting, obj)
                                if isinstance(setting_value, float):
                                    new_entry[setting_socket] = round(setting_value, 3)
                                elif isinstance(setting_value, int):
                                    new_entry[setting_socket] = setting_value
                                elif isinstance(setting_value, bool):
                                    new_entry[setting_socket] = setting_value
                                elif isinstance(setting_value, str):
                                    new_entry[setting_socket] = setting_value
                                else:
                                    new_entry[setting_socket] = list(setting_value)    # For vector and color settings
                
                if os.path.exists(presets_file_path):
                    with open(presets_file_path, 'r') as f:
                        try:
                            presets_data = json.load(f)
                            if not isinstance(presets_data, list):
                                presets_data = []
                        except json.JSONDecodeError:
                            presets_data = []
                else:
                    presets_data = []

                # Check if the preset already has an entry, update if yes
                updated = False
                for entry in presets_data:
                    if entry.get("preset_name") == preset_name:
                        entry.update(new_entry)
                        updated = True
                        break

                # If no existing entry found, append new
                if not updated:
                    presets_data.append(new_entry)

                with open(presets_file_path, 'w') as f:
                    json.dump(presets_data, f, indent=4)
                shp_show_info_popup(text=f'Preset "{preset_name}" saved.')
            else:
                shp_show_info_popup(text='Object has no "Stylized Hair PRO" modifier')
        else:
            shp_show_info_popup(text="No name set. Enter a name for the preset.")
    else:
        shp_show_info_popup(text="No active object selected.")
        
def shp_remove_preset(context):
    preset_name = context.scene.shp_addon.selected_preset
    
    if preset_name:
        presets_folder_path = bpy.utils.user_resource('SCRIPTS', path="presets")
        presets_file_path = os.path.join(presets_folder_path, "shp_hair_presets", "shp_presets_user_defined.json")

        if os.path.exists(presets_file_path):
            with open(presets_file_path, 'r') as f:
                presets_data = json.load(f)     # Get the presets data

        # Filter out the preset to remove
        presets_data = [entry for entry in presets_data if entry.get("preset_name") != preset_name]
        
        # Write back the presets data
        with open(presets_file_path, 'w') as file:
            json.dump(presets_data, file, indent=4)
        shp_show_info_popup(text=f'Preset "{preset_name}" removed.')
    else:
        pass

def shp_preset_exits(preset_name, context):
    if preset_name:
        presets_folder_path = bpy.utils.user_resource('SCRIPTS', path="presets")
        presets_file_path = os.path.join(presets_folder_path, "shp_hair_presets", "shp_presets_user_defined.json")

        if os.path.exists(presets_file_path):
            with open(presets_file_path, 'r') as f:
                presets_data = json.load(f)     # Get the presets data

            for entry in presets_data:
                if preset_name == entry.get("preset_name"):
                    return True
        return False

def shp_load_presets():
    global shp_user_presets
    presets_folder_path = bpy.utils.user_resource('SCRIPTS', path="presets")
    presets_file_path = os.path.join(presets_folder_path, "shp_hair_presets", "shp_presets_user_defined.json")

    if os.path.exists(presets_file_path):
        with open(presets_file_path, 'r') as f:
            presets_data = json.load(f)     # Get the presets data

        shp_user_presets = []   # Reset the presets list
        for entry in presets_data:
            shp_user_presets.append(entry.get("preset_name"))
    return shp_user_presets

def shp_apply_preset(preset_type, context):
    shp_props = context.scene.shp_addon
    # obj = context.active_object
    default_preset_name = shp_props.default_presets
    preset_name = shp_props.selected_preset
    
    for obj in context.selected_objects:
        if obj:
            if preset_type:
                if shp_modifier_name in obj.modifiers:
                    default_presets_file_path = os.path.join(os.path.dirname(__file__), "shp_presets_default.json")
                    with open(default_presets_file_path, 'r') as f:
                        presets_data = json.load(f)
                    
                    for entry in presets_data:
                        if entry.get("preset_name") == default_preset_name:
                            entry.pop("preset_name")
                            preset_values = entry
                            break
                    
                    for socket in preset_values.keys():
                        modf_input = getattr(obj.modifiers[shp_modifier_name].properties.inputs, socket)
                        try:
                            setattr(modf_input, "value", preset_values.get(socket))
                        except Exception:
                            print(socket)
            else:
                if preset_name:
                    if shp_preset_exits(preset_name, context):
                        if shp_modifier_name in obj.modifiers:
                            file_path = bpy.utils.user_resource('SCRIPTS', path="presets")
                            presets_folder_path = os.path.join(file_path, "shp_hair_presets")
                            presets_file_path = os.path.join(presets_folder_path, "shp_presets_user_defined.json")
                        
                            # Load the presets data
                            if os.path.exists(presets_file_path):
                                with open(presets_file_path, 'r') as f:
                                    presets_data = json.load(f)
                            
                            for entry in presets_data:
                                if entry.get("preset_name") == preset_name:
                                    entry.pop("preset_name")
                                    preset_values = entry
                                    break
                            
                            for socket in preset_values.keys():
                                modf_input = getattr(obj.modifiers[shp_modifier_name].properties.inputs, socket)
                                try:
                                    setattr(modf_input, "value", preset_values.get(socket))
                                except Exception:
                                    print(socket)
                                # obj.modifiers[shp_modifier_name][socket] = preset_values.get(socket)


# UTILITY FUNCTIONS
def shp_refresh_modifier(obj):
    if obj and shp_modifier_name in obj.modifiers:
        for _ in range(2):
            obj.modifiers[shp_modifier_name].show_viewport = not obj.modifiers[shp_modifier_name].show_viewport

def shp_refresh_selection():
    selected_objects = bpy.context.selected_objects
    active_object = bpy.context.active_object
    if active_object.mode == 'OBJECT':
        bpy.ops.object.select_all(action='DESELECT')
        bpy.context.view_layer.objects.active = None
        for obj in selected_objects:
            obj.select_set(True)
        bpy.context.view_layer.objects.active = active_object  

def shp_select_update(obj):
    shp_ctrl = bpy.context.scene.shp_addon

    if obj and shp_modifier_name in obj.modifiers:
        pass    # Update any custom properties from here

def shp_pick_base_mesh(curve):
    if curve and curve.type == 'CURVES' and shp_modifier_name in curve.modifiers:
        base_mesh = curve.data.surface
        base_uv = curve.data.surface_uv_map
        shp_set_value('internal_utils', 'iu_base_mesh', base_mesh, curve)
        shp_set_value('internal_utils', 'iu_base_uv', base_uv, curve)
        shp_refresh_modifier(curve)

def shp_generate_armature(context, armature_only=False):
    selected_guides = context.selected_objects
    bpy.ops.object.select_all(action='DESELECT')
    armature_type = shp_read_value_global('gs_armature_type')
    armature_objects = []   # Store generated armature objects
    
    for guide in selected_guides:
        if shp_get_spline_count(guide):
            if guide.type in {'CURVE', 'CURVES'}:
                guide.select_set(True)                                                      # Select and set as active
                context.view_layer.objects.active = guide
                shp_set_value('internal_utils', 'iu_toggle_armature_guide', True, guide)    # Toggle the armature guide ON
                shp_refresh_modifier(guide)
                bpy.ops.object.duplicate_move()                                             # Duplicate guide 
                bpy.ops.object.convert(target='MESH')                                       # Convert to mesh 
                bpy.ops.object.editmode_toggle()                                            # Split into separate guides
                bpy.ops.mesh.select_all(action='SELECT')
                bpy.ops.mesh.separate(type='LOOSE')
                bpy.ops.object.editmode_toggle()
            
            armature_chains = []   # Temp list to store individual armature chains
            
            for obj in context.selected_objects:
                if obj and obj.type == 'MESH':
                    if armature_type == 'Normal':
                        bone_nametag = shp_read_value_global('gs_name_bone')
                    else: # B-bone
                        scale_factor = shp_read_value('internal_utils', 'iu_scale_factor', guide)
                        armature_scale = 0.03 * scale_factor
                        handles_length = 0.02 * scale_factor
                        bbone_segments = shp_read_value('utility_settings', 'utils_arm_bbone_segments', guide)
                        handle_nametag = shp_read_value_global('gs_name_bbone_handle')
                        bbone_nametag = shp_read_value_global('gs_name_bbone')

                    if armature_type == 'Normal':
                        # Create Bones
                        for i in range(len(obj.data.vertices) - 1):
                            head_loc = obj.data.vertices[i].co
                            tail_loc = obj.data.vertices[i + 1].co
                            
                            if i == 0:  # Add armature
                                bpy.ops.object.armature_add(enter_editmode=True, align='WORLD', location=(obj.location), scale=(1, 1, 1))
                                edit_bone = bpy.context.edit_object.data.edit_bones[i]
                                edit_bone.head = head_loc
                                edit_bone.tail = tail_loc
                                edit_bone.name = f"{bone_nametag}.{i:0>3}"
                            else:   # Extrude bones
                                bpy.ops.armature.extrude_move()
                                edit_bone = bpy.context.edit_object.data.edit_bones[i]
                                edit_bone.tail = tail_loc
                                edit_bone.name = f"{bone_nametag}.{i:0>3}"
                    else: # B-bone
                        # Create Handles
                        for vertex in obj.data.vertices:
                            vert_index = vertex.index
                            direction = obj.data.attributes['guide_direction'].data[vert_index].vector
                            handle_length = direction * handles_length
                            head_loc = vertex.co
                            tail_loc = handle_length
                            
                            if vert_index == 0:
                                bpy.ops.object.armature_add(enter_editmode=True, align='WORLD', location=(obj.location), scale=(1, 1, 1))
                                edit_bone = context.edit_object.data.edit_bones[vert_index]
                                edit_bone.head = head_loc
                                edit_bone.tail = head_loc + tail_loc
                                edit_bone.name = f"{handle_nametag}.{vert_index:0>3}"
                                edit_bone.bbone_x = armature_scale
                                edit_bone.bbone_z = armature_scale
                                edit_bone.use_deform = False
                            else:
                                bpy.ops.armature.bone_primitive_add()
                                edit_bone = context.edit_object.data.edit_bones[vert_index]
                                edit_bone.head = head_loc
                                edit_bone.tail = head_loc + tail_loc
                                edit_bone.name = f"{handle_nametag}.{vert_index:0>3}"
                                edit_bone.bbone_x = armature_scale
                                edit_bone.bbone_z = armature_scale
                                edit_bone.use_deform = False
                    
                        # Create Deform B-Bones
                        for i in range(len(obj.data.vertices) - 1):
                            bone_index = len(obj.data.vertices) + i
                            head_loc = obj.data.vertices[i].co
                            tail_loc = obj.data.vertices[i + 1].co
                            
                            if i == 0:
                                bpy.ops.armature.bone_primitive_add()
                                edit_bone = context.edit_object.data.edit_bones[bone_index]
                                start_handle_name = context.edit_object.data.edit_bones[i].name
                                end_handle_name = context.edit_object.data.edit_bones[i + 1].name
                                
                                edit_bone.head = head_loc
                                edit_bone.tail = tail_loc
                                edit_bone.name = f"{bbone_nametag}.{i:0>3}"
                                edit_bone.bbone_x = armature_scale / 2
                                edit_bone.bbone_z = armature_scale / 2
                                edit_bone.bbone_segments = bbone_segments
                                edit_bone.parent = context.edit_object.data.edit_bones[start_handle_name]
                                edit_bone.bbone_handle_type_start = 'TANGENT'
                                edit_bone.bbone_handle_type_end = 'TANGENT'
                                edit_bone.bbone_custom_handle_start = context.edit_object.data.edit_bones[start_handle_name]
                                edit_bone.bbone_custom_handle_end = context.edit_object.data.edit_bones[end_handle_name]
                            else:
                                bpy.ops.armature.extrude_move()
                                edit_bone = context.edit_object.data.edit_bones[bone_index]
                                start_handle_name = context.edit_object.data.edit_bones[i].name
                                end_handle_name = context.edit_object.data.edit_bones[i + 1].name
                                
                                edit_bone.tail = tail_loc
                                edit_bone.name = f"{bbone_nametag}.{i:0>3}"
                                edit_bone.bbone_x = armature_scale / 2
                                edit_bone.bbone_z = armature_scale / 2
                                edit_bone.bbone_segments = bbone_segments   # Set b-bone segmetns
                                edit_bone.bbone_handle_type_start = 'TANGENT'   # Set start and end handles
                                edit_bone.bbone_handle_type_end = 'TANGENT'
                                edit_bone.bbone_custom_handle_start = context.edit_object.data.edit_bones[start_handle_name]
                                edit_bone.bbone_custom_handle_end = context.edit_object.data.edit_bones[end_handle_name]

                    bpy.ops.object.editmode_toggle()    # Exit 'Edit Mode'

                    if armature_type == 'B-Bone':
                        # Set B-Bone constraints
                        bpy.ops.object.posemode_toggle()    # Enter 'Pose Mode'
                        bpy.ops.pose.select_all(action='DESELECT')
                        for i in range(len(obj.data.vertices) - 1):
                            b_bone_name = f"{bbone_nametag}.{i:0>3}"
                            b_bone = context.view_layer.objects.active.data.bones[b_bone_name]
                            context.view_layer.objects.active.data.bones.active = b_bone
                            
                            # Select bone (for Blender 5.0)
                            bpy.ops.object.editmode_toggle()
                            context.view_layer.objects.active.data.edit_bones.active.select = True
                            bpy.ops.object.posemode_toggle()
                            
                            bpy.ops.pose.constraint_add(type='STRETCH_TO')
                            armature_object = context.view_layer.objects.active
                            target_handle_name = f"{handle_nametag}.{i + 1:0>3}"
                            
                            constraint = context.object.pose.bones[b_bone_name].constraints.active
                            constraint.target = armature_object
                            constraint.subtarget = target_handle_name 
                        bpy.ops.pose.select_all(action='DESELECT')
                        bpy.ops.object.posemode_toggle()    # Exit 'Pose Mode'
                        
                        # Fix bone twisting
                        bpy.ops.object.editmode_toggle()    # Enter 'Edit Mode'
                        bpy.ops.armature.select_all(action='SELECT')
                        context.view_layer.objects.active.data.edit_bones.active = context.view_layer.objects.active.data.edit_bones[f"{handle_nametag}.000"] # Set the start handle as active
                        bpy.ops.armature.calculate_roll(type='ACTIVE')  # Re-calculate Roll
                        bpy.ops.object.editmode_toggle()    # Exit 'Edit Mode'

                    armature_chains.append(context.object) # Add to Armature Chains list
                    bpy.data.objects.remove(obj, do_unlink=True)    # Remove guide
            
            # Join all armatures chains into a single object
            for armature in armature_chains:
                armature.select_set(True)
            bpy.ops.object.join()
            
            if armature_type == 'B-Bone':
                context.object.data.display_type = 'BBONE'  # Set the viewport preview as B-Bone        
            
            # Name the Armature
            armature_name = f"SHP_Armature ({guide.name})"
            context.object.name = armature_name
            context.object.data.name = armature_name
            armature_objects.append(context.object)

            # Toggle the armature guide OFF
            guide.select_set(True)
            context.view_layer.objects.active = guide
            shp_set_value('internal_utils', 'iu_toggle_armature_guide', False, guide)
            shp_set_value('utility_settings', 'utils_arm_preview_armature', False, guide)
            shp_refresh_modifier(context.active_object)
            
            bpy.ops.object.select_all(action='DESELECT')

    # Convert to mesh and parent
    guide_obj_index = 0
    generated_meshes = []
    for guide in selected_guides:
        if shp_get_spline_count(guide):
            guide.select_set(True)
            if not armature_only:
                context.view_layer.objects.active = guide
                is_parent = shp_read_value_global('gs_armature_parent')
                parent_method = shp_read_value_global('gs_armature_parent_method')
                bpy.ops.object.convert(target='MESH')
                generated_meshes.append(context.object) # Add to Generated Meshes list
                
                # Parent
                if is_parent:
                    armature_objects[guide_obj_index].select_set(True)
                    context.view_layer.objects.active = armature_objects[guide_obj_index]
                    if parent_method == "With Empty Groups":
                        bpy.ops.object.parent_set(type='ARMATURE_NAME')
                    elif parent_method == "With Envelope Weights":
                        bpy.ops.object.parent_set(type='ARMATURE_ENVELOPE')
                    elif parent_method == "With Automatic Weights":
                        bpy.ops.object.parent_set(type='ARMATURE_AUTO')    
                
                bpy.ops.object.select_all(action='DESELECT')
                guide_obj_index += 1
    
    # Restore selection
    if not armature_only:
        for hair_mesh in generated_meshes:
            hair_mesh.select_set(True)

def shp_get_curve_avg_length(curve):
    avg_length = 1.0
    if curve:
        if curve.type == 'CURVE':
            avg_length = 0.0
            total_length = 0.0
            spline_count = len(curve.data.splines)
            if spline_count > 0:
                for spline in curve.data.splines:
                    total_length += spline.calc_length()
                avg_length = round(total_length / spline_count, 3)
                return avg_length
        elif curve.type == 'CURVES':
            avg_length = 0.0
            total_length = 0.0
            spline_count = len(curve.data.curves)
            if spline_count > 0:
                for spline in curve.data.curves:
                    for i in range(spline.points_length - 1):
                        segment_length = (spline.points[i].position - spline.points[i + 1].position).length
                        total_length += segment_length
                avg_length = round(total_length / spline_count, 3)
                return avg_length
        else:
            return avg_length
    else:
        return avg_length

def shp_bake_hair_geo(obj, mode='BAKE'):
    if obj:
        if shp_modifier_name in obj.modifiers:
            for bake in obj.modifiers[shp_modifier_name].bakes:
                if bake.node.type == 'BAKE':
                    if mode == 'BAKE':
                        bpy.ops.object.geometry_node_bake_single(session_uid=obj.session_uid, modifier_name=shp_modifier_name, bake_id=bake.bake_id)
                        shp_set_value('internal_utils', 'iu_is_geo_baked', True, obj)
                    elif mode == 'DELETE':
                        bpy.ops.object.geometry_node_bake_delete_single(session_uid=obj.session_uid, modifier_name=shp_modifier_name, bake_id=bake.bake_id)
                        shp_set_value('internal_utils', 'iu_is_geo_baked', False, obj)

def shp_disable_all_gizmos():
    if shp_modifier_name in bpy.data.node_groups:
        node = bpy.data.node_groups[shp_modifier_name].nodes['shp_shell']
        node.inputs[sd['global_settings']['gs_show_scale_gizmos'][0]].default_value = False
        node.inputs[sd['global_settings']['gs_show_twist_gizmos'][0]].default_value = False
        node.inputs[sd['global_settings']['gs_show_root_pinch_gizmos'][0]].default_value = False
        node.inputs[sd['global_settings']['gs_show_tip_pinch_gizmos'][0]].default_value = False
        node.inputs[sd['global_settings']['gs_show_curls_gizmos'][0]].default_value = False
        node.inputs[sd['global_settings']['gs_show_braid_body_gizmos'][0]].default_value = False
        node.inputs[sd['global_settings']['gs_show_braid_strands_gizmos'][0]].default_value = False
        node.inputs[sd['global_settings']['gs_show_braid_roots_gizmos'][0]].default_value = False
        node.inputs[sd['global_settings']['gs_show_split_tip_gizmos'][0]].default_value = False
        node.inputs[sd['global_settings']['gs_show_resolution_gizmos'][0]].default_value = False
    
def shp_is_gizmo_visible():
    obj = bpy.context.active_object
    if obj:
        master_gizmo_toggle = shp_read_value_global('gs_toggle_gizmos')
        gizmo_in_obj_mode = shp_read_value_global('gs_show_gizmos_in_editing')
        if not gizmo_in_obj_mode:
            gizmo_in_obj_mode = not shp_read_value('internal_utils', 'iu_edit_mode', obj)
        gizmo_toggles = [
            shp_read_value_global('gs_show_scale_gizmos'),
            shp_read_value_global('gs_show_twist_gizmos'),
            shp_read_value_global('gs_show_root_pinch_gizmos'),
            shp_read_value_global('gs_show_tip_pinch_gizmos'),
            shp_read_value_global('gs_show_curls_gizmos'),
            shp_read_value_global('gs_show_braid_body_gizmos'),
            shp_read_value_global('gs_show_braid_strands_gizmos'),
            shp_read_value_global('gs_show_braid_roots_gizmos'),
            shp_read_value_global('gs_show_split_tip_gizmos'),
            shp_read_value_global('gs_show_resolution_gizmos'),
        ]
        
        is_gizmo_visible = master_gizmo_toggle and gizmo_in_obj_mode and any(gizmo_toggles)
        # print(f"SHP: Gizmo visible: {is_gizmo_visible}") # DEBUG
        return is_gizmo_visible
    # print("SHP: No actuve object") # DEBUG
    return False


# UPDATE FUNCTIONS
@persistent
def shp_active_object_update(scene):    # Active object change update function
    global shp_last_active_obj
    obj = bpy.context.active_object

    if obj == shp_last_active_obj:
        return  # Exit func, no active object change

    # Run if active object change
    if obj and shp_modifier_name in obj.modifiers:
        # Update custom props
        shp_select_update(obj)
        shp_refresh_modifier(obj)
        
        # Update mode after Alt Q mode transfer
        if obj.mode  in {'EDIT', 'SCULPT_CURVES'}:
            if shp_last_active_obj and shp_modifier_name in shp_last_active_obj.modifiers:
                shp_set_value('internal_utils', 'iu_edit_mode', False, shp_last_active_obj)
                shp_refresh_modifier(shp_last_active_obj)
            shp_set_value('internal_utils', 'iu_edit_mode', True, obj)
            shp_refresh_modifier(obj)
    shp_last_active_obj = obj

@persistent
def shp_mode_change_update(scene):      # Mode change update function
    global shp_last_mode
    obj = bpy.context.active_object

    if obj:
        current_mode = obj.mode
        if current_mode == shp_last_mode:
            return  # Exit func, no Mode change
        
        if shp_modifier_name in obj.modifiers:
            is_edit = current_mode in {'EDIT', 'SCULPT_CURVES'}
            shp_set_value('internal_utils', 'iu_edit_mode', is_edit, obj)
            shp_refresh_modifier(obj)
        
        shp_last_mode = current_mode

@persistent
def shp_scene_time_update(scene):       # Scene Time update function
    obj = bpy.context.active_object

    if obj and shp_modifier_name in obj.modifiers:
        if scene.frame_start == shp_read_value('internal_utils', 'iu_start_frame', obj) and scene.frame_end == shp_read_value('internal_utils', 'iu_end_frame', obj):
            return  # No changes to start/end frame
        else:
            shp_set_value('internal_utils', 'iu_start_frame', scene.frame_start, obj)
            shp_set_value('internal_utils', 'iu_end_frame', scene.frame_end, obj)
            shp_refresh_modifier(obj)

@persistent
def shp_set_modifier_active(scene):     # Optimize performance by deselecting the modifier
    shp_props = bpy.context.scene.shp_addon
    if shp_props.enable_set_active_modifier_funtion:
        if not shp_props.halt_set_active_modifier_function:
            obj = bpy.context.active_object
            if obj and shp_modifier_name in obj.modifiers:
                if obj.modifiers[shp_modifier_name].show_expanded:
                    obj.modifiers[shp_modifier_name].show_expanded = False
                if shp_is_gizmo_visible():
                    if not bool(obj.modifiers.active and obj.modifiers.active.name == shp_modifier_name):
                        obj.modifiers.active = obj.modifiers[shp_modifier_name]
                else:
                    if obj.modifiers.active and obj.modifiers.active.name == shp_modifier_name:
                        obj.modifiers.active = None

def presets_enum_items(self, context):  # Callback for the user presets enum items
    if shp_user_presets:
        return [(x, x, "") for x in shp_user_presets]
    return [("NONE", "No Presets", "")]


# PROPERTY GROUPS (CUSTOM PROPS)
class SHP_Props(bpy.types.PropertyGroup):
    
    dt_show_message: bpy.props.BoolProperty(
        default=True
    ) # type: ignore
    
    # Section Selector
    section_selector: bpy.props.EnumProperty(
        items=[('SHAPE',        "Shape Section",        "Display the 'Shape' section"),
               ('TWIST',        "Twist Section",        "Display the 'Twist' section"),
               ('BUMPS',        "Bumps Section",        "Display the 'Bumps' section"),
               ('CURLS',        "Curls Section",        "Display the Curls' section"),
               ('BRAID',        "Braid Section",        "Display the 'Braid' section"),
               ('FRIZZ',        "Frizz Section",        "Display the 'Frizz' section"),
               ('PROFILE',      "Profile Section",      "Display the 'Profile' section"),
               ('ORNAMENTS',    "Ornaments Section",    "Display the 'Ornaments' section"),
               ('DYNAMICS',     "Dynamics Section",     "Display the 'Dynamics' section"),
               ('SHADING',      "Materials/UV Section", "Display the 'Materials/UV' section"),
               ('SETTINGS',     "Settings Section",     "Display the 'Settings' section"),
               ('UTILITIES',    "Utilities Section",    "Display the 'Utilities' section")],
        default='SHAPE'
    ) # type: ignore
    
    sec_all: bpy.props.BoolProperty(name="Select All Sections", description="Select All Sections", default=True) # type: ignore
    sec_shape: bpy.props.BoolProperty(name="Shape Section", description="Select the SHAPE section", default=True) # type: ignore
    sec_twist: bpy.props.BoolProperty(name="Twist Section", description="Select the TWIST section", default=True) # type: ignore
    sec_bumps: bpy.props.BoolProperty(name="Bumps Section", description="Select the BUMPS section", default=True) # type: ignore
    sec_curls: bpy.props.BoolProperty(name="Curls Section", description="Select the CURLS section", default=True) # type: ignore
    sec_braid: bpy.props.BoolProperty(name="Braid Section", description="Select the BRAID section", default=True) # type: ignore
    sec_frizz: bpy.props.BoolProperty(name="Frizz Section", description="Select the FRIZZ section", default=True) # type: ignore
    sec_profile: bpy.props.BoolProperty(name="Profile Section", description="Select the PROFILE section", default=True) # type: ignore
    sec_ornaments: bpy.props.BoolProperty(name="Ornaments Section", description="Select the ORNAMENTS section", default=True) # type: ignore   
    sec_dynamics: bpy.props.BoolProperty(name="Dynamics Section", description="Select the DYNAMICS section", default=True) # type: ignore      
    sec_shading: bpy.props.BoolProperty(name="Shading Section", description="Select the SHADING section", default=True) # type: ignore
    sec_settings: bpy.props.BoolProperty(name="Settings Section", description="Select the SETTINGS section", default=True) # type: ignore      
    sec_utilities: bpy.props.BoolProperty(name="Utilities Section", description="Select the UTILITIES section", default=True) # type: ignore
    
    hair_curve_length:  bpy.props.EnumProperty(
        items=[('SHORT',    "Short",    "Add a short hair strand"),
               ('MEDIUM',   "Medium",   "Add a medium hair strand"),
               ('LONG',     "Long",     "Add a long hair strand")],
        default='MEDIUM'
    ) # type: ignore

    hair_curve_points:  bpy.props.IntProperty(
        name="Curve Points",
        description="Set the number of points of the curve",
        default=20,
        min=3,
        max=128
    ) # type: ignore
        
    display_tips: bpy.props.BoolProperty(
        name="Show Tips",
        default=True
    )   # type: ignore
    
    display_presets: bpy.props.BoolProperty(
        name="Show Presets",
        default=True
    )   # type: ignore


    preset_tab:  bpy.props.EnumProperty(
        items=[('DEFAULT',  "Default",  "Default built-in hair presets"),
               ('CUSTOM',   "Custom",   "User-defined hair presets")],
        default='DEFAULT'
    ) # type: ignore

    preset_name:    bpy.props.StringProperty(
        name="Preset Name",
        description="Set the of the preset",
        default=""
    ) # type: ignore
    
    selected_preset: bpy.props.EnumProperty(
        name="User Defined Presets",
        items=presets_enum_items
    ) #type:ignore

    default_presets:  bpy.props.EnumProperty(
        name="Default Presets",
        items=[('PLAIN_SHARP',          "Plain - Sharp",        ""),
               ('PLAIN_SOFT',           "Plain - Soft",         ""),
               ('CURL_FINE',            "Curl - Fine",          ""),
               ('CURL_LOOSE',           "Curl - Loose",         ""),
               ('BRAID_NORMAL',         "Braid",                ""),
               ('BRAID_FINE',           "Braid - Fine",         ""),
               ('PONYTAIL_NORMAL',      "Ponytail",             ""),
               ('PONYTAIL_BUBBLE_1',    "Bubble Ponytail 1",    ""),
               ('PONYTAIL_BUBBLE_2',    "Bubble Ponytail 2",    ""),
               ('BANKS_FRONT',          "Banks",                ""),],
        default='PLAIN_SHARP'
    ) # type: ignore

    display_tutorial: bpy.props.BoolProperty(
        name="Enable Tutorial",
        default=True
    )   # type: ignore

    tutorial_steps_counter: bpy.props.IntProperty(
        name='Step Counter', 
        default=0) # type: ignore

    tutorial_steps: bpy.props.EnumProperty(
        name="Stylized Hair PRO - Tutorial Steps",
        items=tutorial_step_items,
        default='STEP_0'
    ) # type: ignore
    
    quick_menu_layout:  bpy.props.EnumProperty(
        name="Quick Menu Layout",
        items=[('DETAILED',  "Detailed",    "Show full width buttons with labels"),
               ('COMPACT',   "Compact",     "Show only icons for more compacted layout")],
        default='DETAILED'
    ) # type: ignore

    halt_set_active_modifier_function: bpy.props.BoolProperty(
        name="Halt 'Set Active Modifier' Function",
        default=False
    )   # type: ignore
    
    enable_set_active_modifier_funtion: bpy.props.BoolProperty(
        name="Enable 'Set Active Modifier'",
        description="Enable to dynamically select/deselect the SHP modifier. Helps with performance optimization.",
        default=True
    )   # type: ignore

# TUTORIAL FUNCTIONS
def tutorial_hl(tut_hl_id):
    # Returns True if the formated 'tut_hl_id' is the same as the current 'tutorial_step' enum
    shp_props = bpy.context.scene.shp_addon
    for step_index, step in enumerate(sts):
        if step[0] == tut_hl_id:
            setting_hl = shp_props.tutorial_steps == f'STEP_{step_index}'
            break
    return setting_hl and shp_props.display_tutorial

def tutorial_group_hl(step_ids):
    shp_props = bpy.context.scene.shp_addon
    step_id = sts[int(shp_props.tutorial_steps.replace("STEP_", ""))][0]
    return shp_props.display_tutorial if step_id in step_ids else False

def draw_tutorial(self, context, space):
    shp_props = context.scene.shp_addon
    box = space.box()

    # STEP PICKER DROP-DOWN
    col = box.column(align=True)
    if shp_props.tutorial_steps != 'STEP_0':
        col.prop(shp_props, "tutorial_steps", text="", expand=False)

    # LABELS
    if tutorial_hl("START"):
        row = col.row()
        row.label(text="New to Stylized Hair PRO?")
        sub = row.row()
        sub.alignment = 'RIGHT'
        sub.prop(shp_props, "display_tutorial", text="Hide", toggle=True, invert_checkbox=True)
    else:
        step_index = int(shp_props.tutorial_steps.replace("STEP_", ""))
        tut_labels = split_string(sts[step_index][1], 45)
        for label in tut_labels:
            col.label(text=label)
        # Lines padding
        line_count = len(tut_labels)
        for _ in range(max(0, 5 - line_count)):
            col.label(text="")

    # BUTTONS
    if tutorial_hl("START"):
        col.operator("wm.tut_next_step", text="Start Tutorial", icon='PLAY', depress=True)
    elif tutorial_hl("ADDITIONAL INFO"):
        row = col.row(align=False)
        row.operator("wm.tut_cancel", text="Cancel", depress=False)
        row.operator("wm.tut_previous_step", text="🡨 Back", depress=True)
        row.operator("wm.tut_cancel", text="Finish", depress=True)
    else:
        row = col.row(align=False)
        row.operator("wm.tut_cancel", text="Cancel", depress=False)
        row.operator("wm.tut_previous_step", text="🡨 Back", depress=True)
        row.operator("wm.tut_next_step", text="Next 🡪", depress=True)


# UI DRAW FUNCTIONS
def draw_shape(self, context, space, show_tips=True):
    obj = context.object
    pcoll = shp_preview_collections["main"]
    label_width = 2.25

    if obj and obj.type in {'CURVE', 'CURVES'} and shp_modifier_name in obj.modifiers:

        # Header
        shp_draw_main_section_header(space, 'shape', "SHAPE SETTINGS", hl_1=tutorial_hl('COPY SECTION SETTINGS'), hl_2=tutorial_hl('RESET SECTION SETTINGS'))

        # Sub-panels tabs
        row = space.row(align=False)
        row.alert = tutorial_hl('SUB-SECTIONS')
        shp_draw(row, 'internal_utils', 'iu_shape_tab', label=" ", expand=True)

        # ENDS SHAPE sub-panel
        if shp_read_value('internal_utils', "iu_shape_tab", obj) == 'Ends Shape':
            sec_id = 'shape_settings'
            
            # Header
            shp_draw_sub_section_header(space, sec_id, "ENDS SHAPE", hl_1=tutorial_hl('COPY SECTION SETTINGS'), hl_2=tutorial_hl('RESET SECTION SETTINGS'))
            
            # Strand Shape Settings
            col = space.column(align=False)
            sub = col.column()
            sub.alert = tutorial_hl('ENDS SHAPE')
            shp_draw_double_label(sub, "Root", "Tip", label_width)
            shp_draw_double_row(sub, sec_id, "Size", "root_size", "tip_size", label_width)
            shp_draw_double_row(sub, sec_id, "Scale", "root_scale", "tip_scale", label_width)
            shp_draw_double_row(sub, sec_id, "Bulge", "root_bulge", "tip_bulge", label_width)
            shp_draw_double_row(sub, sec_id, "Round", "root_round", "tip_round", label_width)
            shp_draw_double_row(sub, sec_id, "Open", "root_open", "tip_open", label_width)
            shp_draw_double_row(sub, sec_id, "Flatten", "root_flatten", "tip_flatten", label_width)
            shp_draw_double_row(sub, sec_id, "Bend", "root_bend", "tip_bend", label_width)
            
            sub = col.column()
            sub.alert = tutorial_hl('SHAPE FACTOR WIDGET')
            shp_draw_shape_factor(sub, sec_id, "ends")
            col.separator(factor=1.0, type='LINE')
            sub = col.column()
            shp_draw_double_row(sub, sec_id, "Tilt", "root_tilt", "tip_tilt", label_width, enable_1=not shp_read_value('hair_settings_misc', 'settings_align_to_base', obj))
            shp_draw_double_row(sub, sec_id, "Tilt Dir.", "root_tilt_orientation", "tip_tilt_orientation", label_width, enable_1=not shp_read_value('hair_settings_misc', 'settings_align_to_base', obj))

        # PINCH sub-panel
        if shp_read_value('internal_utils', "iu_shape_tab", obj) == 'Pinch':
            sec_id = 'pinch_settings'
            
            # Header
            shp_draw_sub_section_header(space, sec_id, "PINCH", hl_1=tutorial_hl('COPY SECTION SETTINGS'), hl_2=tutorial_hl('RESET SECTION SETTINGS'))
            
            col = space.column(align=False)
            col.alert = tutorial_hl('PINCH')
            enable_1 = shp_read_value(sec_id, "root_pinch", obj) > 0.0
            enable_2 = shp_read_value(sec_id, "tip_pinch", obj) > 0.0
            enable_3 = shp_read_value('bumps_reg_settings', "reg_bumps_strength", obj) > 0.0
            
            # Pinch settings
            row = col.row(align=False)
            sub = row.row()
            sub.alignment = 'RIGHT'
            sub.ui_units_x = label_width
            sub.label(text="")
            sub2 = row.row()
            sub2.label(text="Root")
            sub = sub2.row()
            sub.alert = tutorial_hl('GIZMOS')
            shp_draw_global(sub, 'gs_show_root_pinch_gizmos', "", icon='GIZMO', toggle=True)
            sub3 = row.row()
            sub3.label(text="Tip")
            sub = sub3.row()
            sub.alert = tutorial_hl('GIZMOS')
            shp_draw_global(sub, 'gs_show_tip_pinch_gizmos', "", icon='GIZMO', toggle=True)
            
            row = col.row(align=False)
            row.scale_y = 1.25
            shp_draw_double_row(row, sec_id, "Pinch", "root_pinch", "tip_pinch", label_width, not enable_3, not enable_3)
            shp_draw_double_row(col, sec_id, "Width", "root_pinch_width", "tip_pinch_width", label_width, enable_1 or enable_3, enable_2 or enable_3)
            col.separator(factor=1.0, type='LINE')
            
            # Pinch Tightness settings
            col.label(text="Pinch Tightness:")
            shp_draw_double_row(col, sec_id, "End", "root_pinch_tightness", "tip_pinch_tightness", label_width, enable_1 or enable_3, enable_2 or enable_3)
            shp_draw_double_row(col, sec_id, "Body", "body_pinch_tightness_root", "body_pinch_tightness_tip", label_width, enable_1 and not enable_3, enable_2 and not enable_3)
            col.separator(factor=1.0, type='LINE')

            # Pinch Shape settings
            col.label(text="Pinch Shape:")
            shp_draw_double_row(col, sec_id, "End", "root_pinch_shape", "tip_pinch_shape", label_width, enable_1 or enable_3, enable_2 or enable_3)
            shp_draw_double_row(col, sec_id, "Body", "body_pinch_shape_root", "body_pinch_shape_tip", label_width, enable_1 and not enable_3, enable_2 and not enable_3)

def draw_twist(self, context, space, show_tips=True):
    obj = context.object
    sec_id = 'twist_settings'
    pcoll = shp_preview_collections["main"]

    if obj and obj.type in {'CURVE', 'CURVES'} and shp_modifier_name in obj.modifiers:

        # Header
        shp_draw_main_section_header(space, 'twist', "TWIST SETTINGS", hl_1=tutorial_hl('COPY SECTION SETTINGS'), hl_2=tutorial_hl('RESET SECTION SETTINGS'))

        # TWIST settings
        flow = space.grid_flow(row_major=True, columns=3, even_columns=True, even_rows=True, align=False)
        flow.alert = tutorial_group_hl(['TWIST'])
        flow.label(text="Root:")
        flow.label(text="Mid:")
        flow.label(text="Tip:")
        shp_draw(flow, sec_id, 'twist_root', "")
        shp_draw(flow, sec_id, 'twist_mid', "")
        shp_draw(flow, sec_id, 'twist_tip', "")

        # Sub-panels tabs
        space.separator(factor=1, type='LINE')
        row = space.row(align=False)
        shp_draw(row, 'internal_utils', 'iu_twist_tab', label=" ", expand=True)
        
        # WAVINESS sub-panel
        if shp_read_value('internal_utils', "iu_twist_tab", obj) == 'Waviness':
            sec_id = 'waviness_settings'

            # Header
            shp_draw_sub_section_header(space, sec_id, "WAVINESS", hl_1=tutorial_hl('COPY SECTION SETTINGS'), hl_2=tutorial_hl('RESET SECTION SETTINGS'))
            
            col = space.column(align=False)
            col.alert = tutorial_group_hl(['WAVINESS'])
            shp_draw_split(col, sec_id, 'waviness_strength', "Strength", 3)
            shp_draw_split(col, sec_id, 'waviness_scale', "Scale", 3)
            shp_draw_split(col, sec_id, 'waviness_seed', "Seed", 3)
            shp_draw_shape_factor(col, sec_id, "waviness")
        
        # CUSTOM TWIST sub-panel 
        if shp_read_value('internal_utils', "iu_twist_tab", obj) == 'Custom Twist':
            sec_id = 'custom_twist_settings'
            
            # Header
            shp_draw_sub_section_header(space, sec_id, "CUSTOM TWIST", hl_1=tutorial_hl('COPY SECTION SETTINGS'), hl_2=tutorial_hl('RESET SECTION SETTINGS'))

            # Custom Twist 1
            col = space.column(align=False)
            col.alert = tutorial_group_hl(['CUSTOM TWIST'])
            shp_draw(col, sec_id, 'custom_twist_1_amount', "Twist 1")
            sub = col.column(align=False)
            sub.enabled = shp_read_value(sec_id, "custom_twist_1_amount", obj) != 0.0
            shp_draw_shape_factor(sub, sec_id, "custom_twist_1", label1="Position 1", label2="Spread 1")
            
            # Custom Twist 2
            col.separator(factor=2, type='LINE')
            shp_draw(col, sec_id, 'custom_twist_2_amount', "Twist 2")
            sub = col.column(align=False)
            sub.enabled = shp_read_value(sec_id, "custom_twist_2_amount", obj) != 0.0
            shp_draw_shape_factor(sub, sec_id, "custom_twist_2", label1="Position 2", label2="Spread 2")
            
            # Custom Twist 1
            col.separator(factor=2, type='LINE')
            shp_draw(col, sec_id, 'custom_twist_3_amount', "Twist 3")
            sub = col.column(align=False)
            sub.enabled = shp_read_value(sec_id, "custom_twist_3_amount", obj) != 0.0
            shp_draw_shape_factor(sub, sec_id, "custom_twist_3", label1="Position 3", label2="Spread 3")

def draw_bumps(self, context, space, show_tips=True):
    obj = context.object
    pcoll = shp_preview_collections["main"]

    if obj and obj.type in {'CURVE', 'CURVES'} and shp_modifier_name in obj.modifiers:

        # Header
        shp_draw_main_section_header(space, 'bumps', "BUMPS SETTINGS", hl_1=tutorial_hl('COPY SECTION SETTINGS'), hl_2=tutorial_hl('RESET SECTION SETTINGS'))

        # Sub-panels tabs
        row = space.row(align=False)
        shp_draw(row, 'internal_utils', 'iu_bumps_tab', label=" ", expand=True)

        # REGULAR BUMPS sub-panel
        if shp_read_value('internal_utils', "iu_bumps_tab", obj) == 'Regular':
            sec_id = 'bumps_reg_settings'
            
            # Tab Header
            shp_draw_sub_section_header(space, sec_id, "REGULAR BUMPS", hl_1=tutorial_hl('COPY SECTION SETTINGS'), hl_2=tutorial_hl('RESET SECTION SETTINGS'))

            box = space.box()
            box.scale_y = 0.75
            col = box.column(align=False)
            shp_draw_split(col, 'shape_settings', 'root_size', "Root Size", 3)
            shp_draw_split(col, 'shape_settings', 'tip_size', "Tip Size", 3)
            
            col = space.column(align=False)
            row = col.row(align=False)
            row.scale_y = 1.25
            row.alert = tutorial_group_hl(['REGULAR BUMPS'])
            shp_draw(row, sec_id, 'reg_bumps_strength', "Strength")
            col.separator(factor=2, type='LINE')
            
            sub = col.column(align=False)
            sub.enabled = shp_read_value(sec_id, "reg_bumps_strength", obj) > 0.0
            shp_draw_split(sub, sec_id, 'reg_bumps_count', "Count", 3.6)
            shp_draw_split(sub, sec_id, 'reg_bumps_shape', "Shape", 3.6, text="Linear ⟷ Round")
            shp_draw_split(sub, sec_id, 'reg_bumps_gap_size', "Gaps Size", 3.6)
            shp_draw_split(sub, sec_id, 'reg_bumps_taper', "Taper", 3.6)
            shp_draw_split(sub, sec_id, 'reg_bumps_shift', "Shift Volume", 3.6, text="Root ⟷ Tip")
            shp_draw_random_seed(sub, sec_id, 'reg_bumps', label="Randomize Thickness")

        # RANDOM BUMPS sub-panel
        if shp_read_value('internal_utils', "iu_bumps_tab", obj) == 'Random':
            sec_id = 'bumps_rnd_settings'
            
            # Tab Header
            shp_draw_sub_section_header(space, sec_id, "RANDOM BUMPS", hl_1=tutorial_hl('COPY SECTION SETTINGS'), hl_2=tutorial_hl('RESET SECTION SETTINGS'))

            col = space.column(align=False)
            row = col.row(align=False)
            row.scale_y = 1.25
            row.alert = tutorial_group_hl(['RANDOM BUMPS'])
            shp_draw(row, sec_id, 'rnd_bumps_strength', "Strength")
            col.separator(factor=2, type='LINE')
            
            sub = col.column(align=False)
            sub.enabled = shp_read_value(sec_id, "rnd_bumps_strength", obj) > 0.0
            shp_draw_split(sub, sec_id, 'rnd_bumps_scale', "Scale", 3.6)
            shp_draw_split(sub, sec_id, 'rnd_bumps_seed', "Seed", 3.6)
            shp_draw_shape_factor(sub, sec_id, "rnd_bumps")

        # SURFACE BUMPS sub-panel
        if shp_read_value('internal_utils', "iu_bumps_tab", obj) == 'Surface':
            sec_id = 'bumps_srf_settings'
            
            # Tab Header
            shp_draw_sub_section_header(space, sec_id, "SURFACE BUMPS", hl_1=tutorial_hl('COPY SECTION SETTINGS'), hl_2=tutorial_hl('RESET SECTION SETTINGS'))

            col = space.column(align=False)
            row = col.row(align=False)
            row.scale_y = 1.25
            row.alert = tutorial_group_hl(['SURFACE BUMPS'])
            shp_draw(row, sec_id, 'srf_bumps_strength', "Strength")
            col.separator(factor=2, type='LINE')
            
            sub = col.column(align=False)
            sub.enabled = shp_read_value(sec_id, "srf_bumps_strength", obj) > 0.0
            shp_draw_split(sub, sec_id, 'srf_bumps_scale', "Scale", 3.6)
            shp_draw_split(sub, sec_id, 'srf_bumps_detail', "Detail", 3.6)
            shp_draw_split(sub, sec_id, 'srf_bumps_seed', "Seed", 3.6)
            shp_draw_shape_factor(sub, sec_id, "srf_bumps")

        # SUB-STRANDS sub-panel
        if shp_read_value('internal_utils', "iu_bumps_tab", obj) == 'Subs':
            sec_id = 'bumps_subs_settings'
            
            # Tab Header
            shp_draw_sub_section_header(space, sec_id, "SUB-STRANDS", hl_1=tutorial_hl('COPY SECTION SETTINGS'), hl_2=tutorial_hl('RESET SECTION SETTINGS'))

            col = space.column(align=False)
            row = col.row(align=False)
            row.scale_y = 1.25
            row.alert = tutorial_group_hl(['SUB-STRANDS'])
            shp_draw(row, sec_id, 'subs_bumps_strength', "Strength")
            col.separator(factor=2, type='LINE')
            
            sub = col.column(align=False)
            sub.enabled = shp_read_value(sec_id, "subs_bumps_strength", obj) > 0.0
            shp_draw_split(sub, sec_id, 'subs_bumps_scale', "Scale", 3.6)
            shp_draw_split(sub, sec_id, 'subs_bumps_seed', "Seed", 3.6)
            shp_draw_split(sub, sec_id, 'subs_bumps_shape', "Shape", 3.6)
            shp_draw_shape_factor(sub, sec_id, "subs_bumps")

def draw_curls(self, context, space, show_tips=True):
    obj = context.object
    sec_id = 'curls_settings'
    pcoll = shp_preview_collections["main"]
    label_width = 3.25

    if obj and obj.type in {'CURVE', 'CURVES'} and shp_modifier_name in obj.modifiers:

        # Header
        shp_draw_main_section_header(space, 'curls', "CURLS SETTINGS", randomize=True, hl_1=tutorial_hl('COPY SECTION SETTINGS'), hl_2=tutorial_hl('RESET SECTION SETTINGS'))
        
        row = space.row(align=True)
        row.scale_y = 1.25
        sub = row.row(align=True)
        sub.alert = tutorial_group_hl(['CURLS'])
        shp_draw(sub, sec_id, "curls_frequency", "Frequency")
        sub = row.row(align=True)
        sub.alert = tutorial_hl('GIZMOS')
        shp_draw_global(sub, 'gs_show_curls_gizmos', "", icon='GIZMO', toggle=True)

        col = space.column(align=False)
        col.enabled = shp_read_value(sec_id, "curls_frequency", obj) != 0.0

        shp_draw_split(col, sec_id, 'curls_radius', "Radius", label_width)
        shp_draw_split(col, sec_id, 'curls_phase', "Phase", label_width)
        shp_draw_split(col, sec_id, 'curls_stylize', "Stylization", label_width)
        shp_draw(col, sec_id, 'curls_flip_dir', "Flip Curl Direction")
        col.separator(factor=2, type='LINE')
        shp_draw_random_seed(col, sec_id, 'curls', label="Randomize Curl")
        col.separator(factor=2, type='LINE')
        shp_draw_split(col, sec_id, 'curls_flatten', "Flatten Curl", label_width)
        shp_draw_split(col, sec_id, 'curls_flatten_dir', "Direction", label_width)
        col.separator(factor=2, type='LINE')
        shp_draw_shape_factor(col, sec_id, 'curls')

def draw_braid(self, context, space, show_tips=True):
    obj = context.object
    pcoll = shp_preview_collections["main"]

    if obj and obj.type in {'CURVE', 'CURVES'} and shp_modifier_name in obj.modifiers:

        # Header
        shp_draw_main_section_header(space, 'braid', "BRAID SETTINGS", randomize=True, hl_1=tutorial_hl('COPY SECTION SETTINGS'), hl_2=tutorial_hl('RESET SECTION SETTINGS'))
        
        # Main Braid Settings
        row = space.row(align=True)
        row.scale_y = 1.25
        sub = row.row(align=True)
        sub.alert = tutorial_group_hl(['BRAIDS'])
        shp_draw(sub, 'braid_body_settings', 'braid_frequency', "Frequency")
        sub = row.row(align=True)
        sub.alert = tutorial_hl('GIZMOS')
        shp_draw_global(sub, 'gs_show_braid_body_gizmos', "", icon='GIZMO', toggle=True)
        shp_draw_global(sub, 'gs_show_braid_strands_gizmos', "", icon='GIZMO', toggle=True)
        shp_draw_global(sub, 'gs_show_braid_roots_gizmos', "", icon='GIZMO', toggle=True)
        
        # TIP
        if show_tips:
            box = space.box()
            box.scale_y = 0.8
            sub = box.column(align=False)
            shp_draw_tips(sub, 'tip_braid_base')
            row = sub.row()
            row.label(text="Base Mesh:")
            row.operator("wm.shp_pick_base_mesh")
            shp_draw(sub, 'internal_utils', 'iu_base_mesh', "Object", icon='OBJECT_DATAMODE')
        
        # Sub-panels tabs
        space.separator(type='LINE')
        row = space.row(align=False)
        shp_draw(row, 'internal_utils', 'iu_braid_tab', label=" ", expand=True)

        # BRAID BODY sub-panel
        if shp_read_value('internal_utils', "iu_braid_tab", obj) == 'Body':
            sec_id = 'braid_body_settings'
            label_width = 4
            
            # Tab Header
            shp_draw_sub_section_header(space, sec_id, "BRAID BODY", hl_1=tutorial_hl('COPY SECTION SETTINGS'), hl_2=tutorial_hl('RESET SECTION SETTINGS'))
            
            col = space.column(align=True)
            col.alert = tutorial_group_hl(['BRAID BODY'])
            col.enabled = shp_read_value(sec_id, "braid_frequency", obj) > 0.0
            shp_draw_split(col, sec_id, 'braid_width', "Width", label_width)
            shp_draw_split(col, sec_id, 'braid_depth', "Depth", label_width)
            col.separator(factor=2, type='LINE')
            shp_draw_split(col, sec_id, 'braid_taper', "Taper", label_width)
            shp_draw_split(col, sec_id, 'braid_taper_degree', "Taper Degree", label_width)
        
        # BRAID STRANDS sub-panel
        if shp_read_value('internal_utils', "iu_braid_tab", obj) == 'Strands':
            sec_id = 'braid_strands_settings'
            label_width = 3.25
            
            # Tab Header
            shp_draw_sub_section_header(space, sec_id, "BRAID STRANDS", hl_1=tutorial_hl('COPY SECTION SETTINGS'), hl_2=tutorial_hl('RESET SECTION SETTINGS'))
            
            col = space.column(align=True)
            col.alert = tutorial_group_hl(['BRAID STRANDS'])
            col.enabled = shp_read_value('braid_body_settings', "braid_frequency", obj) > 0.0
            shp_draw_split(col, sec_id, 'braid_strands_pinch', "Pinch", label_width)
            col.separator(factor=2, type='LINE')
            shp_draw_random_seed(col, sec_id, 'braid_strands', label="Randomize Thickness")
            col.separator(factor=2, type='LINE')

            row = col.row(align=False)

            sub = row.column(align=False)
            sub.alignment = 'RIGHT'
            sub.ui_units_x = 3
            sub.label(text="")
            sub.label(text="Thickness:")
            sub.label(text="Flatten:")
            sub.label(text="Rotate:")
            sub.label(text="Twist:")
            
            sub = row.column(align=False)
            sub.label(text="Strand 1")
            shp_draw(sub, sec_id, 'braid_strand_1_thickness', "")
            shp_draw(sub, sec_id, 'braid_strand_1_flatten', "")
            shp_draw(sub, sec_id, 'braid_strand_1_rotate', "")
            shp_draw(sub, sec_id, 'braid_strand_1_twist', "")

            sub = row.column(align=False)
            sub.label(text="Strand 2")
            shp_draw(sub, sec_id, 'braid_strand_2_thickness', "")
            shp_draw(sub, sec_id, 'braid_strand_2_flatten', "")
            shp_draw(sub, sec_id, 'braid_strand_2_rotate', "")
            shp_draw(sub, sec_id, 'braid_strand_2_twist', "")

            sub = row.column(align=False)
            sub.label(text="Strand 3")
            shp_draw(sub, sec_id, 'braid_strand_3_thickness', "")
            shp_draw(sub, sec_id, 'braid_strand_3_flatten', "")
            shp_draw(sub, sec_id, 'braid_strand_3_rotate', "")
            shp_draw(sub, sec_id, 'braid_strand_3_twist', "")


        # BRAID ROOTS sub-panel
        if shp_read_value('internal_utils', "iu_braid_tab", obj) == 'Roots':
            sec_id = 'braid_roots_settings'
            label_width = 3.25
            
            # Tab Header
            shp_draw_sub_section_header(space, sec_id, "BRAID ROOTS", hl_1=tutorial_hl('COPY SECTION SETTINGS'), hl_2=tutorial_hl('RESET SECTION SETTINGS'))
            
            col = space.column(align=True)
            col.alert = tutorial_group_hl(['BRAID ROOTS'])
            col.enabled = shp_read_value('braid_body_settings', "braid_frequency", obj) > 0.0
            
            box = col.box()
            box.scale_y = 0.75
            shp_draw_split(box, 'shape_settings', 'root_size', "Root Size", label_width)

            row = col.row(align=False)
            sub = row.column(align=False)
            sub.alignment = 'RIGHT'
            sub.ui_units_x = 3.5
            sub.label(text="")
            col = sub.column()
            col.alignment = 'RIGHT'
            col.ui_units_y = 3
            col.label(text="Move:")
            sub.label(text="Scale:")
            sub.label(text="Flatten:")
            sub.label(text="Bend:")
            sub.label(text="Rotate:")
            sub.label(text="Size Factor:")
            sub.label(text="Adjust Start:")
            sub.label(text="Adjust End:")

            sub = row.column(align=False)
            sub.label(text="Root 1")
            col = sub.column()
            col.ui_units_y = 3
            shp_draw(col, sec_id, 'braid_root_1_move', "")
            shp_draw(sub, sec_id, 'braid_root_1_scale', "")
            shp_draw(sub, sec_id, 'braid_root_1_flatten', "")
            shp_draw(sub, sec_id, 'braid_root_1_bend', "")
            shp_draw(sub, sec_id, 'braid_root_1_rotate', "")
            shp_draw(sub, sec_id, 'braid_root_1_factor', "")
            shp_draw(sub, sec_id, 'braid_root_1_start', "")
            shp_draw(sub, sec_id, 'braid_root_1_end', "")

            sub = row.column(align=False)
            sub.label(text="Root 2")
            col = sub.column()
            col.ui_units_y = 3
            shp_draw(col, sec_id, 'braid_root_2_move', "")
            shp_draw(sub, sec_id, 'braid_root_2_scale', "")
            shp_draw(sub, sec_id, 'braid_root_2_flatten', "")
            shp_draw(sub, sec_id, 'braid_root_2_bend', "")
            shp_draw(sub, sec_id, 'braid_root_2_rotate', "")
            shp_draw(sub, sec_id, 'braid_root_2_factor', "")
            shp_draw(sub, sec_id, 'braid_root_2_start', "")
            shp_draw(sub, sec_id, 'braid_root_2_end', "")

            sub = row.column(align=False)
            sub.label(text="Root 3")
            col = sub.column()
            col.ui_units_y = 3
            shp_draw(col, sec_id, 'braid_root_3_move', "")
            shp_draw(sub, sec_id, 'braid_root_3_scale', "")
            shp_draw(sub, sec_id, 'braid_root_3_flatten', "")
            shp_draw(sub, sec_id, 'braid_root_3_bend', "")
            shp_draw(sub, sec_id, 'braid_root_3_rotate', "")
            shp_draw(sub, sec_id, 'braid_root_3_factor', "")
            shp_draw(sub, sec_id, 'braid_root_3_start', "")
            shp_draw(sub, sec_id, 'braid_root_3_end', "")

def draw_frizz(self, context, space, show_tips=True):
    obj = context.object
    pcoll = shp_preview_collections["main"]
    sec_id = 'frz_splt_tip_settings'

    if obj and obj.type in {'CURVE', 'CURVES'} and shp_modifier_name in obj.modifiers:

        # Header
        shp_draw_main_section_header(space, 'frizz', "FRIZZ SETTINGS", hl_1=tutorial_hl('COPY SECTION SETTINGS'), hl_2=tutorial_hl('RESET SECTION SETTINGS'))

        # Sub-panels tabs
        row = space.row(align=False)
        shp_draw(row, 'internal_utils', 'iu_frizz_tab', label=" ", expand=True)

        # SPLIT TIP sub-panel
        if shp_read_value('internal_utils', "iu_frizz_tab", obj) == 'Split Tip':
            sec_id = 'frz_splt_tip_settings'
            
            # Tab Header
            shp_draw_sub_section_header(space, sec_id, "SPLIT TIP", randomize=True, hl_1=tutorial_hl('COPY SECTION SETTINGS'), hl_2=tutorial_hl('RESET SECTION SETTINGS'))

            box = space.box()
            box.scale_y = 0.75
            col = box.column(align=False)
            shp_draw_split(col, 'shape_settings', 'tip_size', "Tip Size", 3)
            shp_draw_split(col, 'shape_settings', 'tip_scale', "Tip Scale", 3)
                
            row = space.row(align=True)
            row.scale_y = 1.25
            sub = row.row(align=True)
            sub.alert = tutorial_group_hl(['SPLIT TIP'])
            shp_draw(sub, sec_id, "frz_splt_tip_split", "Split Tip")
            sub = row.row(align=True)
            sub.alert = tutorial_hl('GIZMOS')
            shp_draw_global(sub, 'gs_show_split_tip_gizmos', "", icon='GIZMO', toggle=True)
            
            col = space.column(align=False)
            col.enabled = shp_read_value(sec_id, "frz_splt_tip_split", obj) > 0.0
            
            col.alert = tutorial_group_hl(['SPLIT TIP SETTINGS'])
            col.separator(factor=2, type='LINE')
            shp_draw_split(col, sec_id, 'frz_splt_tip_splits_count', "Splits Count", 3.5)
            shp_draw_split(col, sec_id, 'frz_splt_tip_seed_major', "Splits Seed", 3.5)
            shp_draw_split(col, sec_id, 'frz_splt_tip_smooth', "Smooth Cuts", 3.5)
            shp_draw_random_seed(col, sec_id, 'frz_splt_tip_split', label="Randomize", text="Split")
            shp_draw_sub_row(col, sec_id, 'frz_splt_tip_depth_random', 'frz_splt_tip_depth_seed', "Depth", "")
            shp_draw_sub_row(col, sec_id, 'frz_splt_tip_length_random', 'frz_splt_tip_length_seed', "Length", "")
            shp_draw_sub_row(col, sec_id, 'frz_splt_tip_tilt_random', 'frz_splt_tip_tilt_seed', "Tilt", "", enabled=((shp_read_value(sec_id, "frz_splt_tip_split", obj) < 1.0) or (shp_read_value(sec_id, "frz_splt_tip_split_random", obj) > 0.0)))
            
            col.separator(factor=2, type='LINE')
            shp_draw_random_seed(col, sec_id, 'frz_splt_tip_bend', label="Bend Splits", text="Amount")
            shp_draw_split(col, sec_id, 'frz_splt_tip_bend_direction', "Direction", 3.5, "Normal ⟷ Sideways")
            shp_draw_split(col, sec_id, 'frz_splt_tip_bend_limit', "Limit Bend", 3.5)
            shp_draw(col, sec_id, 'frz_splt_tip_bend_outward_only', "Outwards Bend Only")
            shp_draw(col, sec_id, 'frz_splt_tip_bend_limit_central', "Limit Central Splits Bend")
            
            col.separator(factor=2, type='LINE')
            shp_draw_split(col, sec_id, 'frz_splt_tip_curl', "Curl Splits", 3.5)
            shp_draw_split(col, sec_id, 'frz_splt_tip_curl_radius', "Curl Radius", 3.5)
            shp_draw_split(col, sec_id, 'frz_splt_tip_curl_limit', "Limit Curl", 3.5)
            shp_draw_random_seed(col, sec_id, 'frz_splt_tip_curl', label="Randomize Curl")

        # FRIZZ STRAND sub-panel
        if shp_read_value('internal_utils', "iu_frizz_tab", obj) == 'Frizz Strand':
            sec_id = 'frz_strand_settings'
            label_width = 4.5

            # Tab Header
            shp_draw_sub_section_header(space, sec_id, "FRIZZ STRAND", hl_1=tutorial_hl('COPY SECTION SETTINGS'), hl_2=tutorial_hl('RESET SECTION SETTINGS'))

            col = space.column(align=True)
            col.scale_y = 1.25
            col.alert = tutorial_group_hl(['FRIZZ STRAND'])
            shp_draw(col, sec_id, 'frz_str_strength', "Strength")

            col = space.column(align=False)
            col.enabled = shp_read_value(sec_id, "frz_str_strength", obj) > 0
            shp_draw_split(col, sec_id, 'frz_str_scale', "Scale", label_width)
            shp_draw_split(col, sec_id, 'frz_str_roughness', "Roughness", label_width)
            shp_draw_split(col, sec_id, 'frz_str_seed', "Seed", label_width)
            shp_draw_split(col, sec_id, 'frz_str_length_preserve', "Preserve Length", label_width)
            shp_draw_shape_factor(col, sec_id, 'frz_str')

        # FLYAWAYS sub-panel
        if shp_read_value('internal_utils', "iu_frizz_tab", obj) == 'Flyaways':
            sec_id = 'frz_flys_settings'
            label_width = 3.0
            
            # Tab Header
            shp_draw_sub_section_header(space, sec_id, "FLYAWAYS", hl_1=tutorial_hl('COPY SECTION SETTINGS'), hl_2=tutorial_hl('RESET SECTION SETTINGS'))
            
            col = space.column(align=True)
            row = col.row(align=False)
            row.scale_y = 1.25
            row.alert = tutorial_group_hl(['FLYAWAYS'])
            shp_draw(row, sec_id, 'frz_flys_count', "Count")

            col = space.column(align=False)
            col.enabled = shp_read_value(sec_id, "frz_flys_count", obj) > 0
            
            shp_draw_split(col, sec_id, 'frz_flys_offset', "Offset", label_width)
            shp_draw_split(col, sec_id, 'frz_flys_seed', "Seed", label_width)
            shp_draw_shape_factor(col, sec_id, 'frz_flys')
            col.separator(type='LINE')
            shp_draw_split(col, sec_id, 'frz_flys_length', "Length", label_width)
            shp_draw_split(col, sec_id, 'frz_flys_length_random', "Randomize", label_width)
            col.separator(type='LINE')
            shp_draw_split(col, sec_id, 'frz_flys_thickness', "Thickness", label_width)
            shp_draw_split(col, sec_id, 'frz_flys_thickness_random', "Randomize", label_width)
            col.separator(type='LINE')
            shp_draw_split(col, sec_id, 'frz_flys_spin', "Twist", label_width)
            shp_draw(col, sec_id, 'frz_flys_in_both_dir', "In Both Directions")
            col.separator(type='LINE')

            col = space.column(align=True)
            col.enabled = shp_read_value(sec_id, "frz_flys_count", obj) > 0.0
            row = col.row(align=False)
            row.scale_y = 1.25
            shp_draw(row, sec_id, 'frz_flys_frizz_strength', "Frizz Flyaways")

            col = space.column(align=False)
            col.enabled = shp_read_value(sec_id, "frz_flys_frizz_strength", obj) > 0.0 and shp_read_value(sec_id, "frz_flys_count", obj) > 0.0
            
            shp_draw_split(col, sec_id, 'frz_flys_frizz_scale', "Scale", label_width)
            shp_draw_split(col, sec_id, 'frz_flys_frizz_roughness', "Roughness", label_width)
            shp_draw_split(col, sec_id, 'frz_flys_frizz_seed', "Seed", label_width)
            shp_draw_shape_factor(col, sec_id, 'frz_flys_frizz')

def draw_profile(self, context, space, show_tips=True):
    obj = context.object
    sec_id = 'profile_settings'
    pcoll = shp_preview_collections["main"]

    if obj and obj.type in {'CURVE', 'CURVES'} and shp_modifier_name in obj.modifiers:

        # Header
        shp_draw_main_section_header(space, 'profile', "PROFILE SETTINGS", hl_1=tutorial_hl('COPY SECTION SETTINGS'), hl_2=tutorial_hl('RESET SECTION SETTINGS'))
        
        col = space.column(align=False)
        col.label(text="Profile Type:")
        row = col.row()
        row.scale_y = 1.25
        shp_draw(row, sec_id, 'profile_type', " ", expand=True)
        
        space.separator(factor=0.5, type='LINE')

        
        # ALMOND profile
        if shp_read_value(sec_id, 'profile_type', obj) == 'Almond':
            col = space.column(align=False)
            # col.alert = tutorial_group_hl(['SMART PROFILE'])
            shp_draw_split(col, sec_id, 'smart_profile_shape', "Profile Shape", 4, text="Sharp ⟷ Round")

        # BOX profile
        elif shp_read_value(sec_id, 'profile_type', obj) == 'Box':  
            col = space.column(align=False)
            shp_draw_split(col, sec_id, 'smart_profile_smooth', "Smooth Profile", 4, text="Sharp ⟷ Smooth")

        # TRIANGLE profile
        elif shp_read_value(sec_id, 'profile_type', obj) == 'Triangle':  
            col = space.column(align=False)
            shp_draw_split(col, sec_id, 'smart_profile_smooth', "Smooth Profile", 4, text="Sharp ⟷ Smooth")


        # CUSTOM profile
        elif shp_read_value(sec_id, 'profile_type', obj) == 'Custom':
            col = space.column(align=False)
            col.alert = tutorial_group_hl(['CUSTOM PROFILE'])
            col.label(text="Custom Profile Type:")
            sub = col.row(align=False)
            shp_draw(sub, sec_id, 'custom_profile_type', label=" ", expand=True)
            if shp_read_value(sec_id, 'custom_profile_type', obj) == 'Object':
                col.label(text="Profile Curve Object:")
                shp_draw_prop_search(col, sec_id, 'custom_profile_curve', 'OBJ', icon='CURVE_DATA')
                # col.prop_search(obj.modifiers[shp_modifier_name], shp_input(sd[sec_id]['custom_profile_curve'][0]), bpy.data, "objects", text="", icon='CURVE_DATA')
            elif shp_read_value(sec_id, 'custom_profile_type', obj) == 'Collection':
                col.label(text="Profile Curves Collection:")
                shp_draw_prop_search(col, sec_id, 'custom_profile_collection', 'COL')
                # col.prop_search(obj.modifiers[shp_modifier_name], shp_input(sd[sec_id]['custom_profile_collection'][0]), bpy.data, "collections", text="", icon='OUTLINER_COLLECTION')
                col.separator(factor=2, type='LINE')
                shp_draw(col, sec_id, 'custom_profile_reset_scale', label="Pick Curve from Collection")
                sub = col.row(align=False)
                sub.enabled = shp_read_value(sec_id, 'custom_profile_reset_scale', obj)
                shp_draw_split(sub, sec_id, 'custom_profile_seed', "Profile Curve Seed", 5.5)

def draw_ornaments(self, context, space, show_tips=True):
    obj = context.object
    sec_id = 'ornaments_main_settings'
    pcoll = shp_preview_collections["main"]

    if obj and obj.type in {'CURVE', 'CURVES'} and shp_modifier_name in obj.modifiers:

        # Header
        shp_draw_main_section_header(space, 'ornaments', "ORNAMENTS SETTINGS", hl_1=tutorial_hl('COPY SECTION SETTINGS'), hl_2=tutorial_hl('RESET SECTION SETTINGS'))
        
        col = space.column(align=False)
        col.label(text="Enable Ornaments in:")
        row = col.row(align=False)
        row.scale_y = 1.25
        row.alert = tutorial_group_hl(['ORNAMENTS'])
        shp_draw(row, sec_id, 'ornaments_at_root', label="Root Pinch", toggle=True)
        shp_draw(row, sec_id, 'ornaments_in_bump_gaps', label="Bump Gaps", toggle=True)
        shp_draw(row, sec_id, 'ornaments_at_tip', label="Tip Pinch", toggle=True)
        
        # TIP
        if show_tips:
            box = col.box()
            box.scale_y = 0.8
            sub = box.column(align=False)
            shp_draw_tips(sub, 'tip_place_ornaments')
            shp_draw_split(sub, 'pinch_settings', 'root_pinch', "Root Pinch", 4)
            shp_draw_split(sub, 'pinch_settings', 'tip_pinch', "Tip Pinch", 4)
            shp_draw_split(sub, 'bumps_reg_settings', 'reg_bumps_strength', "Regular Bumps", 4)

        space.separator(type='LINE')
        
        # TIP
        if show_tips:
            box = col.box()
            box.scale_y = 0.8
            sub = box.column(align=False)
            shp_draw_tips(sub, 'tip_ornament_size')
            shp_draw_split(sub, 'ornaments_adjustments_settings', 'ornaments_adjust_size', "Adjust Size", 4)
        
        # Sub-panels tabs
        row = space.row(align=False)
        shp_draw(row, 'internal_utils', 'iu_ornaments_tab', label=" ", expand=True)

        # ORNAMENTS GEOMETRY sub-panel
        if shp_read_value('internal_utils', "iu_ornaments_tab", obj) == 'Geometry':
            sec_id = 'ornaments_geometry_settings'
            
            # Tab Header
            shp_draw_sub_section_header(space, sec_id, "GEOMETRY", hl_1=tutorial_hl('COPY SECTION SETTINGS'), hl_2=tutorial_hl('RESET SECTION SETTINGS'))
            
            col = space.column(align=False)
            row = col.row(align=True)
            label_width = 3.25
            shp_draw(row, sec_id, 'ornaments_type', label=" ", expand=True)
            if shp_read_value(sec_id, 'ornaments_type', obj) == 'Default':
                sub = col.column()
                sub.alert = tutorial_group_hl(['DEFAULT ORNAMENTS'])
                shp_draw_split(sub, sec_id, 'ornaments_default_type', "Ornament Type", 4.5)
                sub.separator(type='LINE')
                shp_draw_split(sub, sec_id, 'ornaments_thickness', "Thickness", label_width)
                if shp_read_value(sec_id, 'ornaments_default_type', obj) == 'Band':  # Band
                    shp_draw_split(sub, sec_id, 'ornaments_smooth', "Smooth", label_width)
                elif shp_read_value(sec_id, 'ornaments_default_type', obj) == 'Ring':  # Ring
                    pass
                elif shp_read_value(sec_id, 'ornaments_default_type', obj) == 'Coil':  # Coil
                    shp_draw_split(sub, sec_id, 'ornaments_radius', "Radius", label_width)
                    shp_draw_split(sub, sec_id, 'ornaments_frequency', "Frequency", label_width)
                elif shp_read_value(sec_id, 'ornaments_default_type', obj) == 'Scrunchie':  # Scrunchie
                    shp_draw_split(sub, sec_id, 'ornaments_scrunch', "Scrunch", label_width)
                    shp_draw_split(sub, sec_id, 'ornaments_scale', "Scale", label_width)
                    shp_draw_split(sub, sec_id, 'ornaments_scrunch_seed', "Seed", label_width)
            elif shp_read_value(sec_id, 'ornaments_type', obj) == 'Custom':
                sub = col.column()
                sub.alert = tutorial_group_hl(['CUSTOM ORNAMENTS'])
                shp_draw_split(sub, sec_id, 'ornaments_custom_type', "Ornament Type", 4.5)
                sub.separator(type='LINE')
                if shp_read_value(sec_id, 'ornaments_custom_type', obj) == 'Object':
                    sub.label(text="Ornaments Object:")
                    shp_draw_prop_search(sub, sec_id, 'ornaments_object', 'OBJ')
                    # sub.prop_search(obj.modifiers[shp_modifier_name], shp_input(sd[sec_id]['ornaments_object'][0]), bpy.data, "objects", text="", icon='OBJECT_DATAMODE')
                elif shp_read_value(sec_id, 'ornaments_custom_type', obj) == 'Collection':
                    sub.label(text="Ornaments Collection:")
                    shp_draw_prop_search(sub, sec_id, 'ornaments_collection', 'COL')
                    # sub.prop_search(obj.modifiers[shp_modifier_name], shp_input(sd[sec_id]['ornaments_collection'][0]), bpy.data, "collections", text="", icon='OUTLINER_COLLECTION')
                    shp_draw_split(sub, sec_id, 'ornaments_collection_items', "Instance", label_width)
                    shp_draw_split(sub, sec_id, 'ornaments_seed', "Items Seed", label_width)

        # ADJUST ORNAMENTS sub-panel
        if shp_read_value('internal_utils', "iu_ornaments_tab", obj) == 'Adjustments':
            sec_id = 'ornaments_adjustments_settings'
            
            # Tab Header
            shp_draw_sub_section_header(space, sec_id, "ADJUSTMENTS", hl_1=tutorial_hl('COPY SECTION SETTINGS'), hl_2=tutorial_hl('RESET SECTION SETTINGS'))
            
            col = space.column(align=False)
            col.alert = tutorial_group_hl(['ORNAMENTS ADJUSTMENTS'])
            shp_draw_split(col, sec_id, 'ornaments_adjust_size', "Adjust Size", 4)
            shp_draw_split(col, sec_id, 'ornaments_adjust_rotation', "Adjust Rotation", 4)
            col.separator(type='LINE')
            shp_draw_random_seed(col, sec_id, 'ornaments_size', label="Randomize Size")
            shp_draw_random_seed(col, sec_id, 'ornaments_rotation', label="Randomize Rotation")

        # ORNAMENTS SETTINGS sub-panel
        if shp_read_value('internal_utils', "iu_ornaments_tab", obj) == 'Settings':
            sec_id = 'ornaments_settings'
            
            # Tab Header
            shp_draw_sub_section_header(space, sec_id, "SETTINGS", hl_1=tutorial_hl('COPY SECTION SETTINGS'), hl_2=tutorial_hl('RESET SECTION SETTINGS'))

            col = space.column(align=False)
            col.alert = tutorial_group_hl(['ORNAMENTS SETTINGS'])
            shp_draw_split(col, sec_id, 'ornaments_axis', "Alignment Axis", 4.6, text=" ", expand=True)
            col.separator(type='LINE')
            shp_draw(col, sec_id, 'ornaments_center_position', label="Center Ornaments Position")
            shp_draw(col, sec_id, 'ornaments_reset_scale', label="Reset Ornaments Scale")
            sub = col.column()
            sub.enabled = shp_read_value(sec_id, "ornaments_reset_scale", obj)
            shp_draw_split(sub, sec_id, 'ornaments_scale_method', "Re-scale Method", 4.6)
            col.separator(type='LINE')
            shp_draw(col, sec_id, 'ornaments_deform', label="Deform Ornaments")

def draw_dynamics(self, context, space, show_tips=True):
    obj = context.object
    pcoll = shp_preview_collections["main"]
    sec_id = 'dyn_main_settings'

    if obj and obj.type in {'CURVE', 'CURVES'} and shp_modifier_name in obj.modifiers:

        # Header
        shp_draw_main_section_header(space, 'dynamics', "HAIR DYNAMICS", hl_1=tutorial_hl('COPY SECTION SETTINGS'), hl_2=tutorial_hl('RESET SECTION SETTINGS'))

        # Enable / disable button
        col = space.column(align=False)
        col.scale_y = 1.25
        col.alert = tutorial_group_hl(['HAIR DYNAMICS'])
        label_text = "Disable Dynamics" if shp_read_value(sec_id, "dyn_main_enable", obj) else "Enable Dynamics"
        shp_draw(col, sec_id, 'dyn_main_enable', label=label_text, toggle=True)
        space.separator(type='LINE')
        
        # TIP
        if show_tips:
            box = space.box()
            box.scale_y = 0.8
            sub = box.column(align=False)
            shp_draw_tips(sub, 'tip_dynamics_base')
            row = sub.row()
            row.label(text="Base Mesh:")
            row.operator("wm.shp_pick_base_mesh")
            shp_draw(sub, 'internal_utils', 'iu_base_mesh', "Object", icon='OBJECT_DATAMODE')
            surface_obj = shp_read_value('internal_utils', 'iu_base_mesh', obj)
            if surface_obj and surface_obj.type == 'MESH':
                shp_draw_prop_search(sub, 'internal_utils', 'iu_base_uv', 'UV', data_search=surface_obj.data, text="UV Map")
                # sub.prop_search(obj.modifiers[shp_modifier_name], shp_input(sd['internal_utils']['iu_base_uv'][0]), surface_obj.data, "uv_layers", text="UV Map", icon='GROUP_UVS')
            else:
                shp_draw(sub, 'internal_utils', 'iu_base_uv', "UV Map", icon='GROUP_UVS')

        # Sub-panels tabs
        row = space.row(align=False)
        shp_draw(row, 'internal_utils', 'iu_dynamics_tab', label=" ", expand=True)

        # MAIN DYNAMICS SETTINGS sub-panel
        if shp_read_value('internal_utils', "iu_dynamics_tab", obj) == 'Main':
            sec_id = 'dyn_main_settings'
            
            # Tab Header
            shp_draw_sub_section_header(space, sec_id, "MAIN DYNAMICS", hl_1=tutorial_hl('COPY SECTION SETTINGS'), hl_2=tutorial_hl('RESET SECTION SETTINGS'))

            col = space.column(align=False)
            col.enabled = shp_read_value(sec_id, "dyn_main_enable", obj)
            label_width = 3.0
            sub = col.column()
            sub.alert = tutorial_group_hl(['STRAND SETTINGS'])
            shp_draw_split(sub, sec_id, 'dyn_main_stiffness', "Stiffness", label_width)
            shp_draw_split(sub, sec_id, 'dyn_main_elasticity', "Elasticity", label_width)
            shp_draw_split(sub, sec_id, 'dyn_main_damping', "Damping", label_width)
            shp_draw_split(sub, sec_id, 'dyn_main_liveliness', "Liveliness", label_width)
            
            sub = col.column()
            sub.alert = tutorial_group_hl(['DYNAMICS EFFECT FACTOR'])
            shp_draw_shape_factor(sub, sec_id, 'dyn_main', label1="Effect Factor")
            
            # TIP
            if show_tips:
                box = col.box()
                box.scale_y = 0.8
                sub = box.column(align=False)
                shp_draw_tips(sub, 'tip_dynamics_twitching')
            
            col.separator(type='LINE')

            sub = col.column()
            sub.label(text="Gravity:")
            sub.alert = tutorial_group_hl(['GRAVITY'])
            shp_draw_split(sub, sec_id, 'dyn_main_gravity_strength', "Strength", label_width)
            shp_draw_split(sub, sec_id, 'dyn_main_gravity_direction', "Direction", label_width)
            col.separator(type='LINE')

            sub = col.column()
            sub.alert = tutorial_group_hl(['COLLISIONS'])
            shp_draw(sub, sec_id, 'dyn_main_collisions_enable', label="Enable Collisions")

            sub = col.column()
            sub.alert = tutorial_group_hl(['COLLISION SETTINGS'])
            sub.enabled = shp_read_value(sec_id, "dyn_main_collisions_enable", obj)
            label_width = 4.0
            shp_draw_split(sub, sec_id, 'dyn_main_collisions_object', "Collider Object", label_width)            
            shp_draw_split(sub, sec_id, 'dyn_main_collisions_distance', "Distance", label_width)
            sub = col.column()
            sub.alert = tutorial_group_hl(['COLLISION REPEL FORCE'])
            sub.enabled = shp_read_value(sec_id, "dyn_main_collisions_enable", obj)
            shp_draw_split(sub, sec_id, 'dyn_main_collisions_repel_force', "Repel Force", label_width)
            sub = col.column()
            sub.alert = tutorial_group_hl(['COLLISION QUALITY STEPS'])
            sub.enabled = shp_read_value(sec_id, "dyn_main_collisions_enable", obj)
            shp_draw_split(sub, sec_id, 'dyn_main_collisions_quality_steps', "Quality Steps", label_width)

        # WIND EFFECTS sub-panel
        if shp_read_value('internal_utils', "iu_dynamics_tab", obj) == 'Wind':
            sec_id = 'dyn_wind_effects'
            
            # Tab Header
            shp_draw_sub_section_header(space, sec_id, "WIND EFFECTS", hl_1=tutorial_hl('COPY SECTION SETTINGS'), hl_2=tutorial_hl('RESET SECTION SETTINGS'))

            col = space.column(align=False)
            col.enabled = shp_read_value('dyn_main_settings', "dyn_main_enable", obj)
            col.alert = tutorial_group_hl(['WIND EFFECTS'])
            row = col.row(align=False)
            row.scale_y = 1.25
            row.alert = tutorial_group_hl(['WIND SETTINGS'])
            shp_draw(row, sec_id, 'dyn_wind_force', "Wind Force")
            col.separator(factor=2, type='LINE')
            
            sub = col.column(align=False)
            sub.enabled = shp_read_value(sec_id, "dyn_wind_force", obj) > 0.0
            sub.alert = tutorial_group_hl(['WIND SETTINGS'])
            
            label_width = 3.25
            shp_draw_split(sub, sec_id, 'dyn_wind_sim_type', "Wind Type", label_width)
            shp_draw_split(sub, sec_id, 'dyn_wind_speed', "Wind Speed", label_width)
            sub.separator(type='LINE')
            shp_draw_split(sub, sec_id, 'dyn_wind_turbulence', "Turbulence", label_width)
            sub2 = sub.column(align=False)
            sub2.alert = tutorial_group_hl(['WIND TURBULENCE TYPE'])
            shp_draw_split(sub2, sec_id, 'dyn_wind_turbulence_type', "Turb. Type", label_width)
            sub3 = sub2.column(align=False)
            sub3.enabled = shp_read_value(sec_id, "dyn_wind_turbulence_type", obj) == 1
            shp_draw_split(sub3, sec_id, 'dyn_wind_orientation', "Orientation", label_width)
            shp_draw_split(sub3, sec_id, 'dyn_wind_scale', "Scale", label_width)
            sub2.separator(type='LINE')
            sub2 = sub.column(align=False)
            sub2.alert = tutorial_group_hl(['WIND DIRECTION'])
            row = sub2.row(align=False)
            shp_draw(row, sec_id, 'dyn_wind_use_effector', label=" ",expand=True)
            if not shp_read_value(sec_id, 'dyn_wind_use_effector', obj):
                shp_draw_split(sub2, sec_id, 'dyn_wind_direction', "Direction", label_width)
            else:
                shp_draw_split(sub2, sec_id, 'dyn_wind_effector_object', "Eff. Object", label_width)
                shp_draw_split(sub2, sec_id, 'dyn_wind_effector_method', "Method", label_width)

        # PULSE EFFECTS sub-panel
        if shp_read_value('internal_utils', "iu_dynamics_tab", obj) == 'Pulse':
            sec_id = 'dyn_pulse_effects'
            
            # Tab Header
            shp_draw_sub_section_header(space, sec_id, "PULSE EFFECTS", hl_1=tutorial_hl('COPY SECTION SETTINGS'), hl_2=tutorial_hl('RESET SECTION SETTINGS'))

            col = space.column(align=False)
            col.enabled = shp_read_value('dyn_main_settings', "dyn_main_enable", obj)
            col.alert = tutorial_group_hl('PULSE EFFECTS')
            row = col.row(align=False)
            row.scale_y = 1.25
            shp_draw(row, sec_id, 'dyn_pulse_strength', "Strength")
            col.separator(factor=2, type='LINE')
            
            sub = col.column(align=False)
            label_width = 2.5
            sub.enabled = shp_read_value(sec_id, "dyn_pulse_strength", obj) > 0.0
            shp_draw_split(sub, sec_id, 'dyn_pulse_scale', "Scale", label_width)
            shp_draw_split(sub, sec_id, 'dyn_pulse_speed', "Speed", label_width)
            shp_draw_split(sub, sec_id, 'dyn_pulse_move', "Move", label_width, text="Root ⟷ Tip")
            sub.separator(type='LINE')
            sub.label(text="Options:")
            label_width = 4.0
            shp_draw_split(sub, sec_id, 'dyn_pulse_shift', "Position Shift", label_width)
            shp_draw_split(sub, sec_id, 'dyn_pulse_twist', "Twist Amount", label_width)

        # SIM SETTINGS sub-panel
        if shp_read_value('internal_utils', "iu_dynamics_tab", obj) == 'Settings':
            sec_id = 'dyn_sim_settings'
            
            # Tab Header
            shp_draw_sub_section_header(space, sec_id, "SIMULATION SETTINGS", hl_1=tutorial_hl('COPY SECTION SETTINGS'), hl_2=tutorial_hl('RESET SECTION SETTINGS'))

            col = space.column(align=False)
            col.alert = tutorial_group_hl('SIMULATION SETTINGS')
            label_width = 4.5
            shp_draw_split(col, sec_id, 'dyn_settings_sim_points', "Simulation Points", 5)
            shp_draw(col, sec_id, 'dyn_settings_stretch', label="Affect Thickness (Stretch)")
            sub = col.column(align=False)
            sub.alert = tutorial_group_hl('GENERATED EFFECTS')
            shp_draw(sub, sec_id, 'dyn_settings_gen_only', label="Generated Effects Only")

def draw_shading(self, context, space, show_tips=True):
    obj = context.object
    pcoll = shp_preview_collections["main"]

    if obj and obj.type in {'CURVE', 'CURVES'} and shp_modifier_name in obj.modifiers:

        # Header
        shp_draw_main_section_header(space, 'shading', "SHADING SETTINGS", hl_1=tutorial_hl('COPY SECTION SETTINGS'), hl_2=tutorial_hl('RESET SECTION SETTINGS'))

        # Sub-panels tabs
        row = space.row(align=False)
        shp_draw(row, 'internal_utils', 'iu_materials_tab', label=" ", expand=True)
        
        # MATERIALS sub-panel
        if shp_read_value('internal_utils', "iu_materials_tab", obj) == 'Materials':
            sec_id = 'materials_settings'
            
            # Tab Header
            shp_draw_sub_section_header(space, sec_id, "MATERIALS", hl_1=tutorial_hl('COPY SECTION SETTINGS'), hl_2=tutorial_hl('RESET SECTION SETTINGS'))

            col = space.column(align=False)
            col.alert = tutorial_group_hl(['SHADING'])
            label_width = 3
            shp_draw_prop_search(col, sec_id, 'hair_material', 'MAT', split_label=True, label="Strands", label_width=label_width)
            shp_draw_prop_search(col, sec_id, 'flyaways_material', 'MAT', split_label=True, label="Flyaways", label_width=label_width)
            shp_draw_prop_search(col, sec_id, 'ornaments_material', 'MAT', split_label=True, label="Ornaments", label_width=label_width)
            
        # UV MAPS sub-panel
        if shp_read_value('internal_utils', "iu_materials_tab", obj) == 'UV Maps':
            sec_id = 'uv_maps_settings'
            
            # Tab Header
            shp_draw_sub_section_header(space, sec_id, "UV MAPS", hl_1=tutorial_hl('COPY SECTION SETTINGS'), hl_2=tutorial_hl('RESET SECTION SETTINGS'))

            col = space.column(align=False)
            col.alert = tutorial_group_hl(['UV SETTINGS'])
            shp_draw(col, sec_id, 'uv_switch_order', "Switch UV Order")
            col.separator(type='LINE')
            
            sub = col.column(align=False)
            sub.enabled = shp_read_value('hair_settings_misc', 'settings_fill_caps', obj)
            shp_draw_split(sub, sec_id, 'uv_caps_scale', "Scale Caps UV", 4.25)
            shp_draw_split(sub, sec_id, 'uv_caps_rotate', "Rotate Caps UV", 4.25)
            shp_draw(sub, sec_id, 'uv_caps_invert_rotation', "Invert Caps UV Rotation")
            
            col.separator(type='LINE')
            sub = col.column(align=False)
            sub.alert = tutorial_group_hl(['PACK UV ISLANDS'])
            sub.label(text="Pack UV Islands:")
            row = sub.row(align=True)
            shp_draw(row, sec_id, 'uv_pack_hair', "Strands")
            shp_draw(row, sec_id, 'uv_pack_flys', "Flyaways")
            shp_draw(row, sec_id, 'uv_pack_ornaments', "Ornaments")
            
            sub = sub.column(align=False)
            sub.enabled = shp_read_value(sec_id, 'uv_pack_hair', obj) or shp_read_value(sec_id, 'uv_pack_flys', obj) or shp_read_value(sec_id, 'uv_pack_ornaments', obj)
            shp_draw_split(sub, sec_id, 'uv_pack_margin', "Margin", 2.0)
            shp_draw(sub, sec_id, 'uv_pack_rotate', "Allow UV Islands Rotation")

        # SHADES sub-panel
        if shp_read_value('internal_utils', "iu_materials_tab", obj) == 'Shades':
            sec_id = 'shades_settings'
            
            # Tab Header
            shp_draw_sub_section_header(space, sec_id, "SHADES", hl_1=tutorial_hl('COPY SECTION SETTINGS'), hl_2=tutorial_hl('RESET SECTION SETTINGS'))

            # TIP
            if show_tips:
                box = space.box()
                box.scale_y = 0.8
                sub = box.column(align=False)
                shp_draw_tips(sub, 'tip_shades_use')

            col = space.column(align=True)
            sub = col.column(align=True)
            sub.alert = tutorial_group_hl(['COLOR SHADES'])
            label_width = 3.75
            row = sub.row(align=False)
            row.label(text="Color 1:")
            row.label(text="Color 2:")
            row = sub.row(align=False)
            shp_draw(row, sec_id, 'shades_color_1', "")
            shp_draw(row, sec_id, 'shades_color_2', "")
            sub.separator(factor=2, type='LINE')
            sub = col.column(align=True)
            sub.alert = tutorial_group_hl(['RANDOM PER STRAND SHADE'])
            shp_draw_split(sub, sec_id, 'shades_random_per_strand_seed', "Random Seed", label_width)
            
            col.separator(factor=2, type='LINE')
            sub = col.column(align=True)
            sub.alert = tutorial_group_hl(['STRAND NOISE'])
            header, panel = sub.panel("shp_ui_panel_hair_noise_shade", default_closed=True)
            header.label(text="STRANDS NOISE")
            if panel:
                col = panel.column(align=False)
                shp_draw_split(col, sec_id, 'shades_noise_scale', "Scale", label_width)
                shp_draw_split(col, sec_id, 'shades_noise_roughness', "Roughness", label_width)
                shp_draw_split(col, sec_id, 'shades_noise_contrast', "Contrast", label_width)
                shp_draw_split(col, sec_id, 'shades_noise_stretch', "Stretch", label_width)
                shp_draw_split(col, sec_id, 'shades_noise_twist', "Twist", label_width)
                shp_draw_split(col, sec_id, 'shades_noise_seed', "Seed", label_width)
            
            col.separator(type='LINE')
            sub = col.column(align=True)
            sub.alert = tutorial_group_hl(['ENDS SHADE'])
            header, panel = sub.panel("shp_ui_panel_ends_shade", default_closed=True)
            header.label(text="ENDS SHADE")
            if panel:
                col = panel.column(align=False)
                sub = col.row(align=False)
                sub.scale_y = 1.25
                shp_draw(sub, sec_id, 'shades_ends_root_shade', "Root")
                shp_draw(sub, sec_id, 'shades_ends_tip_shade', "Tip")
                
                sub = col.row(align=False)
                shp_draw(sub, sec_id, 'shades_ends_root_contrast', "Contrast")
                shp_draw(sub, sec_id, 'shades_ends_tip_contrast', "Contrast")
                
                col.separator(type='LINE')
                label_width = 4
                shp_draw_split(col, sec_id, 'shades_ends_add_noise', "Add Noise", label_width)
                shp_draw_split(col, sec_id, 'shades_ends_noise_contrast', "Noise Contrast", label_width)
            
            col.separator(type='LINE')
            sub = col.column(align=True)
            sub.alert = tutorial_group_hl(['ANISOTROPIC HIGHLIGHT'])
            header, panel = sub.panel("shp_ui_panel_hl_shade", default_closed=True)
            header.label(text="ANISOTROPIC HIGHLIGHT")
            if panel:
                col = panel.column(align=False)
                shp_draw_split(col, sec_id, 'shades_hl_move_spot', "Move Spot", label_width)
                shp_draw_split(col, sec_id, 'shades_hl_spot_size', "Spot Size", label_width)
                shp_draw_split(col, sec_id, 'shades_hl_spot_shift', "Spot Shift", label_width)
                shp_draw_split(col, sec_id, 'shades_hl_brightness', "Brightness", label_width)
                shp_draw_split(col, sec_id, 'shades_hl_detail', "Detail", label_width)
                shp_draw_split(col, sec_id, 'shades_hl_distortion', "Distortion", label_width)
                shp_draw_split(col, sec_id, 'shades_hl_distortion_scale', "Dist. Scale", label_width)
                shp_draw_split(col, sec_id, 'shades_hl_distortion_seed', "Dist. Seed", label_width)

def draw_hair_settings(self, context, space, show_tips=True):
    obj = context.object
    pcoll = shp_preview_collections["main"]

    if obj and obj.type in {'CURVE', 'CURVES'} and shp_modifier_name in obj.modifiers:
        # Header
        shp_draw_main_section_header(space, 'settings', "HAIR SETTINGS", hl_1=tutorial_hl('COPY SECTION SETTINGS'), hl_2=tutorial_hl('RESET SECTION SETTINGS'))

        # Sub-panels tabs
        row = space.row(align=False)
        shp_draw(row, 'internal_utils', 'iu_settings_tab', label=" ", expand=True)
        
        # RESOLUTION sub-panel
        if shp_read_value('internal_utils', "iu_settings_tab", obj) == 'Resolution':
            sec_id = 'hair_settings_resolution'  
             
            # Tab Header
            shp_draw_sub_section_header(space, sec_id, "RESOLUTION", hl_1=tutorial_hl('COPY SECTION SETTINGS'), hl_2=tutorial_hl('RESET SECTION SETTINGS'))

            label_width = 2.25
            col = space.column(align=False)
            sub = col.column()
            sub.alert = tutorial_group_hl(['SETTINGS & RESOLUTION'])
            row = sub.row(align=False)
            sub1 = row.row()
            sub1.alignment = 'RIGHT'
            sub1.ui_units_x = label_width
            sub1.label(text="")
            sub2 = row.row()
            sub2.label(text="Viewport")
            sub3 = sub2.row()
            sub3.alert = tutorial_hl('GIZMOS')
            shp_draw_global(sub3, 'gs_show_resolution_gizmos', "", icon='GIZMO', toggle=True)
            sub4 = row.row()
            sub4.label(text="Render")
                    
            if shp_read_value(sec_id, 'settings_sync_resolutions', obj):
                shp_draw_double_row(sub, sec_id, "Curve", "settings_resolution_curve", "settings_resolution_curve", label_width, enable_2=False)
                shp_draw_double_row(sub, sec_id, "Profile", "settings_resolution_profile", "settings_resolution_profile", label_width, enable_2=False)
            else:
                shp_draw_double_row(sub, sec_id, "Curve", "settings_resolution_curve", "settings_render_reso_curve", label_width)
                shp_draw_double_row(sub, sec_id, "Profile", "settings_resolution_profile", "settings_render_reso_profile", label_width)
            
            # TIP
            if show_tips:
                box = col.box()
                box.scale_y = 0.8
                sub = box.column(align=False)
                shp_draw_tips(sub, 'tip_high_resolution')
                shp_draw_global(sub, 'gs_groom_optimize', "Grooming Optimization")
            
            sub = col.column()            
            sub.alert = tutorial_group_hl(['SETTINGS & RESOLUTION'])
            shp_draw(sub, sec_id, 'settings_sync_resolutions', label="Sync Render to Viewport Resolution")
            shp_draw(sub, sec_id, 'settings_preview_render_reso', label="Preview Render Resolution")
            
            col.separator(type='LINE')
            sub = col.column()            
            sub.alert = tutorial_group_hl(['GEOMETRY DENSITY & TAPER'])
            header, panel = sub.panel("shp_ui_panel_reso_density", default_closed=True)
            header.label(text="DENSITY")
            if panel:
                label_width = 3
                col = panel.column(align=False)
                shp_draw_split(col, sec_id, 'settings_density_root', "Root", label_width)
                shp_draw_split(col, sec_id, 'settings_density_mid', "Mid", label_width)
                shp_draw_split(col, sec_id, 'settings_density_tip', "Tip", label_width)
                shp_draw_split(col, sec_id, 'settings_density_ornaments', "Ornaments", label_width)
                shp_draw_split(col, sec_id, 'settings_density_flys', "Flyaways", label_width)
            
            sub.separator(type='LINE')
            header, panel = sub.panel("shp_ui_panel_reso_taper", default_closed=True)
            header.label(text="TAPER POINTS")
            if panel:
                label_width = 3
                col = panel.column(align=False)
                shp_draw_split(col, sec_id, 'settings_taper_root', "Root", label_width, text="Root ⟷ Tip")
                shp_draw_split(col, sec_id, 'settings_taper_mid', "Mid", label_width, text="Root ⟷ Tip")
                shp_draw_split(col, sec_id, 'settings_taper_tip', "Tip", label_width, text="Root ⟷ Tip")

        # MISC sub-panel
        if shp_read_value('internal_utils', "iu_settings_tab", obj) == 'Misc':
            sec_id = 'hair_settings_misc'
            
            # Tab Header
            shp_draw_sub_section_header(space, sec_id, "MISCELLANEOUS", hl_1=tutorial_hl('COPY SECTION SETTINGS'), hl_2=tutorial_hl('RESET SECTION SETTINGS'))

            label_width = 4.5
            col = space.column(align=False)
            col.alert = tutorial_group_hl(['MISCELLANEOUS SETTINGS'])
            shp_draw_split(col, 'internal_utils', "iu_scale_factor", "Scale Factor", label_width)
            col.separator(type='LINE')
            sub = col.column()
            sub.alert = tutorial_group_hl(['HAIR BASE MESH'])
            row = sub.row()
            row.label(text="Base Mesh:")
            row.operator("wm.shp_pick_base_mesh")
            shp_draw(sub, 'internal_utils', 'iu_base_mesh', "Object", icon='OBJECT_DATAMODE')
            
            surface_obj = shp_read_value('internal_utils', 'iu_base_mesh', obj)
            if surface_obj and surface_obj.type == 'MESH':
                shp_draw_prop_search(sub, 'internal_utils', 'iu_base_uv', 'UV', data_search=surface_obj.data, text="UV Map")
                # sub.prop_search(obj.modifiers[shp_modifier_name], shp_input(sd['internal_utils']['iu_base_uv'][0]), surface_obj.data, "uv_layers", text="UV Map", icon='GROUP_UVS')
            else:
                shp_draw(sub, 'internal_utils', 'iu_base_uv', "UV Map", icon='GROUP_UVS')
            
            col.separator(type='LINE')
            shp_draw_split(col, sec_id, 'settings_pre_smooth', "Pre-smooth Curves", 5.5)
            shp_draw(col, sec_id, 'settings_flip_normals', label="Flip Normals")
            shp_draw(col, sec_id, 'settings_fill_caps', label="Fill Caps")
            shp_draw(col, sec_id, 'settings_use_original_thickness', label="Use Original Curve Thickness")
            col.separator(type='LINE')
            shp_draw_split(col, sec_id, 'settings_shading_style', "Shading Style", label_width)
            col.separator(type='LINE')
            sub = col.column()
            sub.alert = tutorial_group_hl(['ALIGN HAIR ROOT TO BASE'])
            shp_draw(sub, sec_id, 'settings_align_to_base', label="Align Root to Base Surface")
            sub = col.column()
            sub.alert = tutorial_group_hl(['AUTO-SQUISH HAIR ROOT'])
            shp_draw(sub, sec_id, 'settings_auto_squish_root', label="Auto-Squish Hair Root")
            sub2 = sub.column()
            sub2.enabled = shp_read_value(sec_id, 'settings_auto_squish_root', obj)
            shp_draw_split(sub2, sec_id, 'settings_auto_squish_strength', "Squish Strength", label_width)
            shp_draw_split(sub2, sec_id, 'settings_auto_squish_limit', "Limit Squish", label_width)
            
            # TIP
            if show_tips:
                box = col.box()
                box.alert = False
                box.scale_y = 0.8
                sub = box.column(align=False)
                shp_draw_tips(sub, 'tip_align_root_base')

def draw_utilities(self, context, space, show_tips=True):
    obj = context.object
    pcoll = shp_preview_collections["main"]
    shp_props = bpy.context.scene.shp_addon
    sec_id = 'utility_settings'

    if obj and obj.type in {'CURVE', 'CURVES'} and shp_modifier_name in obj.modifiers:
        # Header
        shp_draw_main_section_header(space, 'utilities', "UTILITES", hl_1=tutorial_hl('COPY SECTION SETTINGS'), hl_2=tutorial_hl('RESET SECTION SETTINGS'))
        
        # OPTIMIZATION
        col = space.column()
        col.alert = tutorial_group_hl(['OPTIMIZATION UTILITY'])
        header, panel = col.panel("shp_ui_panel_optimization", default_closed=True)
        header.label(text="OPTIMIZATION")
        if panel:
            col = panel.column(align=False)
            col.prop(shp_props, 'enable_set_active_modifier_funtion', text="Optimize SHP Modifier")
            col.separator(type='LINE', factor=2.0)
            shp_draw_global(col, 'gs_groom_optimize', "Grooming Optimization")
            shp_draw_split_global(col, 'gs_optimization_strength', "Optimization Strength", 6)
            col.separator(type='LINE', factor=2.0)
            row = col.row(align=True)
            row.enabled = False
            bake_status = "Hair Geometry Baked." if shp_read_value('internal_utils', 'iu_is_geo_baked', obj) else "Bake Hair Geometry:"
            row.label(text=bake_status)
            row = col.row(align=True)
            row.operator('wm.shp_bake_hair_geo', text="Bake Hair Geo").mode='BAKE'
            sub = row.row(align=True)
            sub.enabled = shp_read_value('internal_utils', 'iu_is_geo_baked', obj)
            sub.operator('wm.shp_bake_hair_geo', text="", icon='TRASH').mode='DELETE'
            

        # MESH & ARMATURE
        col = space.column()
        col.alert = tutorial_group_hl(['MESH & ARMATURE UTILITY', 'GENERATE ARMATURE'])
        header, panel = col.panel("shp_ui_panel_mesh_convert", default_closed=True)
        header.label(text="MESH & ARMATURE")
        if panel:
            label_width = 5.5
            col = panel.column(align=False)
            shp_draw_global(col, 'gs_armature_generate', "Generate Armature")
            
            col = panel.column(align=False)
            col.enabled = shp_read_value_global('gs_armature_generate')

            row = col.row()     # Armature Type tab
            shp_draw_global(row, 'gs_armature_type', " ", expand=True)
            
            if shp_read_value_global('gs_armature_type') == "Normal":
                shp_draw_split(col, sec_id, 'utils_arm_bone_count', "Bone Count", label_width)
            else:
                shp_draw_split(col, sec_id, 'utils_arm_bbone_handles', "Number of Handles", label_width)
                shp_draw_split(col, sec_id, 'utils_arm_bbone_segments', "B-Bone Segments", label_width)
            
            col.separator(type='LINE')
            shp_draw_split(col, sec_id, 'utils_arm_taper_armature', "Taper Armature", label_width)
            shp_draw_split(col, sec_id, 'utils_arm_start', "Armature Start", label_width)
            shp_draw_split(col, sec_id, 'utils_arm_end', "Armature End", label_width)
            
            col.separator(type='LINE')
            shp_draw(col, sec_id, 'utils_arm_use_curls', "Use Curled Curve")

            col.separator(type='LINE')
            shp_draw_global(col, 'gs_armature_parent', "Parent to Armature")
            sub = col.row()
            sub.enabled = shp_read_value_global('gs_armature_parent')
            shp_draw_split_global(sub, 'gs_armature_parent_method', "Method", 2.5)
            
            col.separator(type='LINE')
            header, sub_panel = col.panel("shp_ui_panel_bone_names", default_closed=True)
            header.label(text="BONE NAMING")
            if sub_panel:
                col = sub_panel.column(align=False)
                shp_draw_split_global(col, 'gs_name_bone', "Bones Name", label_width)
                shp_draw_split_global(col, 'gs_name_bbone', "B-Bones Name", label_width)
                shp_draw_split_global(col, 'gs_name_bbone_handle', "Handles Name", label_width)

            col.separator(type='LINE')
            row = col.row()
            shp_draw(row, sec_id, 'utils_arm_preview_armature', "Preview Armature")
            sub = row.row()
            sub.enabled = shp_read_value(sec_id, 'utils_arm_preview_armature', obj)
            shp_draw(sub, sec_id, 'utils_arm_preview_scale', "Scale")
            
            row = panel.row(align=False)
            row.scale_y = 1.25
            row.operator("wm.shp_mesh_convert", text="Convert to Mesh")
            sub = row.row()
            sub.enabled = shp_read_value_global('gs_armature_generate')
            sub.operator("wm.shp_generate_armature", text="Armature Only")

        # RANDOMIZER
        col = space.column()
        col.alert = tutorial_group_hl(['RANDOMIZER UTILITY'])
        header, panel = col.panel("shp_ui_panel_randomizer", default_closed=True)
        header.label(text="RANDOMIZER")
        if panel:
            col = panel.column(align=False)
            label_width = 3.75
            col.enabled = False
            col.label(text="Use the buttons with the randomizer", icon_value=pcoll["shp_icon_random"].icon_id)
            col.label(text="icon to quickly generate hair geometry.")

        # CUSTOM HAIR GEOMETRY
        col = space.column()
        col.alert = tutorial_group_hl(['CUSTOM HAIR GEOMETRY'])
        header, panel = col.panel("shp_ui_panel_custom_mesh", default_closed=True)
        header.label(text="CUSTOM HAIR GEOMETRY")
        if panel:
            col = panel.column(align=False)
            label_width = 3.75
            
            shp_draw(col, sec_id, 'utils_cust_geo_enable', "Use Custom Hair Geometry")
            sub = col.column()
            sub.enabled = shp_read_value(sec_id, 'utils_cust_geo_enable', obj)
            shp_draw_split(sub, sec_id, 'utils_cust_geo_object', "Object", label_width)
            shp_draw_split(sub, sec_id, 'utils_cust_geo_axis', "Deform Axis", label_width, text=" ", expand=True)
            shp_draw(sub, sec_id, 'utils_cust_geo_rescale', "Re-scale Custom Geo")
            
            box = sub.box()
            box.scale_y = 0.75
            sub = box.column(align=False)
            shp_draw(sub, 'hair_settings_misc', 'settings_use_original_thickness', label="Use Original Curve Thickness")

        # SPLIT CURVES
        col = space.column()
        col.alert = tutorial_group_hl(['SPLIT CURVES UTILITY'])
        header, panel = col.panel("shp_ui_panel_split_curves", default_closed=True)
        header.label(text="SPLIT CURVES")
        if panel:
            col = panel.column(align=False)
            
            if obj.type == 'CURVES':
                spline_count = len(obj.data.curves)
            elif obj.type == 'CURVE':
                spline_count = len(obj.data.splines)
            
            # Count the splines in selected curves
            selected_objects = context.selected_objects
            curves_count = len(selected_objects)
            spline_count = 0
            for obj in selected_objects:
                if obj.type == 'CURVES':
                    spline_count += len(obj.data.curves)
                elif obj.type == 'CURVE':
                    spline_count += len(obj.data.splines)
            
            if obj.mode != 'OBJECT':
                info_text = "Go to 'Object Mode'."
                col.enabled = False
            else:
                if spline_count == 0:
                    info_text = "Object doesn't have any curves."
                    col.enabled = False
                elif spline_count == 1:
                    info_text = "Object has only 1 curve."
                    col.enabled = False
                else:
                    info_text = "Split Curve Objects Enabled:"
            
            row = col.row()
            row.enabled = False
            row.label(text=info_text, icon='INFO_LARGE')
            
            row = col.row()
            row.scale_y = 1.25
            button_label = f"Split {curves_count} Object/s into {spline_count} Curves"
            row.operator("wm.shp_split_curves", text=button_label)

        # UPDATE SETUP VERSION
        col = space.column()
        # col.alert = tutorial_group_hl(['ADD_STEP_HERE'])
        header, panel = col.panel("shp_ui_panel_update_setup", default_closed=True)
        header.label(text="UPDATE SETUP VERSION")
        if panel:
            node_tree_version = shp_get_node_tree_version(output_type='INT')
            add_on_version = int(f'{shp_addon_version[0]}{shp_addon_version[1]}{shp_addon_version[2]}')
            
            col = panel.column(align=False)
            sub = col.column()
            sub.scale_y = 0.8
            sub.enabled = False
            sub.label(text=f'Node setup version: {shp_get_node_tree_version(output_type="STR")}')
            sub.label(text=f'Add-on version: v{shp_addon_version[0]}.{shp_addon_version[1]}.{shp_addon_version[2]}')
            
            box = sub.box()
            sub2 = box.column()
            sub2.scale_y = 0.8
            if node_tree_version < add_on_version and node_tree_version > 410:
                sub2.label(text=f'Update:  v{shp_get_node_tree_version(output_type="STR")}  🡪  v{shp_addon_version[0]}.{shp_addon_version[1]}.{shp_addon_version[2]}')
            if node_tree_version < 410:
                for label in split_string('Node tree versions created before Blender 4.5 are not supported. Update utility works with node tree versions > 4.1.0', 44):
                    sub2.label(text=label)
            if node_tree_version > add_on_version:
                for label in split_string('⚠ Warning: Add-on version is lower than the currently applied node tree version. Updating might cause errors.', 44):
                    sub2.label(text=label)
                
            if node_tree_version == add_on_version:
                sub2.label(text='Setup matches installed version.')
                sub2.label(text='No update required.')
            
            sub = col.row()
            sub.scale_y = 1.25
            sub.enabled = node_tree_version != add_on_version and node_tree_version >= 410
            sub.operator("wm.shp_update_setup")

def shp_main_panel_ui(self, context):
    pcoll = shp_preview_collections["main"]
    shp_props = context.scene.shp_addon
    dt_props = getattr(context.scene, "dt_addon", None)
    obj = context.object
    layout = self.layout
    sec_id = 'main_settings'
    
    shp_ui_draw = True
    if dt_props:
        shp_ui_draw = dt_props.context_tool == 'SHP'
    else:
        shp_ui_draw = True
    
    if shp_ui_draw:
        # Action Button
        col = layout.column(align=True)
        row = col.row(align=True)
        row.scale_y = 1.1
        
        sub = row.row(align=True)
        if obj and not obj.hide_get() and not obj.hide_viewport and obj.type in {'MESH', 'CURVE', 'CURVES'}:
            if shp_modifier_name in obj.modifiers:
                sub.operator("wm.shp_remove_setup", text="Remove SHP Setup", icon_value=pcoll["shp_icon_setup_remove"].icon_id)
            else:
                if obj.type == 'MESH':
                    sub.alert = tutorial_group_hl(['ADD THE FIRST HAIR CURVE'])
                    sub.operator("wm.add_curve_panel", text="Add Strand", icon_value=pcoll["shp_icon_add_new_curve"].icon_id)
                elif obj.type in {'CURVE', 'CURVES'}:
                    sub.operator("wm.shp_add_setup", text="Add SHP setup", icon_value=pcoll["shp_icon_setup_add"].icon_id)
        else:
             sub.enabled = False
             sub.operator("wm.shp_add_setup", text="Select Mesh or Curve")
        
        # Action Toggles
        col.separator(factor=0.5)
        row = col.row(align=True)
        row.alignment = 'CENTER'
        
        # Quck Menu
        sub = row.row(align=True)
        sub.alert = tutorial_group_hl(['QUICK MENU'])
        if obj and shp_modifier_name in obj.modifiers:
            sub.operator("wm.shp_call_pie_menu", text='', icon_value=pcoll["shp_icon_quick_menu"].icon_id)
        else:
            sub.label(icon_value=pcoll["shp_icon_quick_menu"].icon_id)
        sub.separator(factor=0.5)
                
        # SHP Preferences
        sub = row.row(align=True)
        sub.alert = tutorial_hl('ADD-ON PREFERENCES')
        sub.operator("wm.shp_addon_preferences", text="", icon='PREFERENCES')
        sub.separator(factor=0.5)
        
        # SHP Info
        sub = row.row(align=True)
        sub.alert = tutorial_hl('ADDITIONAL INFO')
        sub.operator("wm.shp_addon_info", text="", icon='INFO_LARGE')
        sub.separator(factor=2.0)
        
        # Show Gizmos
        sub = row.row(align=True)
        sub.alert = tutorial_group_hl(['GIZMOS'])
        if obj and shp_modifier_name in obj.modifiers:
            shp_draw_global(sub, 'gs_toggle_gizmos', "", icon='GIZMO', toggle=True)
            sub2 = sub.row(align=True)
            sub2.alignment = 'CENTER'
            sub2.enabled = shp_read_value_global('gs_toggle_gizmos')
            sub2.popover(panel="SHP_PT_GizmosMenu", text="", icon='NONE')
        else:
            sub.label(icon='GIZMO')
        sub.separator(factor=0.5)
        
        # View Wireframe
        sub = row.row(align=True)
        sub.alert = tutorial_hl('VIEW WIREFRAME')
        if obj:
            sub.prop(obj, 'show_wire', text="", toggle=True, icon_value=pcoll["shp_icon_wire"].icon_id)
        else:
            sub.label(icon_value=pcoll["shp_icon_wire"].icon_id)
        sub.separator(factor=0.5)
        
        # Duplicate Strand
        sub = row.row(align=True)
        sub.alert = tutorial_hl('DUPLICATE STRAND')
        if obj and obj.type in {'CURVE', 'CURVES'}:
            sub.operator("wm.shp_duplicate_strand", text='', icon_value=pcoll["shp_icon_curve_duplicate"].icon_id)
        else:
            sub.label(icon_value=pcoll["shp_icon_curve_duplicate"].icon_id)
        sub.separator(factor=0.5)
        
        # Reset All
        sub = row.row(align=True)
        sub.alert = tutorial_hl('RESET ALL')
        if obj and shp_modifier_name in obj.modifiers:
            sub.operator("wm.shp_reset_sections", text='', icon_value=pcoll["shp_icon_curve_refresh"].icon_id).section = 'all'
        else:
            sub.label(icon_value=pcoll["shp_icon_curve_refresh"].icon_id)

        # Tutorial
        if shp_props.display_tutorial:
            draw_tutorial(self, context, layout)
        
        # Presets
        if shp_props.display_presets:
            col = layout.column(align=False)
            col.alert = tutorial_group_hl(['PRESETS', 'CUSTOM PRESETS'])
            
            row = col.row(align=False)
            row.label(text="Presets:")
            row.prop(shp_props, "preset_tab", text=" ", expand=True)
            
            row = col.row(align=True)
            sub = row.row(align=True)
            # Default Presets
            if shp_props.preset_tab == 'DEFAULT':
                sub.prop(shp_props, "default_presets", text="")
            # Custom Presets
            elif shp_props.preset_tab == 'CUSTOM':
                preset_enable = shp_preset_exits(shp_props.selected_preset, context)
                
                sub2 = sub.row(align=True)
                sub2.enabled = preset_enable
                sub2.prop(shp_props, "selected_preset", text="")
                sub2.operator("wm.shp_remove_hair_preset", text="", icon='REMOVE')
                sub2 = sub.row(align=True)
                
                sub2.enabled = True if obj and obj.type in {'CURVE', 'CURVES'} and shp_modifier_name in obj.modifiers else False
                sub2.operator("wm.shp_save_hair_preset", text="", icon='ADD')
                sub2 = sub.row(align=True)
                sub2.operator("wm.shp_reload_hair_presets", text="", icon='FILE_REFRESH')
            row.separator()
            sub = row.row(align=True)
            sub.enabled = True if obj and obj.type in {'CURVE', 'CURVES'} and shp_modifier_name in obj.modifiers else False

            if shp_props.preset_tab == 'DEFAULT':
                sub.operator("wm.shp_apply_hair_preset", text="", icon='CHECKMARK').preset_type = 'DEFAULT'
            else:
                sub.operator("wm.shp_apply_hair_preset", text="", icon='CHECKMARK').preset_type = 'CUSTOM'
        
        # Main Settings
        if obj and obj.type in {'CURVE', 'CURVES'} and shp_modifier_name in obj.modifiers:            
            col = layout.column(align=True)
            col.separator(type='LINE')
            
            # Mirrors
            flow = col.grid_flow(row_major=True, columns=2, even_columns=True, even_rows=True, align=False)
            flow.alert = tutorial_hl('MIRROR')
            row = flow.row(align=True)
            sub = row.row()
            sub.ui_units_x = 2.5
            sub.alignment = 'LEFT'
            sub.label(text="Mirror")
            shp_draw(row, sec_id, "main_mirror_x", "X", toggle=True)
            shp_draw(row, sec_id, "main_mirror_y", "Y", toggle=True)
            shp_draw(row, sec_id, "main_mirror_z", "Z", toggle=True)
            
            row = flow.row(align=False)
            # modf = obj.modifiers[shp_modifier_name]
            # modf_inputs = modf.properties.inputs
            socket = getattr(obj.modifiers[shp_modifier_name].properties.inputs, sd[sec_id]["main_mirror_ghosting"][0])
            
            # row.prop(socket, "value", text="Ghosting", icon_value=pcoll["shp_icon_mirror_ghost"].icon_id, toggle=True)
            sub = row.row(align=True)
            sub.enabled = obj.type == 'CURVES'
            sub.operator("wm.shp_apply_mirror", text="Apply")
            col.separator(type='LINE')

            row = col.row(align=True)
            row.scale_y = 1.25
            
            sub = row.row(align=True)
            sub.alert = tutorial_hl('MAIN SETTINGS')
            shp_draw(sub, sec_id, "main_thickness", "Thickness")
            sub = row.row(align=True)
            sub.alert = tutorial_hl('GIZMOS')
            shp_draw_global(sub, 'gs_show_scale_gizmos', "", icon='GIZMO', toggle=True)
            
            row.separator()
            
            sub = row.row(align=True)
            sub.alert = tutorial_hl('MAIN SETTINGS')
            shp_draw(sub, sec_id, "main_rotation", "Rotation")
            sub = row.row(align=True)
            sub.alert = tutorial_hl('GIZMOS')
            shp_draw_global(sub, 'gs_show_twist_gizmos', "", icon='GIZMO', toggle=True)
            col.separator(factor=1.0)
            
            # Bake Warning
            if shp_read_value('internal_utils', 'iu_is_geo_baked', obj):
                box = col.box()
                box.scale_y = 0.8
                sub = box.column(align=True)
                sub.enabled = False
                label_index = 0
                warn_text = split_string("Hair geometry is baked. Some settings will not work properly. Delete the hair bake to restore regular functionality.", 40)
                for row_label in warn_text:
                    if label_index == 0:
                        sub.label(text=row_label, icon='ERROR')
                    else:
                        sub.label(text=row_label)
                    label_index += 1
                box.operator('wm.shp_bake_hair_geo', text="Delete Hair Geo Bake", icon='TRASH').mode='DELETE'

            # Section Buttons
            flow = col.grid_flow(row_major=False, columns=2, even_columns=True, even_rows=True, align=True)
            flow.scale_y = 0.81
            sub = flow.row(align=True)
            sub.alert = tutorial_group_hl(['SETTINGS SECTIONS', 'SHAPE', 'SUB-SECTIONS', 'ENDS SHAPE', 'SHAPE FACTOR WIDGET', 'PINCH'])
            sub.operator("wm.shp_select_section", text="SHAPE", icon_value=pcoll["shp_icon_curve_shape"].icon_id, depress=shp_props.section_selector == 'SHAPE').section_id = 'SHAPE'
            sub = flow.row(align=True)
            sub.alert = tutorial_group_hl(['SETTINGS SECTIONS', 'TWIST', 'WAVINESS', 'CUSTOM TWIST'])
            sub.operator("wm.shp_select_section", text="TWIST", icon_value=pcoll["shp_icon_curve_twist"].icon_id, depress=shp_props.section_selector == 'TWIST').section_id = 'TWIST'
            sub = flow.row(align=True)
            sub.alert = tutorial_group_hl(['SETTINGS SECTIONS', 'HAIR BUMPS', 'REGULAR BUMPS', 'RANDOM BUMPS', 'SURFACE BUMPS', 'SUB-STRANDS'])
            sub.operator("wm.shp_select_section", text="BUMPS", icon_value=pcoll["shp_icon_curve_bumps"].icon_id, depress=shp_props.section_selector == 'BUMPS').section_id = 'BUMPS'
            sub = flow.row(align=True)
            sub.alert = tutorial_group_hl(['SETTINGS SECTIONS', 'CURLS'])
            sub.operator("wm.shp_select_section", text="CURLS", icon_value=pcoll["shp_icon_curve_curls"].icon_id, depress=shp_props.section_selector == 'CURLS').section_id = 'CURLS'
            sub = flow.row(align=True)
            sub.alert = tutorial_group_hl(['SETTINGS SECTIONS', 'BRAIDS', 'BRAID BODY', 'BRAID STRANDS', 'BRAID ROOTS'])
            sub.operator("wm.shp_select_section", text="BRAID", icon_value=pcoll["shp_icon_curve_braid"].icon_id, depress=shp_props.section_selector == 'BRAID').section_id = 'BRAID'
            sub = flow.row(align=True)
            sub.alert = tutorial_group_hl(['SETTINGS SECTIONS', 'FRIZZ', 'SPLIT TIP', 'SPLIT TIP SETTINGS', 'FRIZZ STRAND', 'FLYAWAYS'])
            sub.operator("wm.shp_select_section", text="FRIZZ", icon_value=pcoll["shp_icon_frizz"].icon_id, depress=shp_props.section_selector == 'FRIZZ').section_id = 'FRIZZ'
            sub = flow.row(align=True)
            sub.alert = tutorial_group_hl(['SETTINGS SECTIONS', 'PROFILE', 'PROFILE TYPE', 'CUSTOM PROFILE'])
            sub.operator("wm.shp_select_section", text="PROFILE", icon_value=pcoll["shp_icon_curve_profile"].icon_id, depress=shp_props.section_selector == 'PROFILE').section_id = 'PROFILE'
            sub = flow.row(align=True)
            sub.alert = tutorial_group_hl(['SETTINGS SECTIONS', 'ORNAMENTS', 'ORNAMENTS GEOMETRY', 'DEFAULT ORNAMENTS', 'CUSTOM ORNAMENTS', 'ORNAMENTS ADJUSTMENTS', 'ORNAMENTS SETTINGS'])
            sub.operator("wm.shp_select_section", text="ORNAMENTS", icon_value=pcoll["shp_icon_curve_ornament"].icon_id, depress=shp_props.section_selector == 'ORNAMENTS').section_id = 'ORNAMENTS'
            sub = flow.row(align=True)
            sub.alert = tutorial_group_hl(['SETTINGS SECTIONS', 'HAIR DYNAMICS', 'MAIN HAIR DYNAMICS', 'STRAND SETTINGS', 'DYNAMICS EFFECT FACTOR', 'GRAVITY', 'COLLISIONS', 'COLLISION SETTINGS', 'COLLISION REPEL FORCE', 'COLLISION QUALITY STEPS', 'WIND EFFECTS', 'WIND SETTINGS', 'WIND TURBULENCE TYPE', 'WIND DIRECTION', 'PULSE EFFECTS', 'SIMULATION SETTINGS', 'GENERATED EFFECTS'])
            sub.operator("wm.shp_select_section", text="DYNAMICS", icon_value=pcoll["shp_icon_curve_dynamics"].icon_id, depress=shp_props.section_selector == 'DYNAMICS').section_id = 'DYNAMICS'
            sub = flow.row(align=True)
            sub.alert = tutorial_group_hl(['SETTINGS SECTIONS', 'SHADING', 'UV MAPS', 'UV SETTINGS', 'PACK UV ISLANDS', 'SHADES', 'COLOR SHADES', 'RANDOM PER STRAND SHADE', 'STRAND NOISE', 'ENDS SHADE', 'ANISOTROPIC HIGHLIGHT', 'MORE SHADES AND MASKS'])
            sub.operator("wm.shp_select_section", text="SHADING", icon_value=pcoll["shp_icon_curve_uv"].icon_id, depress=shp_props.section_selector == 'SHADING').section_id = 'SHADING'
            sub = flow.row(align=True)
            sub.alert = tutorial_group_hl(['SETTINGS SECTIONS', 'SETTINGS & RESOLUTION', 'GEOMETRY DENSITY & TAPER', 'MISCELLANEOUS SETTINGS', 'HAIR BASE MESH', 'ALIGN HAIR ROOT TO BASE', 'AUTO-SQUISH HAIR ROOT'])
            sub.operator("wm.shp_select_section", text="SETTINGS", icon_value=pcoll["shp_icon_curve_settings"].icon_id, depress=shp_props.section_selector == 'SETTINGS').section_id = 'SETTINGS'
            sub = flow.row(align=True)
            sub.alert = tutorial_group_hl(['SETTINGS SECTIONS', 'UTILITIES', 'OPTIMIZATION UTILITY', 'MESH & ARMATURE UTILITY', 'GENERATE ARMATURE', 'RANDOMIZER UTILITY', 'CUSTOM HAIR GEOMETRY', 'SPLIT CURVES UTILITY'])
            sub.operator("wm.shp_select_section", text="UTILITIES", icon_value=pcoll["shp_icon_utilities"].icon_id, depress=shp_props.section_selector == 'UTILITIES').section_id = 'UTILITIES'

            # Sections UI
            box = col.box()
            if shp_props.section_selector == 'SHAPE':
                draw_shape(self, context, box, show_tips=shp_props.display_tips)
            if shp_props.section_selector == 'TWIST':
                draw_twist(self, context, box, show_tips=shp_props.display_tips)
            if shp_props.section_selector == 'BUMPS':
                draw_bumps(self, context, box, show_tips=shp_props.display_tips)
            if shp_props.section_selector == 'CURLS':
                draw_curls(self, context, box, show_tips=shp_props.display_tips)
            if shp_props.section_selector == 'BRAID':
                draw_braid(self, context, box, show_tips=shp_props.display_tips)
            if shp_props.section_selector == 'FRIZZ':
                draw_frizz(self, context, box, show_tips=shp_props.display_tips)
            if shp_props.section_selector == 'PROFILE':
                draw_profile(self, context, box, show_tips=shp_props.display_tips)
            if shp_props.section_selector == 'ORNAMENTS':
                draw_ornaments(self, context, box, show_tips=shp_props.display_tips)
            if shp_props.section_selector == 'DYNAMICS':
                draw_dynamics(self, context, box, show_tips=shp_props.display_tips)
            if shp_props.section_selector == 'SHADING':
                draw_shading(self, context, box, show_tips=shp_props.display_tips)
            if shp_props.section_selector == 'SETTINGS':
                draw_hair_settings(self, context, box, show_tips=shp_props.display_tips)
            if shp_props.section_selector == 'UTILITIES':
                draw_utilities(self, context, box, show_tips=shp_props.display_tips)

# OPERATORS

class SHP_OT_AddSetup(bpy.types.Operator): 
    bl_idname = "wm.shp_add_setup"
    bl_label = 'Add SHP Setup'
    bl_description = 'Add the "Stylized Hair PRO" setup to the selected curve/s'

    def execute(self, context):
        scale_factor = shp_get_curve_avg_length(context.object)
        shp_add_setup(all=True, set_scale=True)
        if shp_get_spline_count(context.object):
            shp_set_value('internal_utils', 'iu_scale_factor', scale_factor, context.object)
        return {'FINISHED'}

class SHP_OT_RemoveSetup(bpy.types.Operator): 
    bl_idname = "wm.shp_remove_setup"
    bl_label = 'Remove SHP Setup'
    bl_description = 'Remove the "Stylized Hair PRO" setup from the selected curve/s'

    def execute(self, context):
        shp_remove_setup()
        return {'FINISHED'}

class SHP_OT_AddStrand(bpy.types.Operator):
    bl_idname = "wm.shp_add_strand"
    bl_label = "Add Strand"
    bl_description = "Add a hair curve to the selected mesh"

    length: bpy.props.StringProperty(name="Add Strand", description="") #type:ignore

    def execute(self, context):
        if context.object:
            shp_props = context.scene.shp_addon
            points = shp_props.hair_curve_points
            if self.length == 'SHORT':
                length_factor = 0.2
            elif self.length == 'LONG':
                length_factor = 1
            else:
                length_factor = 0.5
            shp_add_curve(length_factor, points, context)
            shp_add_setup(all=True, set_scale=False)
            
            shp_pick_base_mesh(context.object)
            
            brush = bpy.context.tool_settings.curves_sculpt.brush.curves_sculpt_settings
            scale_factor = brush.curve_length
            shp_set_value('internal_utils', 'iu_scale_factor', scale_factor, context.object)
        return {'FINISHED'}

class SHP_OT_AddCurvePanel(bpy.types.Operator):
    bl_idname = "wm.add_curve_panel"
    bl_label = "Add New Hair Curve"
    bl_description = "Add a new hair curve to the selected mesh"

    sec_id: bpy.props.StringProperty(name="Section ID", description="The string identifier of the section") #type:ignore

    def invoke(self, context, event):
        return context.window_manager.invoke_props_dialog(self, width=250)

    def draw(self, context):
        shp_props = context.scene.shp_addon
        layout = self.layout
        
        col = layout.column(align=False)
        row = col.row(align=True)
        row.prop(shp_props, "hair_curve_length", text=" ", expand=True)
        row = col.row(align=False)
        sub = row.row()
        sub.alignment='RIGHT'
        sub.ui_units_x = 5
        sub.label(text="Number of Points")
        sub = row.row()
        sub.prop(shp_props, "hair_curve_points", text="")

    def execute(self, context):
        if context.object:
            bpy.ops.wm.shp_add_strand(length=context.scene.shp_addon.hair_curve_length)
        return {'FINISHED'}
    
class SHP_OT_DuplicateStrand(bpy.types.Operator):
    bl_idname = "wm.shp_duplicate_strand"
    bl_label = "Duplicate Strand"
    bl_description = "Duplicate the selected strand"

    def execute(self, context):
        obj = context.object
        bpy.ops.object.mode_set(mode='OBJECT')
        if obj and obj.type in {'CURVE', 'CURVES'}:
            bpy.ops.object.duplicate(linked=False)
            if obj.type in {'CURVES'}:
                bpy.ops.object.mode_set(mode='SCULPT_CURVES')
                try:
                    bpy.ops.brush.asset_activate(asset_library_type='ESSENTIALS', asset_library_identifier="", relative_asset_identifier="brushes\\essentials_brushes-curve_sculpt.blend\\Brush\\Slide")
                except Exception:
                    pass
                bpy.ops.curves.select_all(action='SELECT')
        return {'FINISHED'}

class SHP_OT_SelectSection(bpy.types.Operator): 
    bl_idname = "wm.shp_select_section"
    bl_label = "Select Section"
    bl_description = "Select the section to display"

    section_id: bpy.props.StringProperty(name="Section ID", description="The section label") #type:ignore

    def execute(self, context):
        context.scene.shp_addon.section_selector = self.section_id
        return {'FINISHED'}

class SHP_OT_ResetSection(bpy.types.Operator):
    bl_idname = "wm.shp_reset_section"
    bl_label = "Reset"
    bl_description = "Reset the Section"
    bl_options = {'REGISTER', 'UNDO'}

    section: bpy.props.StringProperty(name="Section ID", description="The string identifier of the section") #type:ignore

    def execute(self, context):
        selected_objects = context.selected_objects
        if not selected_objects:
            if context.object:
                selected_objects.append(context.object)
        
        for obj in selected_objects:
            shp_reset_section(self.section, obj)
            shp_refresh_modifier(obj)
        
        return {'FINISHED'}

class SHP_OT_ResetMultipleSections(bpy.types.Operator):
    bl_idname = "wm.shp_reset_sections"
    bl_label = "Reset"
    bl_description = "Reset the Section"
    bl_options = {'REGISTER', 'UNDO'}

    section: bpy.props.StringProperty(name="Section ID", description="The string identifier of the section") #type:ignore

    def execute(self, context):
        selected_objects = context.selected_objects
        if not selected_objects:
            if context.object:
                selected_objects.append(context.object)
    
        for obj in selected_objects:
            shp_reset_multiple_sections(self.section, obj, all_sections=self.section == 'all')
            shp_refresh_modifier(obj)
        
        return {'FINISHED'}

class SHP_OT_CopySection(bpy.types.Operator):
    bl_idname = "wm.shp_copy_section"
    bl_label = "Copy to Selected"
    bl_description = "Copy the section settings to the selected strands"

    sec_id: bpy.props.StringProperty(name="Section ID", description="The string identifier of the section") #type:ignore

    def execute(self, context):
        selected_curves = context.selected_objects
        active_curve = context.active_object

        for sub_section in sd['sub_sections'][self.sec_id]:
            for setting in sd[sub_section].keys():
                setting_value = shp_read_value(sub_section, setting, curve=active_curve)
                for curve in selected_curves:
                    shp_set_value(sub_section, setting, setting_value, curve=curve)
                    shp_refresh_modifier(curve)
        
        return {'FINISHED'}

class SHP_OT_CopySubSection(bpy.types.Operator):
    bl_idname = "wm.shp_copy_sub_section"
    bl_label = "Copy to Selected"
    bl_description = "Copy the sub-section settings to the selected strands"

    sec_id: bpy.props.StringProperty(name="Section ID", description="The string identifier of the section") #type:ignore

    def execute(self, context):
        selected_curves = context.selected_objects
        active_curve = context.active_object

        for setting in sd[self.sec_id].keys():
            setting_value = shp_read_value(self.sec_id, setting, curve=active_curve)
            for curve in selected_curves:
                shp_set_value(self.sec_id, setting, setting_value, curve=curve)
                shp_refresh_modifier(curve)
        
        return {'FINISHED'}

class SHP_OT_ApplyMirror(bpy.types.Operator):
    bl_idname = "wm.shp_apply_mirror"
    bl_label = "Apply Mirror"
    bl_description = "Apply the mirrors of the current hair curve"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        shp_props = bpy.context.scene.shp_addon
        hair_curve = context.object
        
        if hair_curve and hair_curve.type == 'CURVES':
            # Halt the "Set modifier Active" function
            halt_setting = shp_props.halt_set_active_modifier_function
            shp_props.halt_set_active_modifier_function = True
            # # Restore the Halt "Set modifier Active" function setting value
            # shp_props.halt_set_active_modifier_function = halt_setting
            
            bpy.ops.object.modifier_add(type='NODES') # Add new GN modifier
            mirror_modf = hair_curve.modifiers.active

            bpy.ops.object.modifier_move_to_index(modifier=mirror_modf.name, index=0)
            mirror_modf.node_group = bpy.data.node_groups[".SHP_mirror_curve"]

            # Set the same mirrors from the SHP
            x_mirror = shp_read_value('main_settings', 'main_mirror_x', hair_curve)
            y_mirror = shp_read_value('main_settings', 'main_mirror_y', hair_curve)
            z_mirror = shp_read_value('main_settings', 'main_mirror_z', hair_curve)
            
            mirror_modf.properties.inputs.Socket_2.value = x_mirror
            mirror_modf.properties.inputs.Socket_3.value = y_mirror
            mirror_modf.properties.inputs.Socket_4.value = z_mirror
            mirror_modf.properties.inputs.Socket_5.value = hair_curve.data.surface
            mirror_modf.properties.inputs.Socket_6.value = hair_curve.data.surface_uv_map

            # Remove the mirrors from SHP
            shp_set_value('main_settings', 'main_mirror_x', False, hair_curve)
            shp_set_value('main_settings', 'main_mirror_y', False, hair_curve)
            shp_set_value('main_settings', 'main_mirror_z', False, hair_curve)

            # Apply the Mirror GN modifier
            bpy.ops.object.modifier_apply(modifier=mirror_modf.name)
            
            # Restore the Halt "Set modifier Active" function setting value
            shp_props.halt_set_active_modifier_function = halt_setting
        return {'FINISHED'}

class SHP_OT_SplitCurves(bpy.types.Operator):
    bl_idname = "wm.shp_split_curves"
    bl_label = "Split Curves"
    bl_description = "Split a curve with multiple splines into separate objects"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        
        shp_props = bpy.context.scene.shp_addon
        
        # Halt the "Set modifier Active" function
        halt_setting = shp_props.halt_set_active_modifier_function
        shp_props.halt_set_active_modifier_function = True
        
        selected_objects = context.selected_objects
        for obj in selected_objects:
            if obj.type == 'CURVES':
                spline_count = len(obj.data.curves)
                tmp_hair_curves = [] # Temporary curves list
                
                # Select working curve
                bpy.ops.object.select_all(action='DESELECT')    # Deselect
                obj.select_set(True)                            # Select
                context.view_layer.objects.active = obj         # Set Active
                
                # Add the temporary Split Curves GN modifier
                bpy.ops.object.modifier_add(type='NODES')                                   # Add GN modifier
                split_modf = obj.modifiers.active                                           # Set the modifier as active
                bpy.ops.object.modifier_move_to_index(modifier=split_modf.name, index=0)    # Move modifier to the top
                split_modf.node_group = bpy.data.node_groups[".SHP_split_curves"]           # Add the 'Split Curves' node group

                tmp_hair_curves.append(context.object)  # Add the curve to the temporary list
                for _ in range(spline_count - 1):       # Create copies of the curve objects and add them to the temporary list
                    bpy.ops.object.duplicate_move()
                    tmp_hair_curves.append(context.object)

                # Remove all but one curve and apply the temporary modifier
                curve_index = 0
                for curve in tmp_hair_curves:
                    # Select working curve
                    bpy.ops.object.select_all(action='DESELECT')    # Deselect
                    curve.select_set(True)                          # Select
                    context.view_layer.objects.active = curve       # Set Active

                    context.object.modifiers.active.properties.inputs.Socket_2.value = curve_index  # Select the spline index to leave
                    bpy.ops.object.modifier_apply(modifier=context.object.modifiers.active.name)    # Apply the modifier
            
                    curve_index += 1
            
            elif obj.type == 'CURVE':
                spline_count = len(obj.data.splines)
                tmp_hair_curves = [obj] # Temporary curves list
                
                # Select working curve
                bpy.ops.object.select_all(action='DESELECT')    # Deselect
                obj.select_set(True)                            # Select
                context.view_layer.objects.active = obj         # Set Active
                
                for _ in range(spline_count - 1):
                    bpy.ops.object.duplicate_move()
                    tmp_hair_curves.append(bpy.context.object)

                spline_index_to_delete = 0
                for curve in tmp_hair_curves:
                    spline_index = 0
                    for spline in curve.data.splines:
                        if spline_index != spline_index_to_delete:
                            curve.data.splines.remove(spline)
                        spline_index += 1
                    spline_index_to_delete += 1
        
        # # Restore the Halt "Set modifier Active" function setting value
        shp_props.halt_set_active_modifier_function = halt_setting
        return {'FINISHED'}

class SHP_OT_PickBaseMesh(bpy.types.Operator):
    bl_idname = "wm.shp_pick_base_mesh"
    bl_label = "Auto-select Base"
    bl_description = "Automatically pick the Base Mesh and Base Surface UV when the curve is a 'Hair Curves' object"

    def execute(self, context):
        for obj in context.selected_objects:
            shp_pick_base_mesh(obj)
        # shp_refresh_modifier()
        
        return {'FINISHED'}

class SHP_OT_MeshConvert(bpy.types.Operator):
    bl_idname = "wm.shp_mesh_convert"
    bl_label = "Convert Geometry to Mesh"
    bl_description = "Applies the 'Stylized Hair PRO' modifier and converts the geometry to a mesh."
    bl_options = {'REGISTER', 'UNDO'}
    
    
    def execute(self, context):
        bpy.ops.object.mode_set(mode='OBJECT') # Set to Object mode first
        if shp_read_value_global('gs_armature_generate'):
            transform = context.scene.transform_orientation_slots[0].type   # Switch to global transform orientation
            context.scene.transform_orientation_slots[0].type = 'GLOBAL'
            shp_generate_armature(context, armature_only=False)
            context.scene.transform_orientation_slots[0].type = transform
        else:
            bpy.ops.object.convert(target='MESH')
        return {'FINISHED'}

class SHP_OT_GenerateArmature(bpy.types.Operator):
    bl_idname = "wm.shp_generate_armature"
    bl_label = "Generate Armature"
    bl_description = "Generate only the armature, without converting the geometry to a mesh"
    bl_options = {'REGISTER', 'UNDO'}
    
    def execute(self, context):
        bpy.ops.object.mode_set(mode='OBJECT') # Set to Object mode first
        if shp_read_value_global('gs_armature_generate'):
            transform = context.scene.transform_orientation_slots[0].type   # Switch to global transfor orientation
            context.scene.transform_orientation_slots[0].type = 'GLOBAL'
            shp_generate_armature(context, armature_only=True)
            context.scene.transform_orientation_slots[0].type = transform
        return {'FINISHED'}

class SHP_OT_SelectAllSections(bpy.types.Operator): 
    bl_idname = "wm.shp_select_all_sections"
    bl_label = 'Select/Deselect All'
    bl_description = 'Select/deselct all sections'
    
    select: bpy.props.BoolProperty(name="Selection Type", description="", default=True) #type:ignore

    def execute(self, context):
        shp_select_all_sections(self.select, context)
        return {'FINISHED'}

class SHP_OT_SaveHairPreset(bpy.types.Operator): 
    bl_idname = "wm.shp_save_hair_preset"
    bl_label = 'Save New Preset'
    bl_description = 'Save the current hair settings as a new preset'

    def invoke(self, context, event):
        return context.window_manager.invoke_props_dialog(self, width=250)

    def draw(self, context):
        shp_props = context.scene.shp_addon
        layout = self.layout
        col = layout.column(align=False)
        col.label(text="Save current hair settings as a new preset.")
        col.label(text="Preset Name:")
        col.activate_init = True
        col.prop(shp_props, "preset_name", text="")
        col.prop(shp_props, 'sec_all', text="Include all Sections")

        if not shp_props.sec_all:
            col.label(text="Select which sections to include in the preset:")
            row = col.row()
            row.operator("wm.shp_select_all_sections", text="Select All").select=True
            row.operator("wm.shp_select_all_sections", text="Deselect All").select=False
            flow = col.grid_flow(row_major=False, columns=2, align=True)
            for item in shp_get_sections_to_preset(True, context):
                flow.prop(shp_props, f'sec_{item}', text=item.upper())
        
    def execute(self, context):
        shp_add_presets_file()
        shp_save_preset(context)
        shp_load_presets()
        context.scene.shp_addon.preset_name = ""
        return {'FINISHED'}

class SHP_OT_RemoveHairPreset(bpy.types.Operator): 
    bl_idname = "wm.shp_remove_hair_preset"
    bl_label = 'Remove Preset'
    bl_description = 'Remove the selected preset'

    def invoke(self, context, event):
        return context.window_manager.invoke_props_dialog(self, width=250)

    def draw(self, context):
        shp_props = context.scene.shp_addon
        preset_name = shp_props.selected_preset
        layout = self.layout
        layout.label(text=f'Remove "{preset_name}" preset?')
        
    def execute(self, context):
        shp_add_presets_file()
        shp_remove_preset(context)
        shp_load_presets()
        if shp_user_presets:
            context.scene.shp_addon.selected_preset = shp_user_presets[0]
        else:
            context.scene.shp_addon.selected_preset = "NONE"
        return {'FINISHED'}

class SHP_OT_ReloadHairPresets(bpy.types.Operator): 
    bl_idname = "wm.shp_reload_hair_presets"
    bl_label = 'Reload Presets'
    bl_description = 'Reload custom presets list'

    def execute(self, context):
        shp_load_presets()
        return {'FINISHED'}

class SHP_OT_ApplyHairPreset(bpy.types.Operator): 
    bl_idname = "wm.shp_apply_hair_preset"
    bl_label = 'Apply Preset'
    bl_description = 'Apply the selected preset'
    
    preset_type: bpy.props.StringProperty(name="Preset Type", description="Default/Custom preset type", default='DEFAULT') #type:ignore

    def execute(self, context):
        shp_apply_preset(self.preset_type == 'DEFAULT', context)
        for obj in context.selected_objects:
            shp_refresh_modifier(obj)
        return {'FINISHED'}

class SHP_OT_RandomizeSection(bpy.types.Operator): 
    bl_idname = "wm.shp_randomize_section"
    bl_label = 'Randomize Section'
    bl_description = 'Quickly generate random settings for the current section'
    
    settings_set: bpy.props.StringProperty(name="Settings Set", description="", default='CURLS') #type:ignore

    def execute(self, context):
        selected_objects = context.selected_objects
        if not selected_objects:
            if context.object:
                selected_objects.append(context.object)
        
        for obj in selected_objects:
            # Random Curls
            if self.settings_set == 'curls':
                shp_randomize_setting('curls_settings', 'curls_frequency',      obj, min=12.0, max=60.0)
                shp_randomize_setting('curls_settings', 'curls_radius',         obj, min=0.8, max=1.5)
                shp_randomize_setting('curls_settings', 'curls_stylize',        obj, min=0, max=3, int=True)
                shp_randomize_setting('curls_settings', 'curls_random',         obj, min=0.25, max=1)
                shp_randomize_setting('curls_settings', 'curls_seed',           obj, min=-100, max=100)
                shp_randomize_setting('curls_settings', 'curls_flatten',        obj, min=0, max=0.3)
                shp_randomize_setting('curls_settings', 'curls_flatten_dir',    obj, min=-3.14, max=3.14)
                shp_randomize_setting('curls_settings', 'curls_shape_factor',   obj, min=0.45, max=0.6)
                shp_randomize_setting('curls_settings', 'curls_contrast',       obj, min=0.75, max=1)
            # Random Braid
            elif self.settings_set == 'braid':
                shp_randomize_setting('pinch_settings', 'tip_pinch',                obj, min=0.3, max=0.7)
                shp_randomize_setting('pinch_settings', 'tip_pinch_width',          obj, min=0.0, max=0.1)
                shp_randomize_setting('pinch_settings', 'tip_pinch_tightness',      obj, min=0.6, max=0.8)
                shp_randomize_setting('pinch_settings', 'tip_pinch_shape',          obj, min=0.5, max=1)
                shp_randomize_setting('pinch_settings', 'body_pinch_tightness_tip', obj, min=0.6, max=0.8)
                shp_randomize_setting('pinch_settings', 'body_pinch_shape_tip',     obj, min=0.5, max=1)
                
                shp_randomize_setting('braid_body_settings', 'braid_frequency',     obj, min=5.0, max=30.0)
                shp_randomize_setting('braid_body_settings', 'braid_taper',         obj, min=0.2, max=0.8)
                shp_randomize_setting('braid_body_settings', 'braid_taper_degree',  obj, min=1.5, max=2.5)
                
                shp_randomize_setting('braid_strands_settings', 'braid_strands_random',   obj, min=0.6, max=1)
                shp_randomize_setting('braid_strands_settings', 'braid_strands_seed',     obj, min=-100, max=100)
                shp_randomize_setting('braid_strands_settings', 'braid_strands_pinch',    obj, min=0.5, max=0.9)
                shp_randomize_setting('braid_strands_settings', 'braid_strand_1_flatten',  obj, min=0.1, max=0.4)
                shp_randomize_setting('braid_strands_settings', 'braid_strand_2_flatten',  obj, min=0.1, max=0.4)
                shp_randomize_setting('braid_strands_settings', 'braid_strand_3_flatten',  obj, min=0.1, max=0.4)
                
                shp_randomize_setting('braid_roots_settings', 'braid_root_1_scale',     obj, min=1, max=1.5)
                shp_randomize_setting('braid_roots_settings', 'braid_root_2_scale',     obj, min=1, max=1.5)
                shp_randomize_setting('braid_roots_settings', 'braid_root_3_scale',     obj, min=1, max=1.5)
                shp_randomize_setting('braid_roots_settings', 'braid_root_1_flatten',   obj, min=0.4, max=0.6)
                shp_randomize_setting('braid_roots_settings', 'braid_root_2_flatten',   obj, min=0.4, max=0.6)
                shp_randomize_setting('braid_roots_settings', 'braid_root_3_flatten',   obj, min=0.4, max=0.6)
            # Random Tip Split
            elif self.settings_set == 'frz_splt_tip_settings':
                sec_id = 'frz_splt_tip_settings'
                shp_randomize_setting(sec_id, 'frz_splt_tip_split',             obj, min=0.7,   max=1)
                shp_randomize_setting(sec_id, 'frz_splt_tip_splits_count',      obj, min=2,     max=6, int=True)
                shp_randomize_setting(sec_id, 'frz_splt_tip_seed_major',        obj, min=-100,  max=100)
                shp_randomize_setting(sec_id, 'frz_splt_tip_bend_limit',        obj, min=0.1,  max=0.4)
                shp_randomize_setting(sec_id, 'frz_splt_tip_split_random',      obj, min=0.0,   max=0.4)
                shp_randomize_setting(sec_id, 'frz_splt_tip_split_seed',        obj, min=-100,  max=100)
                shp_randomize_setting(sec_id, 'frz_splt_tip_depth_random',      obj, min=0.25,   max=0.75)
                shp_randomize_setting(sec_id, 'frz_splt_tip_depth_seed',        obj, min=-100,  max=100)
                shp_randomize_setting(sec_id, 'frz_splt_tip_length_random',     obj, min=0.1,   max=.3)
                shp_randomize_setting(sec_id, 'frz_splt_tip_length_seed',       obj, min=-100,  max=100)
                shp_randomize_setting(sec_id, 'frz_splt_tip_tilt_random',       obj, min=0.1,   max=0.2)
                shp_randomize_setting(sec_id, 'frz_splt_tip_tilt_seed',         obj, min=-100,  max=100)    

                tip_size = shp_read_value('shape_settings', 'tip_size', obj)
                average_bend_value = remap_value(tip_size, 0.25, 0.9, 0.9, 0.1)
                bend_value = uniform(average_bend_value / 5, average_bend_value)
                shp_set_value(sec_id, 'frz_splt_tip_bend_random', bend_value, obj)

            shp_refresh_modifier(obj)
        return {'FINISHED'}

class SHP_OT_TutNextStep(bpy.types.Operator):
    bl_idname = "wm.tut_next_step"
    bl_label = "Next"
    bl_description = "Go to next step"

    def execute(self, context):
        shp_props = context.scene.shp_addon
        cur_step = shp_props.tutorial_steps
        shp_props.tutorial_steps_counter = int(cur_step.replace('STEP_', '')) + 1
        shp_props.tutorial_steps = f"STEP_{shp_props.tutorial_steps_counter}"
        return {'FINISHED'}

class SHP_OT_TutPreviousStep(bpy.types.Operator):
    bl_idname = "wm.tut_previous_step"
    bl_label = "Back"
    bl_description = "Go back a step"

    def execute(self, context):
        shp_props = context.scene.shp_addon
        cur_step = shp_props.tutorial_steps
        shp_props.tutorial_steps_counter = int(cur_step.replace('STEP_', '')) - 1
        shp_props.tutorial_steps = f"STEP_{shp_props.tutorial_steps_counter}"
        return {'FINISHED'}

class SHP_OT_TutCancel(bpy.types.Operator):
    bl_idname = "wm.tut_cancel"
    bl_label = "Cancel"
    bl_description = "Cancel the tutorial"

    def execute(self, context):
        shp_props = context.scene.shp_addon
        shp_props.tutorial_steps_counter = 0
        shp_props.tutorial_steps = f"STEP_{shp_props.tutorial_steps_counter}"
        return {'FINISHED'}

class SHP_OT_AddOnPreferences(bpy.types.Operator):
    bl_idname = "wm.shp_addon_preferences"
    bl_label = 'SHP Preferences'
    bl_description = 'Open the add-on preferences panel'
    
    def invoke(self, context, event):
        return context.window_manager.invoke_popup(self, width=250)
    
    def draw(self, context):
        shp_props = context.scene.shp_addon
        layout = self.layout
        layout.label(text="SHP Preferences")
        
        if context.object and shp_modifier_name in context.object.modifiers:
            col = layout.column(align=False)
            col.prop(bpy.data.node_groups[shp_modifier_name].nodes['shp_shell'].inputs[359], "default_value", text="Global Scale Factor")
        
        col = layout.column(align=False)
        col.prop(shp_props, "display_tutorial", text="Show Tutorial")
        col.prop(shp_props, "display_tips", text="Show Tips")
        col.prop(shp_props, "display_presets", text="Show Presets")
        
        row = col.row(align=False)
        sub = row.row()
        sub.alignment='LEFT'
        sub.ui_units_x = 5.5
        sub.label(text="Quick Menu Layout")
        sub = row.row()
        sub.prop(shp_props, "quick_menu_layout", text="")

    def execute(self, context):
        return {'FINISHED'}

class SHP_OT_AddOnInfo(bpy.types.Operator):
    bl_idname = "wm.shp_addon_info"
    bl_label = 'SHP Info'
    bl_description = 'Open the add-on info panel'

    def execute(self, context):
        return {'FINISHED'}

    def invoke(self, context, event):
        def draw(self, context):
            layout = self.layout
            col = layout.column(align=False)
            pcoll = shp_preview_collections["main"]

            col.label(text="Stylized Hair PRO - Hair editing for Blender")
            col.label(text=f"Version {shp_addon_version[0]}.{shp_addon_version[1]}.{shp_addon_version[2]}")
            col.separator()
            col.label(text=f"Compatible with Blender {shp_required_blender_version[0]}.{shp_required_blender_version[1]}.{shp_required_blender_version[2]} and above.")
            col.separator()
            col.label(text="by Dean Zarkov")
            col.operator("wm.url_open", text="dean@deantools.dev", icon_value=pcoll["shp_icon_mail"].icon_id).url = "mailto:dean@deantools.dev"
            col.operator("wm.url_open", text="YouTube - @denoa3D", icon_value=pcoll["shp_icon_yt"].icon_id).url = "https://www.youtube.com/@denoa3D"
            col.separator()
            col.label(text="For more info:")
            col.operator("wm.url_open", text="Visit the Main SHP webpage", icon='URL').url = "https://www.deantools.dev/blender-tools/stylized-hair-pro"
            col.operator("wm.url_open", text="Join the SHP Discord group", icon_value=pcoll["shp_icon_discord"].icon_id).url = "https://discord.gg/SRXSuAwJ3g"

        bpy.context.window_manager.popup_menu(draw, title="SHP Info", icon='INFO_LARGE')
        return {'FINISHED'}

class SHP_OT_UpdateSetup(bpy.types.Operator): 
    bl_idname = "wm.shp_update_setup"
    bl_label = 'Update Setup Version'
    bl_description = 'Update the Stylized Hair PRO setup to the currently installed version'

    def execute(self, context):
        current_shp_version = shp_get_node_tree_version(output_type='LIST')
        
        if current_shp_version != shp_addon_version:
            objs_with_shp = shp_get_objects()       # List with all curves with the SHP setup
            tmp_global_values = {}                  # Temporary dict to store global data
            tmp_shp_inputs_data = {}                # Temporary dict to store curve modifier data
            modf_indices = {}                       # Dict with the indices of the SHP modifiers in the stack
            
            # Get the global settings
            for setting in sd['global_settings'].keys():
                tmp_global_values[setting] = shp_read_value_global(setting)
            
            # # Get the global scale factor
            # gsf_value = shp_read_value_global('gs_global_scale_factor')
            
            # Get modifiers data and remove from curve
            for obj in objs_with_shp:
                tmp_shp_inputs_data[obj] = shp_get_inputs(obj)              # Store the modifier inputs values per curve
                modf_indices[obj] = obj.modifiers.find(shp_modifier_name)   # Store the index of the modifier in the stack
                obj.modifiers.remove(obj.modifiers[shp_modifier_name])      # Remove the SHP setup from all curves
            
            # Remove all SHP node groups
            shp_remove_all_groups()
            
            # Import the new setup and apply to all curves
            blend_file_path = os.path.join(os.path.dirname(__file__), "SHP_assets.blend")           # Assets Path

            if shp_modifier_name not in bpy.data.node_groups:                                       # Append the GN node group
                with bpy.data.libraries.load(blend_file_path, link=False) as (data_from, data_to):
                    if shp_modifier_name in data_from.node_groups:
                        data_to.node_groups = [shp_modifier_name]

            if shp_modifier_name in bpy.data.node_groups:                                           # Set fake user
                bpy.data.node_groups[shp_modifier_name].use_fake_user = True

            for obj in objs_with_shp:
                if shp_modifier_name not in obj.modifiers:
                    if obj and obj.type in {'CURVE', 'CURVES'}:
                        obj.modifiers.new(shp_modifier_name, 'NODES')
                        obj.modifiers[shp_modifier_name].node_group = bpy.data.node_groups[shp_modifier_name]
                        obj.modifiers[shp_modifier_name].show_group_selector = False
                        obj.modifiers[shp_modifier_name].show_expanded = False

            # Restore the modifier inputs values for all curves
            for obj in tmp_shp_inputs_data.keys():
                modifier = obj.modifiers[shp_modifier_name]
                for socket in tmp_shp_inputs_data[obj].keys():
                    modf_input = getattr(modifier.properties.inputs, socket)
                    try:
                        setattr(modf_input, "value", tmp_shp_inputs_data[obj][socket])
                    except Exception:
                        pass
                    # modifier[socket] = tmp_shp_inputs_data[obj][socket]
                obj.modifiers.move(obj.modifiers.find(shp_modifier_name), modf_indices[obj])
            
            # Restore global values
            for setting in tmp_global_values.keys():
                shp_set_value_global(setting, tmp_global_values[setting])
            
            # # Restore global scale factor
            # bpy.data.node_groups[shp_modifier_name].nodes['shp_global_scale_factor'].inputs[1].default_value = gsf_value
        
        return {'FINISHED'}

class SHP_OT_DisableAllGizmos(bpy.types.Operator):
    bl_idname = "wm.shp_disable_all_gizmos"
    bl_label = "Disable All Gizmos"
    bl_description = "Disable all gizmos visibility"
    
    def execute(self, context):
        shp_disable_all_gizmos()
        return {'FINISHED'}

class SHP_OT_BakeHairGeo(bpy.types.Operator):
    bl_idname = "wm.shp_bake_hair_geo"
    bl_label = "Bake Hair Geo"
    bl_description = "Bake the generated hair geometry to optimize viewport performance"

    mode: bpy.props.StringProperty(name="Bake Mode", description="Bake or delete bake", default='BAKE') #type:ignore
    
    def execute(self, context):
        if context.object and context.selected_objects and self.mode == 'BAKE':
            shp_disable_all_gizmos()
        for obj in context.selected_objects:
            shp_bake_hair_geo(obj, mode=self.mode)
        return {'FINISHED'}

class SHP_OT_HideDToolsMessage(bpy.types.Operator): 
    bl_idname = "wm.shp_hide_dt_message"
    bl_label = "Hide DeanTools Message"
    bl_description = "Hide this message"
    bl_options = {'REGISTER', 'UNDO'}
    
    def execute(self, context):
        context.scene.shp_addon.dt_show_message = False
        return {'FINISHED'}

# MAIN PANEL
class SHP_PT_MainPanel(bpy.types.Panel):
    bl_label = f"Stylized Hair PRO v{shp_addon_version[0]}.{shp_addon_version[1]}.{shp_addon_version[2]}"
    bl_idname = "SHP_PT_MainPanel"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = 'DT'
    bl_parent_id = ""

    def draw(self, context):
        layout = self.layout
        if context.scene.shp_addon.dt_show_message:
            box = layout.box()
            col = box.column()
            col.scale_y = 0.9
            label_text="This tool is part of DeanTools. To get the best experience, download the DeanTools Main Hub add-on:"
            shp_draw_multiline_text(label_text, col, max_chars=40, first_line_subtract=5, y_scale=0.8, icon='INFO')
            row = col.row(align=True)
            row.alignment = 'EXPAND'
            row.operator("wm.url_open", text="More Info...", icon='URL', depress=False).url = "https://www.deantools.dev/home"
            row.separator(factor=0.5)
            sub = row.row(align=True)
            sub.alignment = 'RIGHT'
            sub.operator("wm.shp_hide_dt_message", text="Hide")
        
        shp_main_panel_ui(self, context)


# PIE MENU
class SHP_MT_PieMenu(bpy.types.Menu):
    bl_label = "Stylized Hair PRO"

    def draw(self, context):
        shp_props = context.scene.shp_addon
        pcoll = shp_preview_collections["main"]
        obj = context.object
        enable_condition = obj and obj.type in {'CURVE', 'CURVES'} and shp_modifier_name in obj.modifiers
        
        # sculpt_tool = context.tool_settings.curves_sculpt.brush
        sculpt_tool = getattr(context.tool_settings.curves_sculpt, "brush", False)
        def brush_depress(brush_name):
            try:
                return sculpt_tool.name == brush_name
            except AttributeError:
                return False
        
        layout = self.layout
        
        pie = layout.menu_pie()
        if enable_condition:
            pie.enabled = True
        else:
            pie.enabled = False
        
        if enable_condition:
            if shp_props.quick_menu_layout == 'DETAILED':
                # LEFT
                col = pie.column(align=True)
                col.ui_units_x = 6
                col.operator("wm.section_pie_menu", text="SHAPE", icon_value=pcoll["shp_icon_curve_shape"].icon_id).sec_id = 'SHAPE'
                col.operator("wm.section_pie_menu", text="TWIST", icon_value=pcoll["shp_icon_curve_twist"].icon_id).sec_id = 'TWIST'
                col.operator("wm.section_pie_menu", text="BUMPS", icon_value=pcoll["shp_icon_curve_bumps"].icon_id).sec_id = 'BUMPS'
                col.operator("wm.section_pie_menu", text="CURLS", icon_value=pcoll["shp_icon_curve_curls"].icon_id).sec_id = 'CURLS'
                col.operator("wm.section_pie_menu", text="BRAID", icon_value=pcoll["shp_icon_curve_braid"].icon_id).sec_id = 'BRAID'
                col.operator("wm.section_pie_menu", text="FRIZZ", icon_value=pcoll["shp_icon_frizz"].icon_id).sec_id = 'FRIZZ'
                # RIGHT
                col = pie.column(align=True)
                col.ui_units_x = 6
                col.operator("wm.section_pie_menu", text="PROFILE", icon_value=pcoll["shp_icon_curve_profile"].icon_id).sec_id = 'PROFILE'
                col.operator("wm.section_pie_menu", text="ORNAMENTS", icon_value=pcoll["shp_icon_curve_ornament"].icon_id).sec_id = 'ORNAMENTS'
                col.operator("wm.section_pie_menu", text="DYNAMICS", icon_value=pcoll["shp_icon_curve_dynamics"].icon_id).sec_id = 'DYNAMICS'
                col.operator("wm.section_pie_menu", text="SHADING", icon_value=pcoll["shp_icon_curve_uv"].icon_id).sec_id = 'SHADING'
                col.operator("wm.section_pie_menu", text="SETTINGS", icon_value=pcoll["shp_icon_curve_settings"].icon_id).sec_id = 'SETTINGS'
                col.operator("wm.section_pie_menu", text="UTILITIES", icon_value=pcoll["shp_icon_utilities"].icon_id).sec_id = 'UTILITIES'
                # BOTTOM
                col = pie.column()
                col.enabled = obj and obj.type == 'CURVES' and shp_modifier_name in obj.modifiers
                row = col.row()
                row.scale_y = 1.5
                row.operator("wm.shp_select_brush", text="Slide",   icon_value=pcoll["shp_icon_edit_slide"].icon_id,   depress=brush_depress('Slide')).brush_id       = 'Slide'
                row.operator("wm.shp_select_brush", text="Smooth",  icon_value=pcoll["shp_icon_edit_smooth"].icon_id,  depress=brush_depress('Smooth')).brush_id      = 'Smooth'
                row.operator("wm.shp_select_brush", text="Comb",    icon_value=pcoll["shp_icon_edit_comb"].icon_id,    depress=brush_depress('Comb')).brush_id        = 'Comb'
                row.operator("wm.shp_select_brush", text="Pull",    icon_value=pcoll["shp_icon_edit_grab"].icon_id,    depress=brush_depress('Pull Tips')).brush_id   = 'Pull Tips'
                row.operator("wm.shp_select_brush", text="Length",  icon_value=pcoll["shp_icon_edit_length"].icon_id,  depress=brush_depress('Grow/Shrink')).brush_id = 'Grow/Shrink'
                # TOP
                col = pie.column()
                col.ui_units_x = 16.5
                    # Thickness and Rotation
                flow = col.grid_flow(row_major=True, columns=2, even_columns=True, even_rows=True, align=False)
                flow.scale_y = 1.5
                sub = flow.row(align=True)
                shp_draw(sub, 'main_settings', "main_thickness", "Thickness")
                shp_draw_global(sub, 'gs_show_scale_gizmos', "", icon='GIZMO', toggle=True)
                sub = flow.row(align=True)
                shp_draw(sub, 'main_settings', "main_rotation", "Rotation")
                shp_draw_global(sub, 'gs_show_twist_gizmos', "", icon='GIZMO', toggle=True)
                    # Action Toggles
                row = col.row(align=False)
                sub = row.row(align=True)
                shp_draw_global(sub, 'gs_toggle_gizmos', "Gizmos", icon='GIZMO', toggle=True)
                sub2 = sub.row(align=True)
                sub2.alignment = 'CENTER'
                sub2.enabled = shp_read_value_global('gs_toggle_gizmos')
                sub2.popover(panel="SHP_PT_GizmosMenu", text="", icon='NONE')
                if obj:
                    row.prop(obj, 'show_wire', text="Wire", toggle=True, icon_value=pcoll["shp_icon_wire"].icon_id)
                else:
                    row.label(text="Wire", icon_value=pcoll["shp_icon_wire"].icon_id)
                row.operator("wm.shp_duplicate_strand", text="Duplicate", icon_value=pcoll["shp_icon_curve_duplicate"].icon_id)
                row.operator("wm.shp_reset_sections", text="Reset All", icon_value=pcoll["shp_icon_curve_refresh"].icon_id).section = 'all'
            
            elif shp_props.quick_menu_layout == 'COMPACT':
                # LEFT
                col = pie.column(align=False)
                col.ui_units_x = 2
                col.scale_y = 1.15
                col.operator("wm.section_pie_menu", text="", icon_value=pcoll["shp_icon_curve_shape"].icon_id).sec_id = 'SHAPE'
                col.operator("wm.section_pie_menu", text="", icon_value=pcoll["shp_icon_curve_twist"].icon_id).sec_id = 'TWIST'
                col.operator("wm.section_pie_menu", text="", icon_value=pcoll["shp_icon_curve_bumps"].icon_id).sec_id = 'BUMPS'
                col.operator("wm.section_pie_menu", text="", icon_value=pcoll["shp_icon_curve_curls"].icon_id).sec_id = 'CURLS'
                col.operator("wm.section_pie_menu", text="", icon_value=pcoll["shp_icon_curve_braid"].icon_id).sec_id = 'BRAID'
                col.operator("wm.section_pie_menu", text="", icon_value=pcoll["shp_icon_frizz"].icon_id).sec_id = 'FRIZZ'
                # RIGHT
                col = pie.column(align=False)
                col.ui_units_x = 2
                col.scale_y = 1.15
                col.operator("wm.section_pie_menu", text="", icon_value=pcoll["shp_icon_curve_profile"].icon_id).sec_id = 'PROFILE'
                col.operator("wm.section_pie_menu", text="", icon_value=pcoll["shp_icon_curve_ornament"].icon_id).sec_id = 'ORNAMENTS'
                col.operator("wm.section_pie_menu", text="", icon_value=pcoll["shp_icon_curve_dynamics"].icon_id).sec_id = 'DYNAMICS'
                col.operator("wm.section_pie_menu", text="", icon_value=pcoll["shp_icon_curve_uv"].icon_id).sec_id = 'SHADING'
                col.operator("wm.section_pie_menu", text="", icon_value=pcoll["shp_icon_curve_settings"].icon_id).sec_id = 'SETTINGS'
                col.operator("wm.section_pie_menu", text="", icon_value=pcoll["shp_icon_utilities"].icon_id).sec_id = 'UTILITIES'
                # BOTTOM
                col = pie.column()
                col.enabled = obj and obj.type == 'CURVES' and shp_modifier_name in obj.modifiers
                row = col.row()
                row.alignment = 'CENTER'
                row.scale_x = 1.25
                row.scale_y = 1.5
                row.operator("wm.shp_select_brush", text="", icon_value=pcoll["shp_icon_edit_slide"].icon_id,   depress=brush_depress('Slide')).brush_id       = 'Slide'
                row.operator("wm.shp_select_brush", text="", icon_value=pcoll["shp_icon_edit_smooth"].icon_id,  depress=brush_depress('Smooth')).brush_id      = 'Smooth'
                row.operator("wm.shp_select_brush", text="", icon_value=pcoll["shp_icon_edit_comb"].icon_id,    depress=brush_depress('Comb')).brush_id        = 'Comb'
                row.operator("wm.shp_select_brush", text="", icon_value=pcoll["shp_icon_edit_grab"].icon_id,    depress=brush_depress('Pull Tips')).brush_id   = 'Pull Tips'
                row.operator("wm.shp_select_brush", text="", icon_value=pcoll["shp_icon_edit_length"].icon_id,  depress=brush_depress('Grow/Shrink')).brush_id = 'Grow/Shrink'
                # TOP
                col = pie.column()
                    # Thickness and Rotation
                sub = col.row(align=True)
                shp_draw(sub, 'main_settings', "main_thickness", "Thickness")
                shp_draw_global(sub, 'gs_show_scale_gizmos', "", icon='GIZMO', toggle=True)
                sub = col.row(align=True)
                shp_draw(sub, 'main_settings', "main_rotation", "Rotation")
                shp_draw_global(sub, 'gs_show_twist_gizmos', "", icon='GIZMO', toggle=True)
                    # Action Toggles
                row = col.row(align=False)
                row.alignment = 'CENTER'
                sub = row.row(align=True)
                shp_draw_global(sub, 'gs_toggle_gizmos', "", icon='GIZMO', toggle=True)
                sub2 = sub.row(align=True)
                sub2.alignment = 'CENTER'
                sub2.enabled = shp_read_value_global('gs_toggle_gizmos')
                sub2.popover(panel="SHP_PT_GizmosMenu", text="", icon='NONE')
                if obj:
                    row.prop(obj, 'show_wire', text="", toggle=True, icon_value=pcoll["shp_icon_wire"].icon_id)
                else:
                    row.label(text="", icon_value=pcoll["shp_icon_wire"].icon_id)
                row.operator("wm.shp_duplicate_strand", text="", icon_value=pcoll["shp_icon_curve_duplicate"].icon_id)
                row.operator("wm.shp_reset_sections", text="", icon_value=pcoll["shp_icon_curve_refresh"].icon_id).section = 'all'

class SHP_OT_CallPieMenu(bpy.types.Operator): 
    bl_idname = "wm.shp_call_pie_menu"
    bl_label = "SHP Quick Menu"
    bl_description = "Open the Stylized Hair PRO Quick Menu"

    def execute(self, context):
        bpy.ops.wm.call_menu_pie(name="SHP_MT_PieMenu")
        return {'FINISHED'}

class SHP_OT_PieSectionPopup(bpy.types.Operator):
    bl_idname = "wm.section_pie_menu"
    bl_label = "Stylized Hair PRO"
    bl_description = "Open Section Menu"

    sec_id: bpy.props.StringProperty(name="Section ID", description="The string identifier of the section") #type:ignore

    def invoke(self, context, event):
        return context.window_manager.invoke_popup(self, width=250)

    def draw(self, context):
        layout = self.layout
        if self.sec_id == 'SHAPE':
            draw_shape(self, context, layout, show_tips=False)
        if self.sec_id == 'TWIST':
            draw_twist(self, context, layout, show_tips=False)
        if self.sec_id == 'BUMPS':
            draw_bumps(self, context, layout, show_tips=False)
        if self.sec_id == 'CURLS':
            draw_curls(self, context, layout, show_tips=False)
        if self.sec_id == 'BRAID':
            draw_braid(self, context, layout, show_tips=False)
        if self.sec_id == 'FRIZZ':
            draw_frizz(self, context, layout, show_tips=False)
        if self.sec_id == 'PROFILE':
            draw_profile(self, context, layout, show_tips=False)
        if self.sec_id == 'ORNAMENTS':
            draw_ornaments(self, context, layout, show_tips=False)
        if self.sec_id == 'DYNAMICS':
            draw_dynamics(self, context, layout, show_tips=False)
        if self.sec_id == 'SHADING':
            draw_shading(self, context, layout, show_tips=False)
        if self.sec_id == 'SETTINGS':
            draw_hair_settings(self, context, layout, show_tips=False)
        if self.sec_id == 'UTILITIES':
            draw_utilities(self, context, layout, show_tips=False)
    
    def execute(self, context):
        return {'FINISHED'}

class SHP_OT_PieSelectBrush(bpy.types.Operator):
    bl_idname = "wm.shp_select_brush"
    bl_label = "Select Brush"
    bl_description = "Select a grooming brush"

    brush_id: bpy.props.StringProperty(name="Brush", description="The string identifier of the brush") #type:ignore

    def execute(self, context):
        obj = context.object
        bpy.ops.object.mode_set(mode='OBJECT')
        if obj and obj.type in {'CURVES'}:
            bpy.ops.object.mode_set(mode='SCULPT_CURVES')
            try:
                bpy.ops.brush.asset_activate(asset_library_type='ESSENTIALS', asset_library_identifier="", relative_asset_identifier=f"brushes\\essentials_brushes-curve_sculpt.blend\\Brush\\{self.brush_id}")
            except Exception:
                pass
            bpy.ops.curves.select_all(action='SELECT')
        return {'FINISHED'}


# MENUS/PANELS
class SHP_PT_GizmosMenu(bpy.types.Panel):
    bl_label = "Gizmo Options"
    bl_idname = "SHP_PT_GizmosMenu"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'WINDOW'
    bl_ui_units_x = 12
    bl_category = ""
    bl_parent_id = ""

    def draw(self, context):
        pcoll = shp_preview_collections["main"]
        layout = self.layout
        layout.label(text="SHP Gizmos")
        shp_draw(layout, 'internal_utils', 'iu_gizmos_curve_index', "Gizmos Curve Index")
        shp_draw_global(layout, 'gs_show_gizmos_in_editing', "Show Gizmos while Editing")
        layout.separator(type='LINE')
        row = layout.row(align=False)
        row.label(text="Display Gizmo:")
        row.operator('wm.shp_disable_all_gizmos', text="Disable All")
        col = layout.column(align=False)
        shp_draw_global(col, 'gs_show_scale_gizmos', label="Ends Shape/Thickness", toggle=True, icon_value=pcoll["shp_icon_gizmo_ends_shape"].icon_id)
        shp_draw_global(col, 'gs_show_twist_gizmos', label="Twist/Rotate", toggle=True, icon_value=pcoll["shp_icon_gizmo_twist"].icon_id)
        sub = col.row(align=True)
        shp_draw_global(sub, 'gs_show_root_pinch_gizmos', label="Root Pinch", toggle=True, icon_value=pcoll["shp_icon_gizmo_root_pinch"].icon_id)
        sub.separator(factor=0.5)
        shp_draw_global(sub, 'gs_show_tip_pinch_gizmos', label="Tip Pinch", toggle=True, icon_value=pcoll["shp_icon_gizmo_tip_pinch"].icon_id)
        shp_draw_global(col, 'gs_show_curls_gizmos', label="Curls", toggle=True, icon_value=pcoll["shp_icon_gizmo_curls"].icon_id)
        sub = col.row(align=True)
        shp_draw_global(sub, 'gs_show_braid_body_gizmos', label="Braid", toggle=True, icon_value=pcoll["shp_icon_gizmo_braid_body"].icon_id)
        sub.separator(factor=0.5)
        shp_draw_global(sub, 'gs_show_braid_strands_gizmos', label="Strands", toggle=True, icon_value=pcoll["shp_icon_gizmo_braid_strands"].icon_id)
        sub.separator(factor=0.5)
        shp_draw_global(sub, 'gs_show_braid_roots_gizmos', label="Roots", toggle=True, icon_value=pcoll["shp_icon_gizmo_braid_roots"].icon_id)
        shp_draw_global(col, 'gs_show_split_tip_gizmos', label="Split Tip", toggle=True, icon_value=pcoll["shp_icon_gizmo_split_tip"].icon_id)
        shp_draw_global(col, 'gs_show_resolution_gizmos', label="Mesh Resolution", toggle=True, icon_value=pcoll["shp_icon_gizmo_resolution"].icon_id)


# Load user presets on add-on enable
shp_load_presets()


# REGISTER
ICONS_LIST = [
    ("shp_icon_add_new_curve",          "shp_icon_add_new_curve.png"),
    ("shp_icon_curve_braid",            "shp_icon_curve_braid.png"),
    ("shp_icon_curve_bumps",            "shp_icon_curve_bumps.png"),
    ("shp_icon_curve_curls",            "shp_icon_curve_curls.png"),
    ("shp_icon_curve_duplicate",        "shp_icon_curve_duplicate.png"),
    ("shp_icon_curve_dynamics",         "shp_icon_curve_dynamics.png"),
    ("shp_icon_curve_wind",             "shp_icon_curve_wind.png"),
    ("shp_icon_curve_ornament",         "shp_icon_curve_ornament.png"),
    ("shp_icon_curve_profile",          "shp_icon_curve_profile.png"),
    ("shp_icon_curve_refresh",          "shp_icon_curve_refresh.png"),
    ("shp_icon_curve_settings",         "shp_icon_curve_settings.png"),
    ("shp_icon_wire",                   "shp_icon_wire.png"),
    ("shp_icon_curve_shape",            "shp_icon_curve_shape.png"),
    ("shp_icon_curve_twist",            "shp_icon_curve_twist.png"),
    ("shp_icon_curve_uv",               "shp_icon_curve_uv.png"),
    ("shp_icon_curve_shades",           "shp_icon_curve_shades.png"),
    ("shp_icon_edit_comb",              "shp_icon_edit_comb.png"),
    ("shp_icon_edit_grab",              "shp_icon_edit_grab.png"),
    ("shp_icon_edit_length",            "shp_icon_edit_length.png"),
    ("shp_icon_edit_slide",             "shp_icon_edit_slide.png"),
    ("shp_icon_edit_smooth",            "shp_icon_edit_smooth.png"),
    ("shp_icon_setup_add",              "shp_icon_setup_add.png"),
    ("shp_icon_setup_remove",           "shp_icon_setup_remove.png"),
    ("shp_icon_profile_box",            "shp_icon_profile_box.png"),
    ("shp_icon_profile_crescent",       "shp_icon_profile_crescent.png"),
    ("shp_icon_profile_islands",        "shp_icon_profile_islands.png"),
    ("shp_icon_profile_linear",         "shp_icon_profile_linear.png"),
    ("shp_icon_profile_robo",           "shp_icon_profile_robo.png"),
    ("shp_icon_profile_triangle",       "shp_icon_profile_triangle.png"),
    ("shp_icon_refresh_settings",       "shp_icon_refresh_settings.png"),
    ("shp_icon_quick_settings",         "shp_icon_quick_settings.png"),
    ("shp_icon_copy_section",           "shp_icon_copy_section.png"),
    ("shp_icon_utilities",              "shp_icon_utilities.png"),
    ("shp_icon_frizz",                  "shp_icon_frizz.png"),
    ("shp_icon_mirror_ghost",           "shp_icon_mirror_ghost.png"),
    ("shp_icon_quick_menu",             "shp_icon_quick_menu.png"),
    ("shp_icon_mail",                   "shp_icon_mail.png"),
    ("shp_icon_yt",                     "shp_icon_yt.png"),
    ("shp_icon_discord",                "shp_icon_discord.png"),
    ("shp_icon_random",                 "shp_icon_random.png"),
    ("shp_icon_gizmo_ends_shape",       "shp_icon_gizmo_ends_shape.png"),
    ("shp_icon_gizmo_twist",            "shp_icon_gizmo_twist.png"),
    ("shp_icon_gizmo_root_pinch",       "shp_icon_gizmo_root_pinch.png"),
    ("shp_icon_gizmo_tip_pinch",        "shp_icon_gizmo_tip_pinch.png"),
    ("shp_icon_gizmo_curls",            "shp_icon_gizmo_curls.png"),
    ("shp_icon_gizmo_braid_body",       "shp_icon_gizmo_braid_body.png"),
    ("shp_icon_gizmo_braid_strands",    "shp_icon_gizmo_braid_strands.png"),
    ("shp_icon_gizmo_braid_roots",      "shp_icon_gizmo_braid_roots.png"),
    ("shp_icon_gizmo_split_tip",        "shp_icon_gizmo_split_tip.png"),
    ("shp_icon_gizmo_resolution",       "shp_icon_gizmo_resolution.png"),
]

CLASSES_LIST = [
    SHP_Props,
    SHP_OT_AddSetup,
    SHP_OT_RemoveSetup,
    SHP_OT_AddStrand,
    SHP_OT_DuplicateStrand,
    SHP_OT_SelectSection,
    SHP_OT_ResetSection,
    SHP_OT_ResetMultipleSections,
    SHP_OT_CopySection,
    SHP_OT_CopySubSection,
    SHP_OT_ApplyMirror,
    SHP_OT_SplitCurves,
    SHP_OT_PickBaseMesh,
    SHP_OT_MeshConvert,
    SHP_OT_GenerateArmature,
    SHP_OT_SelectAllSections,
    SHP_OT_SaveHairPreset,
    SHP_OT_RemoveHairPreset,
    SHP_OT_ReloadHairPresets,
    SHP_OT_ApplyHairPreset,
    SHP_OT_RandomizeSection,
    SHP_OT_TutNextStep,
    SHP_OT_TutPreviousStep,
    SHP_OT_TutCancel,
    SHP_OT_CallPieMenu,
    SHP_OT_PieSectionPopup,
    SHP_OT_PieSelectBrush,
    SHP_OT_AddOnPreferences,
    SHP_OT_AddOnInfo,
    SHP_OT_AddCurvePanel,
    SHP_OT_UpdateSetup,
    SHP_OT_DisableAllGizmos,
    SHP_OT_BakeHairGeo,
    SHP_OT_HideDToolsMessage,
    # SHP_PT_MainPanel,
    SHP_MT_PieMenu,
    SHP_PT_GizmosMenu,
]

def shp_append_to_main_dt_panel():
    """ Append the SHP UI to the main DT panel if DT is enabled. Otherwise register it as its own panel class."""
    dt_panel_class = getattr(bpy.types, dt_main_panel, None)
    
    if dt_panel_class is None:
        bpy.utils.register_class(SHP_PT_MainPanel)
    else:
        if hasattr(dt_panel_class.draw, '_draw_funcs'):
            if shp_main_panel_ui not in dt_panel_class.draw._draw_funcs:
                dt_panel_class.append(shp_main_panel_ui)
        else:
            pass

def shp_remove_from_main_dt_panel():
    """ Remove the SHP UI from the DT panel or remove its panel class"""
    dt_panel_class = getattr(bpy.types, dt_main_panel, None)
    
    try:
        bpy.utils.unregister_class(SHP_PT_MainPanel)
    except Exception:
        pass
    
    try:
        dt_panel_class.remove(shp_main_panel_ui)
    except Exception:
        pass

def register():
    for cls in CLASSES_LIST:
        bpy.utils.register_class(cls)
    
    # SHP panel ui    
    shp_append_to_main_dt_panel()
    
    # Custom props
    bpy.types.Scene.shp_addon = bpy.props.PointerProperty(type=SHP_Props)

    # Handler 
    bpy.app.handlers.depsgraph_update_post.append(shp_active_object_update)
    bpy.app.handlers.depsgraph_update_post.append(shp_mode_change_update)
    bpy.app.handlers.depsgraph_update_post.append(shp_scene_time_update)
    bpy.app.handlers.depsgraph_update_post.append(shp_set_modifier_active)
    
    # Icons
    pcoll = bpy.utils.previews.new()
    icons_dir = os.path.join(os.path.dirname(__file__), "icons")
    for icon_name, icon_file in ICONS_LIST:
        pcoll.load(icon_name, os.path.join(icons_dir, icon_file), 'IMAGE')
    shp_preview_collections["main"] = pcoll

def unregister():
    for cls in CLASSES_LIST:
        bpy.utils.unregister_class(cls)

    # Remove SHP panel ui
    shp_remove_from_main_dt_panel()

    # Custom props
    del bpy.types.Scene.shp_addon

    # Handler
    if shp_active_object_update in bpy.app.handlers.depsgraph_update_post:
        bpy.app.handlers.depsgraph_update_post.remove(shp_active_object_update)
    if shp_mode_change_update in bpy.app.handlers.depsgraph_update_post:
        bpy.app.handlers.depsgraph_update_post.remove(shp_mode_change_update)
    if shp_scene_time_update in bpy.app.handlers.depsgraph_update_post:
        bpy.app.handlers.depsgraph_update_post.remove(shp_scene_time_update)
    if shp_set_modifier_active in bpy.app.handlers.depsgraph_update_post:
        bpy.app.handlers.depsgraph_update_post.remove(shp_set_modifier_active)

    # Icons
    for pcoll in shp_preview_collections.values():
        bpy.utils.previews.remove(pcoll)
    shp_preview_collections.clear()


if __name__ == "__main__":
    register()