Thank you for purchasing "Stylized Hair PRO - Hair editing for Blender"!

## Overview

Welcome to "Stylized Hair PRO"! This Blender add-on is focused on working with the hair curves system in Blender, but I've also adapted it to be able to work with other curves (Bezier, Paths) in the more traditional way of stylized hair creation.

Whether you're a seasoned Blender user or just getting started, "Stylized Hair PRO" aims to an easy alternative to the tedious hair styling process.

It features a lot of tools to create and control hair curves - from their shape, geometry, materials, ornaments, and even animating them with a Hair Dynamics system.

## Installation

To install "Stylized Hair PRO", follow these steps:

	For Blender versions < 4.2.0:
    	1. Open Blender.
		2. Go to Edit > Preferences.
		3. Navigate to the "Add-ons" tab.
		4. Click on the "Install" button.
		5. Locate the "Stylized_Hair_PRO_v3.zip" file. IMPORTANT: Do NOT unzip the file, simply select it and press the "Install Add-on" button.
		6. Then simply enable it by clicking the checkbox, next to the add-on name.

	For Blender versions > 4.2.0:
    	1. Open Blender.
		2. Go to Edit > Preferences.
		3. Navigate to the "Add-ons" tab.
		4. Click on the top-right arrow, then from the drop down select "Install from Disk...".
		5. Locate the "Stylized_Hair_PRO_v3.zip" file. IMPORTANT: Do NOT unzip the file, simply select it and press the "Install Add-on" button.
		6. Then simply enable it by clicking the checkbox, next to the add-on name.

The zip file contains an assets .blend file, called "SHP_assets.blend". This file is used to import the various node groups by the add-on. Make sure you don't modify that file, or you may break the functionality of the add-on.

If you encounter any issues or have questions about "Stylized Hair PRO", feel free to reach out at deanzarkov@protonmail.com

## License

This project is licensed under the MIT License - see the [LICENSE] file for details.

## Contributions

"Stylized Hair PRO" is developed and maintained by Dean Zarkov (deanzarkov@protonmail.com)
