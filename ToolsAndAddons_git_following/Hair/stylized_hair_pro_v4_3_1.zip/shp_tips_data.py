'''MIT License

Copyright (c) 2026 Dean Zarkov

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.'''

# SHP_TIPS = {'tip_id' : 'text'}
SHP_TIPS = {
    'tip_place_ornaments'    : 'To see the enabled ornaments above, you have to enable one or more of the pinch features:',
    'tip_high_resolution'    : 'Using high geometry resolution might slow down the performance while editing the hair strands. You can enable "Grooming Optimization" to have a smoother editing experience:',
    'tip_align_root_base'    : 'A "Base Mesh" surface is needed for the "Auto-Squish" and "Align Root" to work. Set it from the Base Mesh "Object" setting above.',
    'tip_dynamics_base'      : 'For best results, set the Base Mesh "Object" and "UV Map":',
    'tip_shades_use'         : 'To use the shades, add the "SHP Shades" node group in the Shader Editor. Ensure you are editing the material you\'ve set in the "Materials" tab above.',
    'tip_braid_base'         : 'The braid roots require a "Base Surface" to attach to:',
    'tip_ornament_size'      : 'If you don\'t see the ornament, try adjusting its size in the "Adjustments" tab:',
    'tip_dynamics_twitching' : 'If the hair strand twitches excessively while moving, push the Effect Factor more towards the tip. This will mute the root moving, which causes the twitching.',
}