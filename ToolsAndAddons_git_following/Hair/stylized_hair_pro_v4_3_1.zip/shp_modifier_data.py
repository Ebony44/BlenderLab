'''MIT License

Copyright (c) 2026 Dean Zarkov

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.'''

# SECTION_ID : {SETTING_ID : [MODIFIER_INPUT_ID, DEFAULT_VALUE, LABEL, UI_STYLE, IS_PRESET]}
SHP_DATA = {
    # SUB-SECTIONS
    'sub_sections'     : {
        'shape'    : ['shape_settings', 'pinch_settings'],
        'twist'    : ['twist_settings', 'custom_twist_settings', 'waviness_settings'],
        'bumps'    : ['bumps_reg_settings', 'bumps_rnd_settings', 'bumps_srf_settings', 'bumps_subs_settings'],
        'curls'    : ['curls_settings'],
        'braid'    : ['braid_body_settings', 'braid_strands_settings', 'braid_roots_settings'],
        'frizz'    : ['frz_splt_tip_settings', 'frz_strand_settings', 'frz_flys_settings'],
        'profile'  : ['profile_settings'],
        'ornaments': ['ornaments_main_settings', 'ornaments_geometry_settings', 'ornaments_adjustments_settings', 'ornaments_settings'],
        'dynamics' : ['dyn_main_settings', 'dyn_wind_effects', 'dyn_pulse_effects', 'dyn_sim_settings'],
        'shading'  : ['materials_settings', 'uv_maps_settings', 'shades_settings'],
        'settings' : ['hair_settings_resolution', 'hair_settings_misc'],
        'utilities': ['utility_settings'],
    },

    # MAIN
    'main_settings'     : {
        'main_thickness'                    : ['Socket_11',     1.0,    'Thickness',            'full_thick',     False],
        'main_rotation'                     : ['Socket_93',     0.0,    'Rotation',             'full_thick',     False],
        'main_mirror_x'                     : ['Socket_324',    False,  'X',                    'bool_toggle',    False],
        'main_mirror_y'                     : ['Socket_325',    False,  'Y',                    'bool_toggle',    False],
        'main_mirror_z'                     : ['Socket_326',    False,  'Z',                    'bool_toggle',    False],
        'main_mirror_ghosting'              : ['Socket_328',    False,  'Mirror Ghosting',      'bool_toggle',    False],
    },

    # SHAPE
    'shape_settings'    : {
        'root_size'                         : ['Socket_6',      0.25,   "Root Size",         'split_label',     True],
        'root_scale'                        : ['Socket_9',      1.0,    "Root Scale",        'split_label',     True],
        'root_bulge'                        : ['Socket_90',     0.5,    "Root Bulge",        'split_label',     True],
        'root_round'                        : ['Socket_137',    0.0,    "Root Round",        'split_label',     True],
        'root_open'                         : ['Socket_138',    1.0,    "Root Open",         'split_label',     True],
        'root_tilt'                         : ['Socket_320',    0.0,    "Root Tilt",         'split_label',     True],
        'root_tilt_orientation'             : ['Socket_322',    0.0,    "Root Tilt Dir.",    'split_label',     True],
        'root_flatten'                      : ['Socket_89',     0.5,    "Root Flatten",      'split_label',     True],
        'root_bend'                         : ['Socket_381',    0.0,    "Root Bend",         'split_label',     True],
        'tip_size'                          : ['Socket_7',      0.25,   "Tip Size",          'split_label',     True],
        'tip_scale'                         : ['Socket_8',      1.0,    "Tip Scale",         'split_label',     True],
        'tip_bulge'                         : ['Socket_87',     0.5,    "Tip Bulge",         'split_label',     True],
        'tip_round'                         : ['Socket_135',    0.0,    "Tip Round",         'split_label',     True],
        'tip_open'                          : ['Socket_136',    0.0,    "Tip Open",          'split_label',     True],
        'tip_tilt'                          : ['Socket_321',    0.0,    "Tip Tilt",          'split_label',     True],
        'tip_tilt_orientation'              : ['Socket_323',    0.0,    "Tip Tilt Dir.",     'split_label',     True],
        'tip_bend'                          : ['Socket_382',    0.0,    "Tip Bend",          'split_label',     True],
        'tip_flatten'                       : ['Socket_88',     0.5,    "Tip Flatten",       'split_label',     True],
        'ends_shape_factor'                 : ['Socket_91',     0.5,    "Shape Factor",      'double_widget1',  True],
        'ends_contrast'                     : ['Socket_92',     0.0,    "Contrast",          'double_widget2',  True],
    },

    # PINCH
    'pinch_settings'    : {
        'root_pinch'                        : ['Socket_12',     0.0,   "Root Pinch",                'full',     True],
        'root_pinch_width'                  : ['Socket_13',     0.0,   "Root Pinch Width",          'full',     True],
        'root_pinch_tightness'              : ['Socket_14',     0.5,   "Root Pinch Tightness",      'full',     True],
        'root_pinch_shape'                  : ['Socket_15',     0.5,   "Root Pinch Shape",          'full',     True],
        'tip_pinch'                         : ['Socket_16',     0.0,   "Tip Pinch",                 'full',     True],
        'tip_pinch_width'                   : ['Socket_17',     0.0,   "Tip Pinch Width",           'full',     True],
        'tip_pinch_tightness'               : ['Socket_18',     0.5,   "Tip Pinch Tightness",       'full',     True],
        'tip_pinch_shape'                   : ['Socket_19',     0.5,   "Tip Pinch Shape",           'full',     True],
        'body_pinch_tightness_root'         : ['Socket_21',     0.5,   "Root-Side Pinch Tightness", 'full',     True],
        'body_pinch_tightness_tip'          : ['Socket_22',     0.5,   "Tip-Side Pinch Tightness",  'full',     True],
        'body_pinch_shape_root'             : ['Socket_147',    0.5,   "Root-Side Pinch Shape",     'full',     True],
        'body_pinch_shape_tip'              : ['Socket_148',    0.5,   "Tip-Side Pinch Shape",      'full',     True], 
    },

    # TWIST
    'twist_settings'    : {
        'twist_root'                        : ['Socket_94',     0.0,    "Twist Root",           'split_label',     True],
        'twist_mid'                         : ['Socket_95',     0.0,    "Twist Mid",            'split_label',     True],
        'twist_tip'                         : ['Socket_96',     0.0,    "Twist Tip",            'split_label',     True],
    },

    # CUSTOM TWIST
    'custom_twist_settings'    : {
        'custom_twist_1_amount'             : ['Socket_97',     0.0,    "Twist 1",              'split_label',      True],
        'custom_twist_1_shape_factor'       : ['Socket_98',     0.5,    "Position 1",           'double_widget1',   True],
        'custom_twist_1_contrast'           : ['Socket_99',     0.5,    "Amount 1",             'double_widget2',   True],
        'custom_twist_2_amount'             : ['Socket_100',    0.0,    "Twist 2",              'split_label',      True],
        'custom_twist_2_shape_factor'       : ['Socket_102',    0.5,    "Position 2",           'double_widget1',   True],
        'custom_twist_2_contrast'           : ['Socket_104',    0.5,    "Amount 2",             'double_widget2',   True],
        'custom_twist_3_amount'             : ['Socket_101',    0.0,    "Twist 3",              'split_label',      True],
        'custom_twist_3_shape_factor'       : ['Socket_103',    0.5,    "Position 3",           'double_widget1',   True],
        'custom_twist_3_contrast'           : ['Socket_105',    0.5,    "Amount 3",             'double_widget2',   True],
    },

    # WAVINESS
    'waviness_settings'    : {
        'waviness_strength'                 : ['Socket_233',    0.0,    "Strength",             'split_label',     True],
        'waviness_scale'                    : ['Socket_234',    2.0,    "Scale",                'split_label',     True],
        'waviness_seed'                     : ['Socket_235',    0.0,    "Seed",                 'split_label',     True],
        'waviness_shape_factor'             : ['Socket_406',    0.5,    "Shape Factor",         'double_widget1',  True],
        'waviness_contrast'                 : ['Socket_407',    0.0,    "Contrast",             'double_widget2',  True],
    },

    # REGULAR BUMPS
    'bumps_reg_settings'    : {
        'reg_bumps_strength'                : ['Socket_108',    0.0,    "Strength",             'full_thick',       True],
        'reg_bumps_count'                   : ['Socket_107',    3,      "Count",                'split_label',      True],
        'reg_bumps_shape'                   : ['Socket_112',    0.5,    "Shape",                'split_label',      True],
        'reg_bumps_gap_size'                : ['Socket_113',    0.0,    "Gap Size",             'split_label',      True],
        'reg_bumps_taper'                   : ['Socket_114',    0.0,    "Taper",                'split_label',      True],
        'reg_bumps_shift'                   : ['Socket_115',    0.0,    "Shift Volume",         'split_label',      True],
        'reg_bumps_random'                  : ['Socket_110',    0.0,    "Randomize Thickness",  'double_widget1',   True],
        'reg_bumps_seed'                    : ['Socket_111',    0.0,    "Seed",                 'double_widget2',   True],
    },

    # RANDOM BUMPS
    'bumps_rnd_settings'    : {
        'rnd_bumps_strength'                : ['Socket_192',    0.0,    "Strength",             'full_thick',       True],
        'rnd_bumps_scale'                   : ['Socket_193',    5.0,    "Scale",                'split_label',      True],
        'rnd_bumps_seed'                    : ['Socket_194',    0.0,    "Seed",                 'split_label',      True],
        'rnd_bumps_shape_factor'            : ['Socket_195',    0.5,    "Shape Factor",         'double_widget1',   True],
        'rnd_bumps_contrast'                : ['Socket_196',    0.0,    "Contrast",             'double_widget2',   True],
    },

    # SURFACE BUMPS
    'bumps_srf_settings'    : {
        'srf_bumps_strength'                : ['Socket_197',    0.0,    "Strength",             'full_thick',       True],
        'srf_bumps_scale'                   : ['Socket_198',    5.0,    "Scale",                'split_label',      True],
        'srf_bumps_detail'                  : ['Socket_199',    0.0,    "Detail",               'split_label',      True],
        'srf_bumps_seed'                    : ['Socket_200',    0.0,    "Seed",                 'split_label',      True],
        'srf_bumps_shape_factor'            : ['Socket_201',    0.5,    "Shape Factor",         'double_widget1',   True],
        'srf_bumps_contrast'                : ['Socket_202',    0.0,    "Contrast",             'double_widget2',   True],
    },

    # SUB-STRANDS
    'bumps_subs_settings'    : {
        'subs_bumps_strength'    : ['Socket_203',    0.0,       "Strength",     'full_thick',       True],
        'subs_bumps_scale'       : ['Socket_204',    10.0,      "Scale",        'split_label',      True],
        'subs_bumps_seed'        : ['Socket_205',    0.0,       "Seed",         'split_label',      True],
        'subs_bumps_shape'       : ['Socket_206',    'Bumpy',   "Shape",        'split_label',      True],
        'subs_bumps_shape_factor': ['Socket_207',    0.5,       "Shape Factor", 'double_widget1',   True],
        'subs_bumps_contrast'    : ['Socket_208',    0.0,       "Contrast",     'double_widget2',   True],
    },

    # CURLS
    'curls_settings'    : {
        'curls_frequency'                   : ['Socket_116',   0.0,     "Frequency",            'full_thick',       True],
        'curls_flip_dir'                    : ['Socket_117',   False,   "Flip Direction",       'bool',             True],
        'curls_radius'                      : ['Socket_118',   1.0,     "Radius",               'split_label',      True],
        'curls_phase'                       : ['Socket_119',   0.0,     "Phase",                'split_label',      True],
        'curls_random'                      : ['Socket_120',   0.5,     "Randomize Curl",       'double_widget1',   True],
        'curls_seed'                        : ['Socket_121',   0.0,     "Seed",                 'double_widget2',   True],
        'curls_flatten'                     : ['Socket_122',   0.0,     "Flatten Curl",         'split_label',      True],
        'curls_flatten_dir'                 : ['Socket_123',   0.0,     "Direction",            'split_label',      True],
        'curls_stylize'                     : ['Socket_124',   0,       "Stylization",          'split_label',      True],
        'curls_shape_factor'                : ['Socket_125',   0.5,     "Shape Factor",         'double_widget1',   True],
        'curls_contrast'                    : ['Socket_126',   1.0,     "Contrast",             'double_widget2',   True],
    },

    # BRAID BODY
    'braid_body_settings'    : {
        'braid_frequency'                   : ['Socket_26',    0.0,    "Frequency",             'full_thick',       True],
        'braid_width'                       : ['Socket_29',    1.0,    "Width",                 'split_label',      True],
        'braid_depth'                       : ['Socket_30',    1.0,    "Depth",                 'split_label',      True],
        'braid_taper'                       : ['Socket_27',    0.5,    "Taper",                 'split_label',      True],
        'braid_taper_degree'                : ['Socket_28',    2.0,    "Taper Degree",          'split_label',      True],
    },

    # BRAID STRANDS
    'braid_strands_settings'    : {
        'braid_strands_random'    : ['Socket_33',    0.5,    "Randomize Thickness",   'double_widget1',  True],
        'braid_strands_seed'      : ['Socket_34',    0.0,    "Seed",                  'double_widget2',  True],
        'braid_strands_pinch'     : ['Socket_32',    0.5,    "Pinch",                 'split_label',     True],
        'braid_strand_1_thickness': ['Socket_31',    1.0,    "Strand 1 Thickness",    'split_label',     True],
        'braid_strand_2_thickness': ['Socket_391',   1.0,    "Strand 2 Thickness",    'split_label',     True],
        'braid_strand_3_thickness': ['Socket_392',   1.0,    "Strand 3 Thickness",    'split_label',     True],
        'braid_strand_1_rotate'   : ['Socket_36',    0.0,    "Strand 1 Rotate",       'split_label',     True],
        'braid_strand_2_rotate'   : ['Socket_37',    0.0,    "Strand 2 Rotate",       'split_label',     True],
        'braid_strand_3_rotate'   : ['Socket_38',    0.0,    "Strand 3 Rotate",       'split_label',     True],
        'braid_strand_1_twist'    : ['Socket_39',    0.0,    "Strand 1 Twist",        'split_label',     True],
        'braid_strand_2_twist'    : ['Socket_40',    0.0,    "Strand 2 Twist",        'split_label',     True],
        'braid_strand_3_twist'    : ['Socket_41',    0.0,    "Strand 3 Twist",        'split_label',     True],
        'braid_strand_1_flatten'  : ['Socket_35',    0.0,    "Strand 1 Flatten",      'split_label',     True],
        'braid_strand_2_flatten'  : ['Socket_393',   0.0,    "Strand 2 Flatten",      'split_label',     True],
        'braid_strand_3_flatten'  : ['Socket_394',   0.0,    "Strand 3 Flatten",      'split_label',     True],
    },

    # BRAID ROOTS
    'braid_roots_settings'    : {
        'braid_root_1_move'         : ['Socket_42',    [0.0, 0.0, 1.0],    "Root 1 Move",   'split_label',     True],
        'braid_root_2_move'         : ['Socket_43',    [0.0, 0.0, 1.0],    "Root 2 Move",   'split_label',     True],
        'braid_root_3_move'         : ['Socket_44',    [0.0, 0.0, 1.0],    "Root 3 Move",   'split_label',     True],
        'braid_root_1_scale'        : ['Socket_45',    1.0,    "Root 1 Scale",              'split_label',     True],
        'braid_root_2_scale'        : ['Socket_46',    1.0,    "Root 2 Scale",              'split_label',     True],
        'braid_root_3_scale'        : ['Socket_47',    1.0,    "Root 3 Scale",              'split_label',     True],
        'braid_root_1_flatten'      : ['Socket_48',    0.5,    "Root 1 Flatten",            'split_label',     True],
        'braid_root_2_flatten'      : ['Socket_49',    0.5,    "Root 2 Flatten",            'split_label',     True],
        'braid_root_3_flatten'      : ['Socket_50',    0.5,    "Root 3 Flatten",            'split_label',     True],
        'braid_root_1_rotate'       : ['Socket_51',    0.0,    "Root 1 Rotate",             'split_label',     True],
        'braid_root_2_rotate'       : ['Socket_52',    0.0,    "Root 2 Rotate",             'split_label',     True],
        'braid_root_3_rotate'       : ['Socket_53',    0.0,    "Root 3 Rotate",             'split_label',     True],
        'braid_root_1_bend'         : ['Socket_54',    0.0,    "Root 1 Bend",               'split_label',     True],
        'braid_root_2_bend'         : ['Socket_55',    0.0,    "Root 2 Bend",               'split_label',     True],
        'braid_root_3_bend'         : ['Socket_56',    0.0,    "Root 3 Bend",               'split_label',     True],
        'braid_root_1_start'        : ['Socket_57',    0.5,    "Root 1 Adjust Start",       'split_label',     True],
        'braid_root_2_start'        : ['Socket_58',    0.5,    "Root 2 Adjust Start",       'split_label',     True],
        'braid_root_3_start'        : ['Socket_59',    0.5,    "Root 3 Adjust Start",       'split_label',     True],
        'braid_root_1_end'          : ['Socket_60',    0.5,    "Root 1 Adjust End",         'split_label',     True],
        'braid_root_2_end'          : ['Socket_61',    0.5,    "Root 2 Adjust End",         'split_label',     True],
        'braid_root_3_end'          : ['Socket_62',    0.5,    "Root 3 Adjust End",         'split_label',     True],
        'braid_root_1_factor'       : ['Socket_395',   0.5,    "Root 1 Factor",             'split_label',     True],
        'braid_root_2_factor'       : ['Socket_396',   0.5,    "Root 2 Factor",             'split_label',     True],
        'braid_root_3_factor'       : ['Socket_397',   0.5,    "Root 3 Factor",             'split_label',     True],
    },

    # FRIZZ SPLIT TIP
    'frz_splt_tip_settings' : {
        'frz_splt_tip_split'                : ['Socket_63',    0.0,    "Split Tip",                 'full_thick',       True],
        'frz_splt_tip_splits_count'         : ['Socket_64',    3,      "Splits Count",              'full',             True],
        'frz_splt_tip_seed_major'           : ['Socket_65',    0.0,    "Split Seed",                'full',             True],
        'frz_splt_tip_split_random'         : ['Socket_67',    0.0,    "Split",                     'double_row1',      True],
        'frz_splt_tip_split_seed'           : ['Socket_68',    0.0,    "Seed",                      'double_row2',      True],
        'frz_splt_tip_depth_random'         : ['Socket_69',    0.5,    "Depth",                     'double_row1',      True],
        'frz_splt_tip_depth_seed'           : ['Socket_70',    0.0,    "Seed",                      'double_row2',      True],
        'frz_splt_tip_length_random'        : ['Socket_71',    0.5,    "Length",                    'double_row1',      True],
        'frz_splt_tip_length_seed'          : ['Socket_72',    0.0,    "Seed",                      'double_row2',      True],
        'frz_splt_tip_tilt_random'          : ['Socket_73',    0.0,    "Tilt",                      'double_row1',      True],
        'frz_splt_tip_tilt_seed'            : ['Socket_74',    0.0,    "Seed",                      'double_row2',      True],
        'frz_splt_tip_bend_random'          : ['Socket_75',    0.0,    "Amount",                    'double_row1',      True],
        'frz_splt_tip_bend_seed'            : ['Socket_76',    0.0,    "Seed",                      'double_row2',      True],
        'frz_splt_tip_bend_direction'       : ['Socket_77',    0.5,    "Direction",                 'split_label',      True],
        'frz_splt_tip_bend_limit'           : ['Socket_66',    0.25,   "Limit Bend",                'split_label',      True],
        'frz_splt_tip_bend_outward_only'    : ['Socket_78',    True,   "Outwards Bend Only",        'bool',             True],
        'frz_splt_tip_bend_limit_central'   : ['Socket_398',   False,  "Limit Central Splits Bend", 'bool',             True],
        'frz_splt_tip_curl'                 : ['Socket_79',    0.0,    "Curl Splits",               'split_label',      True],
        'frz_splt_tip_curl_radius'          : ['Socket_80',    1.0,    "Curl Radius",               'split_label',      True],
        'frz_splt_tip_curl_random'          : ['Socket_81',    1.0,    "Randomize Curl",            'double_widget1',   True],
        'frz_splt_tip_curl_seed'            : ['Socket_82',    0.0,    "Seed",                      'double_widget2',   True],
        'frz_splt_tip_curl_limit'           : ['Socket_399',   0.0,    "Limit Curl",                'split_label',      True],
        'frz_splt_tip_smooth'               : ['Socket_83',    0.0,    "Smooth Cuts",               'split_label',      True],
    },

    # FRIZZ STRAND
    'frz_strand_settings' : {
        'frz_str_strength'                  : ['Socket_242',    0.0,    "Frizz Strength",           'full_thick',       True],
        'frz_str_scale'                     : ['Socket_243',    10.0,   "Scale",                    'split_label',      True],
        'frz_str_roughness'                 : ['Socket_244',    0.0,    "Roughness",                'split_label',      True],
        'frz_str_seed'                      : ['Socket_245',    0.0,    "Seed",                     'split_label',      True],
        'frz_str_length_preserve'           : ['Socket_246',    0.0,    "Preserve Length",          'split_label',      True],
        'frz_str_shape_factor'              : ['Socket_247',    0.75,   "Shape Factor",             'double_widget1',   True],
        'frz_str_contrast'                  : ['Socket_248',    0.5,    "Contrast",                 'double_widget2',   True],
    },

    # FRIZZ FLYAWAYS
    'frz_flys_settings' : {
        'frz_flys_count'                    : ['Socket_210',    0,      "Flyaways Count",           'full_thick',       True],
        'frz_flys_offset'                   : ['Socket_209',    2.0,    "Offset",                   'split_label',      True],
        'frz_flys_seed'                     : ['Socket_211',    0.0,    "Seed",                     'split_label',      True],
        'frz_flys_profile_res'              : ['Socket_212',    6,      "Resolution",               'split_label',      True],
        'frz_flys_shape_factor'             : ['Socket_213',    0.75,   "Shape Factor",             'double_widget1',   True],
        'frz_flys_contrast'                 : ['Socket_214',    0.0,    "Contrast",                 'double_widget2',   True],
        'frz_flys_thickness'                : ['Socket_215',    0.1,    "Thickness",                'double_row1',      True],
        'frz_flys_thickness_random'         : ['Socket_227',    0.0,    "Randomize",                'double_row2',      True],
        'frz_flys_length'                   : ['Socket_226',    1.0,    "Length",                   'double_row1',      True],
        'frz_flys_length_random'            : ['Socket_216',    0.5,    "Randomize",                'double_row2',      True],
        'frz_flys_spin'                     : ['Socket_239',    0.0,    "Twist",                    'split_label',      True],
        'frz_flys_in_both_dir'              : ['Socket_240',    False,  "In Both Directions",       'bool',             True],
        'frz_flys_frizz_strength'           : ['Socket_217',    5.0,    "Frizz Flyaways",           'full_thick',       True],
        'frz_flys_frizz_scale'              : ['Socket_218',    10.0,   "Scale",                    'split_label',      True],
        'frz_flys_frizz_roughness'          : ['Socket_219',    0.0,    "Roughness",                'split_label',      True],
        'frz_flys_frizz_seed'               : ['Socket_220',    0.0,    "Seed",                     'split_label',      True],
        'frz_flys_frizz_shape_factor'       : ['Socket_222',    0.75,   "Shape Factor",             'double_widget1',   True],
        'frz_flys_frizz_contrast'           : ['Socket_223',    0.5,    "Contrast",                 'double_widget2',   True],
    },

    # PROFILE
    'profile_settings' : {      
        'profile_type'                      : ['Socket_128',    'Almond',   "Profile Type",                  'enum_toggle',     True],
        # 'smart_profile_type'                : ['Socket_140',    0,          "Profile Edges",                 'split_label',     True],
        'smart_profile_shape'               : ['Socket_86',     0.5,        "Profile Shape",                 'split_label',     True],
        'smart_profile_smooth'              : ['Socket_139',    0.0,        "Smooth Profile",                'split_label',     True],
        # 'simple_profile_type'               : ['Socket_129',    0,          "Profile Shape",                 'split_label',     True],
        'simple_profile_smooth'             : ['Socket_130',    0.0,        "Smooth",                        'split_label',     True],
        'simple_profile_detail'             : ['Socket_131',    0.5,        "Detail",                        'split_label',     True],
        'simple_profile_detail_scale'       : ['Socket_132',    0.5,        "Detail Scale",                  'split_label',     True],
        'simple_profile_detail_seed'        : ['Socket_133',    0.0,        "Detail Seed",                   'split_label',     True],
        'simple_profile_thickness'          : ['Socket_134',    0.5,        "Thickness",                     'split_label',     True],
        'custom_profile_type'               : ['Socket_149',    'Object',   "Custom Profile Type",           'enum_toggle',     True],
        'custom_profile_use_orig_res'       : ['Socket_150',    False,      "Use Original Curve Resolution", 'bool',            True],
        'custom_profile_reset_scale'        : ['Socket_151',    True,       "Reset Profile Curves Scale",    'bool',            True],
        'custom_profile_curve'              : ['Socket_152',    None,       "Profile Curve",                 'search_field',    False],
        'custom_profile_collection'         : ['Socket_153',    None,       "Profile Curves Collection",     'search_field',    False],
        'custom_profile_seed'               : ['Socket_154',    0,          "Seed",                          'split_label',     True],
    },

    # ORNAMENTS
    'ornaments_main_settings' : {
        'ornaments_at_root'                 : ['Socket_155',    False,    "Root Pinch",             'bool_toggle',     True],
        'ornaments_at_tip'                  : ['Socket_156',    False,    "Tip Pinch",              'bool_toggle',     True],
        'ornaments_in_bump_gaps'            : ['Socket_157',    False,    "In Bump Gaps",           'bool_toggle',     True],
    },

    # ORNAMENTS GEOMETRY
    'ornaments_geometry_settings' : {
        'ornaments_type'                    : ['Socket_160',    'Default',              "Ornaments Type",         'enum_toggle',      True],
        'ornaments_custom_type'             : ['Socket_161',    'Object',               "Ornament Type",          'split_label',      True],
        'ornaments_object'                  : ['Socket_162',    None,                   "Ornaments Object",       'search_field',     False],
        'ornaments_collection'              : ['Socket_163',    None,                   "Ornaments Collection",   'search_field',     False],
        'ornaments_collection_items'        : ['Socket_164',    'Entire Collection',    "Instance",               'split_label',      True],
        'ornaments_seed'                    : ['Socket_165',    0,                      "Instance Seed",          'split_label',      True],
        'ornaments_default_type'            : ['Socket_175',    'Band',                 "Ornament Type",          'split_label',      True],
        'ornaments_thickness'               : ['Socket_177',    1.0,                    "Thickness",              'split_label',      True],
        'ornaments_smooth'                  : ['Socket_183',    0,                      "Smooth",                 'split_label',      True],
        'ornaments_radius'                  : ['Socket_178',    1.0,                    "Radius",                 'split_label',      True],
        'ornaments_frequency'               : ['Socket_179',    10.0,                   "Frequency",              'split_label',      True],
        'ornaments_scale'                   : ['Socket_180',    2.0,                    "Scale",                  'split_label',      True],
        'ornaments_scrunch'                 : ['Socket_182',    1.0,                    "Scrunch",                'split_label',      True],
        'ornaments_scrunch_seed'            : ['Socket_181',    0.0,                    "Seed",                   'split_label',      True],
    },

    # ORNAMENTS ADJUSTMENTS
    'ornaments_adjustments_settings' : {
        'ornaments_adjust_size'             : ['Socket_166',    0.0,    "Adjust Size",              'split_label',      True],
        'ornaments_adjust_rotation'         : ['Socket_167',    0.0,    "Adjust Rotation",          'split_label',      True],
        'ornaments_size_random'             : ['Socket_172',    0.0,    "Randomize Size",           'double_widget1',   True],
        'ornaments_size_seed'               : ['Socket_173',    0.0,    "Seed",                     'double_widget2',   True],
        'ornaments_rotation_random'         : ['Socket_168',    0.0,    "Randomize Rotation",       'double_widget1',   True],
        'ornaments_rotation_seed'           : ['Socket_169',    0.0,    "Seed",                     'double_widget2',   True],
    },

    # ORNAMENTS SETTINGS
    'ornaments_settings' : {    
        'ornaments_axis'                    : ['Socket_159',    'Z',                  "Alignment Axis",               'split_label',  True],
        'ornaments_center_position'         : ['Socket_400',    True,               "Center Ornaments Position",    'bool',         True],
        'ornaments_reset_scale'             : ['Socket_170',    True,               "Reset Ornaments Scale",        'bool',         True],
        'ornaments_scale_method'            : ['Socket_171',    'Average Offset',   "Re-scale Method",              'split_label',  True],
        'ornaments_deform'                  : ['Socket_174',    False,              "Deform Ornaments",             'bool',         True],
    },

    # DYNAMICS MAIN
    'dyn_main_settings' : {
        'dyn_main_enable'                   : ['Socket_250',    False,  "Enable Dynamics",          'full_thick',       True],
        'dyn_main_stiffness'                : ['Socket_251',    0.5,    "Stiffness",                'split_label',      True],
        'dyn_main_elasticity'               : ['Socket_252',    0.3,    "Elasticity",               'split_label',      True],
        'dyn_main_damping'                  : ['Socket_253',    0.5,    "Damping",                  'split_label',      True],
        'dyn_main_liveliness'               : ['Socket_254',    0.5,    "Liveliness",               'split_label',      True],
        'dyn_main_shape_factor'             : ['Socket_255',    0.2,    "Effect Factor",            'double_widget1',   True],
        'dyn_main_contrast'                 : ['Socket_256',    0.5,    "Contrast",                 'double_widget2',   True],
        'dyn_main_gravity_strength'         : ['Socket_259',    0.0,    "Strength",                 'split_label',      True],
        'dyn_main_gravity_direction'        : ['Socket_260',    [0.0, 0.0, -1.0],    "Direction",   'split_label',      True],
        'dyn_main_collisions_enable'        : ['Socket_261',    False,  "Enable Collisions",        'bool',             True],
        'dyn_main_collisions_object'        : ['Socket_262',    None,   "Collider Object",          'search_field',     False],
        'dyn_main_collisions_distance'      : ['Socket_263',    0.001,  "Distance",                 'split_label',      True],
        'dyn_main_collisions_repel_force'   : ['Socket_264',    0.005,  "Repel Force",              'split_label',      True],
        'dyn_main_collisions_quality_steps' : ['Socket_265',    5,      "Quality Steps",            'split_label',      True],
    },

    # DYNAMICS WIND EFFECTS
    'dyn_wind_effects' : {
        'dyn_wind_force'                    : ['Socket_268',    0.0,    "Wind Force",               'full_thick',       True],
        'dyn_wind_sim_type'                 : ['Socket_267',    'Simulated',      "Wind Type",                'split_label',      True],
        'dyn_wind_speed'                    : ['Socket_269',    1.0,    "Wind Speed",               'split_label',      True],
        'dyn_wind_turbulence'               : ['Socket_278',    0.1,    "Turbulence",               'split_label',      True],
        'dyn_wind_turbulence_type'          : ['Socket_270',    'Complex',      "Turb. Type",               'split_label',      True],
        'dyn_wind_orientation'              : ['Socket_271',    0.0,    "Orientation",              'split_label',      True],
        'dyn_wind_scale'                    : ['Socket_272',    10.0,   "Scale",                    'split_label',      True],
        'dyn_wind_direction'                : ['Socket_273',    [0.0, 0.0, 0.0],    "Dirrection",   'split_label',      True],
        'dyn_wind_use_effector'             : ['Socket_274',    'Direction',      "Use Effector",             'enum_toggle',      True],
        'dyn_wind_effector_object'          : ['Socket_275',    None,   "Eff. Object",              'split_label',      False],
        'dyn_wind_effector_method'          : ['Socket_276',    'Attract',      "Method",                   'split_label',      True],
    },
    
    # DYNAMICS PULSE EFFECTS
    'dyn_pulse_effects' : {
        'dyn_pulse_strength'                : ['Socket_289',    0.0,    "Pulse Strength",           'full_thick',       True],
        'dyn_pulse_scale'                   : ['Socket_290',    1.0,    "Scale",                    'split_label',      True],
        'dyn_pulse_speed'                   : ['Socket_291',    1.0,    "Speed",                    'split_label',      True],
        'dyn_pulse_move'                    : ['Socket_292',    0.0,    "Move",                     'split_label',      True],
        'dyn_pulse_shift'                   : ['Socket_293',    0.1,    "Position Shift",           'split_label',      True],
        'dyn_pulse_twist'                   : ['Socket_294',    0.175,  "Twist Amount",             'split_label',      True],
    },
    
    # DYNAMICS SIMULATION SETTINGS
    'dyn_sim_settings' : {
        'dyn_settings_sim_points'           : ['Socket_279',    16,     "Simulation Points",          'split_label',    True],
        'dyn_settings_stretch'              : ['Socket_287',    True,   "Affect Thickness (Stretch)", 'bool',           True],
        'dyn_settings_complex_curls'        : ['Socket_280',    False,  "Complex Curls Sim",          'bool',           True],
        'dyn_settings_gen_only'             : ['Socket_286',    False,  "Generated Effects Only",     'bool',           True],
    },
    
    # MATERIALS SETTINGS
    'materials_settings' : {
        'hair_material'                     : ['Socket_297',    None,    "Strands",                 'split_label',     False],
        'flyaways_material'                 : ['Socket_299',    None,    "Flyaways",                'split_label',     False],
        'ornaments_material'                : ['Socket_298',    None,    "Ornaments",               'split_label',     False],
    },

    # UV MAPS SETTINGS
    'uv_maps_settings' : {
        'uv_switch_order'                   : ['Socket_306',    False,   "Switch UV Order",           'bool',           True],
        'uv_pack_hair'                      : ['Socket_300',    False,   "Strands",                   'bool',           True],
        'uv_pack_flys'                      : ['Socket_301',    False,   "Flyaways",                  'bool',           True],
        'uv_pack_ornaments'                 : ['Socket_302',    False,   "Ornaments",                 'bool',           True],
        'uv_pack_margin'                    : ['Socket_303',    0.001,   "Margin",                    'split_label',    True],
        'uv_pack_rotate'                    : ['Socket_304',    True,    "Allow UV Islands Rotation", 'bool',           True],
        'uv_caps_scale'                     : ['Socket_307',    1.0,     "Scale Caps UV",             'split_label',    True],
        'uv_caps_rotate'                    : ['Socket_308',    0.0,     "Rotate Caps UV",            'split_label',    True],
        'uv_caps_invert_rotation'           : ['Socket_309',    False,   "Invert Caps UV Rotation",   'bool',           True],
    },
    
    # SHADES SETTINGS
    'shades_settings' : {
        'shades_color_1'                    : ['Socket_329',    [0.033104, 0.132868, 1.000000, 1.000000], "Color 1", 'full',    True],
        'shades_color_2'                    : ['Socket_330',    [1.000000, 0.973446, 0.000000, 1.000000], "Color 2", 'full',    True],
        'shades_random_per_strand_seed'     : ['Socket_331',    0,       "Random Seed",               'split_label',    True],
        'shades_noise_scale'                : ['Socket_332',    10.0,    "Scale",                     'split_label',    True],
        'shades_noise_roughness'            : ['Socket_333',    0.5,     "Roughness",                 'split_label',    True],
        'shades_noise_contrast'             : ['Socket_334',    0.0,     "Contrast",                  'split_label',    True],
        'shades_noise_stretch'              : ['Socket_335',    0.5,     "Stretch",                   'split_label',    True],
        'shades_noise_twist'                : ['Socket_336',    0.0,     "Twist",                     'split_label',    True],
        'shades_noise_seed'                 : ['Socket_337',    0.0,     "Seed",                      'split_label',    True],
        'shades_hl_move_spot'               : ['Socket_339',    0.3,     "Move Spot",                 'split_label',    True],
        'shades_hl_spot_size'               : ['Socket_340',    0.3,     "Spot Size",                 'split_label',    True],
        'shades_hl_spot_shift'              : ['Socket_341',    0.5,     "Spot Shift",                'split_label',    True],
        'shades_hl_brightness'              : ['Socket_342',    0.7,     "Brightness",                'split_label',    True],
        'shades_hl_detail'                  : ['Socket_343',    0.5,     "Detail",                    'split_label',    True],
        'shades_hl_distortion'              : ['Socket_344',    0.3,     "Distortion",                'split_label',    True],
        'shades_hl_distortion_scale'        : ['Socket_345',    5.0,     "Dist. Scale",               'split_label',    True],
        'shades_hl_distortion_seed'         : ['Socket_346',    0.0,     "Dist. Seed",                'split_label',    True],
        'shades_ends_root_shade'            : ['Socket_347',    0.0,     "Root",                      'full',           True],
        'shades_ends_root_contrast'         : ['Socket_348',    0.0,     "Contrast",                  'full',           True],
        'shades_ends_tip_shade'             : ['Socket_349',    0.0,     "Tip",                       'full',           True],
        'shades_ends_tip_contrast'          : ['Socket_350',    0.0,     "Contrast",                  'full',           True],
        'shades_ends_add_noise'             : ['Socket_351',    0.0,     "Add Noise",                 'split_label',    True],
        'shades_ends_noise_contrast'        : ['Socket_352',    0.0,     "Noise Contrast",            'split_label',    True],
    },
    
    # RESOLUTION SETTINGS
    'hair_settings_resolution' : {
        'settings_resolution_curve'         : ['Socket_5',      40,      "Curve",                     'split_label',     True],
        'settings_resolution_profile'       : ['Socket_24',     20,      "Profile",                   'split_label',     True],
        'settings_render_reso_curve'        : ['Socket_355',    40,      "Curve",                     'split_label',     True],
        'settings_render_reso_profile'      : ['Socket_356',    20,      "Profile",                   'split_label',     True],
        'settings_sync_resolutions'         : ['Socket_357',    True,    "Sync Render to Viewport Resolution", 'bool',   True],
        'settings_preview_render_reso'      : ['Socket_358',    False,   "Preview Render Resolution",          'bool',   True],
        'settings_density_root'             : ['Socket_141',    1.0,     "Root",                      'split_label',     True],
        'settings_density_mid'              : ['Socket_142',    1.0,     "Mid",                       'split_label',     True],
        'settings_density_tip'              : ['Socket_143',    1.0,     "Tip",                       'split_label',     True],
        'settings_density_flys'             : ['Socket_241',    1.0,     "Flyaways",                  'split_label',     True],
        'settings_density_ornaments'        : ['Socket_176',    1.0,     "Ornaments",                 'split_label',     True],
        'settings_taper_root'               : ['Socket_144',    0.0,     "Taper Root",                'split_label',     True],
        'settings_taper_mid'                : ['Socket_145',    0.0,     "Taper Mid",                 'split_label',     True],
        'settings_taper_tip'                : ['Socket_146',    0.0,     "Taper Tip",                 'split_label',     True],
    },
    
    # MISCELLANEOUS SETTINGS
    'hair_settings_misc' : {
        'settings_pre_smooth'               : ['Socket_312',    0.1,     "Pre-Smooth Hair Curves",       'split_label',     True],
        'settings_flip_normals'             : ['Socket_315',    False,   "Flip Normals",                 'bool',            True],
        'settings_fill_caps'                : ['Socket_311',    False,   "Fill Caps",                    'bool',            True],
        'settings_use_original_thickness'   : ['Socket_375',    False,   "Use Original Curve Thickness", 'bool',            True],
        'settings_shading_style'            : ['Socket_316',    'Auto-Smooth',       "Shading Style",                'split_label',     True],
        'settings_auto_smooth_angle'        : ['Socket_317',    1.04720, "Auto-Smooth Angle",            'split_label',     True],
        'settings_align_to_base'            : ['Socket_319',    False,   "Align Root to Base Surface",   'bool',            True],
        'settings_auto_squish_root'         : ['Socket_318',    False,   "Auto-Squish Hair Root",        'bool',            True],
        'settings_auto_squish_strength'     : ['Socket_401',    1.0,     "Squish Strength",              'split_label',     True],
        'settings_auto_squish_limit'        : ['Socket_402',    0.0,     "Limit Squish",                 'split_label',     True],
    },

    # UTILITIES
    'utility_settings' : {
        'utils_arm_bone_count'              : ['Socket_360',    6,       "Bone Count",                'split_label',    True],
        'utils_arm_bbone_handles'           : ['Socket_366',    3,       "Number of Handles",         'split_label',    True],
        'utils_arm_bbone_segments'          : ['Socket_367',    8,       "B-Bone Segments",           'split_label',    True],
        'utils_arm_taper_armature'          : ['Socket_361',    0.0,     "Taper Armature",            'split_label',    True],
        'utils_arm_preview_armature'        : ['Socket_362',    False,   "Preview Armature",          'bool',           True],
        'utils_arm_preview_scale'           : ['Socket_363',    1.0,     "Preview Scale",             'split_label',    True],
        'utils_arm_start'                   : ['Socket_364',    0.0,     "Armature Start",            'split_label',    True],
        'utils_arm_end'                     : ['Socket_365',    1.0,     "Armature End",              'split_label',    True],
        'utils_arm_use_curls'               : ['Socket_374',    False,   "Use Curled Curve",          'bool',           True],
        'utils_cust_geo_enable'             : ['Socket_369',    False,   "Use Custom Hair Geometry",  'bool',           False],
        'utils_cust_geo_object'             : ['Socket_371',    None,    "Object",                    'split_label',    False],
        'utils_cust_geo_axis'               : ['Socket_372',    'Z',       "Deform Axis",               'split_label',    False],
        'utils_cust_geo_rescale'            : ['Socket_373',    True,    "Re-scale Custom Geo",       'bool',           False],
    },

    # INTERNAL UTILITIES
    'internal_utils' : {
        'iu_base_mesh'                      : ['Socket_23',     None,    "Object",                       'split_label',     False],
        'iu_base_uv'                        : ['Socket_353',    "",      "UV Map",                       'split_label',     False],
        'iu_scale_factor'                   : ['Socket_376',    1.0],
        'iu_shape_tab'                      : ['Socket_230',    0],
        'iu_twist_tab'                      : ['Socket_238',    0],
        'iu_bumps_tab'                      : ['Socket_228',    0],
        'iu_braid_tab'                      : ['Socket_229',    0],
        'iu_frizz_tab'                      : ['Socket_231',    0],
        'iu_ornaments_tab'                  : ['Socket_232',    0],
        'iu_dynamics_tab'                   : ['Socket_258',    0],
        'iu_materials_tab'                  : ['Socket_295',    0],
        'iu_settings_tab'                   : ['Socket_310',    0],
        'iu_start_frame'                    : ['Socket_283',    1],
        'iu_end_frame'                      : ['Socket_284',    250],
        'iu_random_per_object'              : ['Socket_285',    0],
        'iu_edit_mode'                      : ['Socket_327',    False],
        'iu_toggle_armature_guide'          : ['Socket_359',    False],
        'iu_gizmos_curve_index'             : ['Socket_403',    0],
        'iu_is_geo_baked'                   : ['Socket_404',    False],
    },
    
    # GLOBAL SETTINGS
    'global_settings' : {
        'gs_global_scale_factor'            : [359,   1.0],
        'gs_groom_optimize'                 : [337,   True],
        'gs_optimization_strength'          : [338,   'Medium'],
        'gs_armature_generate'              : [339,   False],
        'gs_armature_type'                  : [340,   'Normal'],
        'gs_name_bone'                      : [341,   'DEF_hair_bone'],
        'gs_name_bbone'                     : [342,   'DEF_hair_bbone'],
        'gs_name_bbone_handle'              : [343,   'MCH_hair_handle'],
        'gs_armature_parent'                : [344,   False],
        'gs_armature_parent_method'         : [345,   'With Empty Groups'],
        'gs_toggle_gizmos'                  : [346,   False],
        'gs_show_gizmos_in_editing'         : [347,   False],
        'gs_show_scale_gizmos'              : [348,   False],
        'gs_show_twist_gizmos'              : [349,   False],
        'gs_show_root_pinch_gizmos'         : [351,   False],
        'gs_show_tip_pinch_gizmos'          : [350,   False],
        'gs_show_curls_gizmos'              : [352,   False],
        'gs_show_braid_body_gizmos'         : [353,   False],
        'gs_show_braid_strands_gizmos'      : [354,   False],
        'gs_show_braid_roots_gizmos'        : [355,   False],
        'gs_show_split_tip_gizmos'          : [356,   False],
        'gs_show_resolution_gizmos'         : [357,   False],
    }
}



















