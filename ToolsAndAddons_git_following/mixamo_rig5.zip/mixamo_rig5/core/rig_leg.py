# Mixamo Rig 5 - Leg Bone Creation
# Creates the leg control bones with IK/FK switching

import bpy
from math import *
from mathutils import *
from ..utils import *
from ..define import *


def add_leg(self, rig, side, use_name_prefix, c_master_name, coll_ctrl_name, coll_mix_name, coll_intern_name):
    """Add leg control bones with IK/FK switching to the rig.
    
    Args:
        self: The operator instance (for ik_legs property)
        rig: The armature object
        side: 'Left' or 'Right'
        use_name_prefix: Whether to use Mixamo naming prefix
        c_master_name: Name of the master control bone
        coll_ctrl_name: Name of the control bone collection
        coll_mix_name: Name of the mixamo bone collection
        coll_intern_name: Name of the internal/mechanical bone collection
    """
    print("  Add Leg", side)

    _side = "_" + side
    thigh_name = get_mix_name(side + leg_names["thigh"], use_name_prefix)
    calf_name = get_mix_name(side + leg_names["calf"], use_name_prefix)
    foot_name = get_mix_name(side + leg_names["foot"], use_name_prefix)
    toe_name = get_mix_name(side + leg_names["toes"], use_name_prefix)
    toe_end_name = get_mix_name(side + leg_names["toes_end"], use_name_prefix)

    # -- Edit Mode --
    bpy.ops.object.mode_set(mode='EDIT')

    thigh = get_edit_bone(thigh_name)
    calf = get_edit_bone(calf_name)
    foot = get_edit_bone(foot_name)
    toe = get_edit_bone(toe_name)
    toe_end = get_edit_bone(toe_end_name)

    hips = get_edit_bone(get_mix_name(spine_names["pelvis"], use_name_prefix))
    c_hips_free_name = c_prefix + spine_rig_names["hips_free"]
    c_hips_free = get_edit_bone(c_hips_free_name)

    if not thigh or not calf or not foot or not toe:
        print("  Leg bones are missing, skip leg: " + side)
        return

    # Set Mixamo bones in DEF collection
    for b in [thigh, calf, foot, toe, toe_end]:
        set_bone_collection(rig, b, coll_mix_name)

    # Correct straight leg angle - need minimum 0.1 degrees for IK constraints to work
    def get_leg_angle():
        vec1 = calf.head - thigh.head
        vec2 = foot.head - calf.head
        return degrees(vec1.angle(vec2))

    leg_angle = get_leg_angle()

    if leg_angle < 0.1:
        print("  ! Straight leg bones, angle = " + str(leg_angle))
        max_iter = 10000
        i = 0

        while leg_angle < 0.1 and i < max_iter:
            dir = ((thigh.z_axis + calf.z_axis) * 0.5).normalized()
            calf.head += dir * (calf.tail - calf.head).magnitude * 0.0001
            leg_angle = get_leg_angle()
            i += 1

        print("    corrected leg angle: " + str(leg_angle))

    # Thigh IK
    thigh_ik_name = leg_rig_names["thigh_ik"] + _side
    thigh_ik = create_edit_bone(thigh_ik_name)
    copy_bone_transforms(thigh, thigh_ik)

    # Auto-align knee position with global Y axis to ensure IK pole vector is physically correct
    leg_axis = calf.tail - thigh.head
    leg_midpoint = (thigh.head + calf.tail) * 0.5

    dir = calf.head - leg_midpoint
    cur_vec = project_vector_onto_plane(dir, leg_axis)
    global_y_vec = project_vector_onto_plane(Vector((0, -1, 0)), leg_axis)

    signed_cur_angle = signed_angle(cur_vec, global_y_vec, leg_axis)
    print("  IK base angle:", degrees(signed_cur_angle))

    # Rotate
    rotated_point = rotate_point(calf.head.copy(), -signed_cur_angle, leg_midpoint, leg_axis)

    # Check
    dir = rotated_point - leg_midpoint
    cur_vec = project_vector_onto_plane(dir, leg_axis)
    signed_cur_angle = signed_angle(cur_vec, global_y_vec, leg_axis)
    print("    IK corrected angle:", degrees(signed_cur_angle))

    thigh_ik.tail = rotated_point
    thigh_ik.parent = c_hips_free
    set_bone_collection(rig, thigh_ik, coll_intern_name)

    # Thigh FK Ctrl
    c_thigh_fk_name = c_prefix + leg_rig_names["thigh_fk"] + _side
    c_thigh_fk = create_edit_bone(c_thigh_fk_name)
    copy_bone_transforms(thigh_ik, c_thigh_fk)
    c_thigh_fk.parent = c_hips_free
    set_bone_collection(rig, c_thigh_fk, coll_ctrl_name)
    c_thigh_fk["mixamo_ctrl"] = 1

    # Calf IK
    calf_ik_name = leg_rig_names["calf_ik"] + _side
    calf_ik_exist = get_edit_bone(calf_ik_name)
    calf_ik = create_edit_bone(calf_ik_name)
    if calf_ik_exist is None:
        copy_bone_transforms(calf, calf_ik)
    calf_ik.head = thigh_ik.tail.copy()
    calf_ik.tail = foot.head.copy()
    calf_ik.parent = thigh_ik
    calf_ik.use_connect = True
    set_bone_collection(rig, calf_ik, coll_intern_name)

    # Align thigh and calf IK roll
    align_bone_z_axis(calf_ik, (calf_ik.head - leg_midpoint))
    align_bone_z_axis(thigh_ik, calf_ik.z_axis)
    copy_bone_transforms(thigh_ik, c_thigh_fk)

    # Calf FK Ctrl
    c_calf_fk_name = c_prefix + leg_rig_names["calf_fk"] + _side
    c_calf_fk = create_edit_bone(c_calf_fk_name)
    copy_bone_transforms(calf_ik, c_calf_fk)
    c_calf_fk.parent = c_thigh_fk
    set_bone_collection(rig, c_calf_fk, coll_ctrl_name)
    c_calf_fk["mixamo_ctrl"] = 1

    # Foot FK Ctrl
    c_foot_fk_name = c_prefix + leg_rig_names["foot_fk"] + _side
    c_foot_fk = create_edit_bone(c_foot_fk_name)
    copy_bone_transforms(foot, c_foot_fk)
    c_foot_fk.tail[2] = foot.head[2]
    align_bone_z_axis(c_foot_fk, Vector((0, 0, 1)))
    c_foot_fk.parent = c_calf_fk
    set_bone_collection(rig, c_foot_fk, coll_ctrl_name)
    c_foot_fk["mixamo_ctrl"] = 1

    # Foot FK
    foot_fk_name = leg_rig_names["foot_fk"] + _side
    foot_fk = create_edit_bone(foot_fk_name)
    copy_bone_transforms(foot, foot_fk)
    foot_fk.parent = c_foot_fk
    set_bone_collection(rig, foot_fk, coll_intern_name)

    # Foot IK Ctrl
    c_foot_ik_name = c_prefix + leg_rig_names["foot_ik"] + _side
    c_foot_ik = create_edit_bone(c_foot_ik_name)
    copy_bone_transforms(foot, c_foot_ik)
    c_foot_ik.tail[2] = foot.head[2]
    align_bone_z_axis(c_foot_ik, Vector((0, 0, 1)))
    set_bone_collection(rig, c_foot_ik, coll_ctrl_name)
    c_foot_ik["mixamo_ctrl"] = 1

    # Foot IK
    foot_ik_name = leg_rig_names["foot_ik"] + _side
    foot_ik = create_edit_bone(foot_ik_name)
    copy_bone_transforms(foot, foot_ik)
    foot_ik.parent = c_foot_ik
    set_bone_collection(rig, foot_ik, coll_intern_name)

    # Foot Snap
    foot_snap_name = leg_rig_names["foot_snap"] + _side
    foot_snap = create_edit_bone(foot_snap_name)
    copy_bone_transforms(c_foot_ik, foot_snap)
    foot_snap.parent = foot_ik
    set_bone_collection(rig, foot_snap, coll_intern_name)

    # Foot IK target
    foot_ik_target_name = leg_rig_names["foot_ik_target"] + _side
    foot_ik_target = create_edit_bone(foot_ik_target_name)
    foot_ik_target.head = foot_ik.head.copy()
    foot_vec = (foot.tail - foot.head)
    foot_ik_target.tail = foot_ik_target.head - (foot_vec * 0.25)
    align_bone_z_axis(foot_ik_target, Vector((0, 0, 1)))
    set_bone_collection(rig, foot_ik_target, coll_intern_name)

    # Foot Heel Out
    heel_out_name = leg_rig_names["heel_out"] + _side
    heel_out = create_edit_bone(heel_out_name)
    heel_out.head, heel_out.tail = Vector((0, 0, 0)), Vector((0, 0, 1))
    heel_out.parent = c_foot_ik
    set_bone_collection(rig, heel_out, coll_intern_name)

    # Foot Heel In
    heel_in_name = leg_rig_names["heel_in"] + _side
    heel_in = create_edit_bone(heel_in_name)
    heel_in.head, heel_in.tail = Vector((0, 0, 0)), Vector((0, 0, 1))
    heel_in.parent = heel_out
    set_bone_collection(rig, heel_in, coll_intern_name)

    # Foot Heel Mid
    heel_mid_name = leg_rig_names["heel_mid"] + _side
    heel_mid = create_edit_bone(heel_mid_name)
    heel_mid.head, heel_mid.tail = Vector((0, 0, 0)), Vector((0, 0, 1))
    heel_mid.parent = heel_in
    set_bone_collection(rig, heel_mid, coll_intern_name)

    heel_mid.head[0], heel_mid.head[1], heel_mid.head[2] = foot.head[0], foot.head[1], foot.tail[2]
    heel_mid.tail = foot.tail.copy()
    heel_mid.tail[2] = heel_mid.head[2]
    heel_mid.tail = heel_mid.head + (heel_mid.tail - heel_mid.head) * 0.5
    align_bone_x_axis(heel_mid, foot.x_axis)

    copy_bone_transforms(heel_mid, heel_in)
    fac = 1 if side == "Left" else -1
    heel_in.head += foot.x_axis.normalized() * foot.length * 0.3 * fac
    heel_in.tail += foot.x_axis.normalized() * foot.length * 0.3 * fac

    copy_bone_transforms(heel_mid, heel_out)
    heel_out.head += foot.x_axis.normalized() * foot.length * 0.3 * -fac
    heel_out.tail += foot.x_axis.normalized() * foot.length * 0.3 * -fac

    # Toe End
    toes_end_name = leg_rig_names["toes_end"] + _side
    toes_end = create_edit_bone(toes_end_name)
    copy_bone_transforms(toe, toes_end)
    toe_vec = (toes_end.tail - toes_end.head)
    toes_end.tail += toe_vec
    toes_end.head += toe_vec
    toes_end.parent = heel_mid
    set_bone_collection(rig, toes_end, coll_intern_name)

    # Toe End 01
    toes_end_01_name = leg_rig_names["toes_end_01"] + _side
    toes_end_01 = create_edit_bone(toes_end_01_name)
    copy_bone_transforms(toes_end, toes_end_01)
    vec = toes_end_01.tail - toes_end_01.head
    toes_end_01.tail = toes_end_01.head + (vec * 0.5)
    toes_end_01.parent = toes_end
    set_bone_collection(rig, toes_end_01, coll_intern_name)

    # Foot 01 Ctrl
    c_foot_01_name = c_prefix + leg_rig_names["foot_01"] + _side
    c_foot_01 = create_edit_bone(c_foot_01_name)
    copy_bone_transforms(foot, c_foot_01)
    c_foot_01_vec = c_foot_01.tail - c_foot_01.head
    c_foot_01.tail += c_foot_01_vec
    c_foot_01.head += c_foot_01_vec
    c_foot_01.parent = toes_end
    set_bone_collection(rig, c_foot_01, coll_ctrl_name)
    c_foot_01["mixamo_ctrl"] = 1

    # Foot_ik_target parent
    foot_ik_target.parent = c_foot_01

    # Foot 01 Pole
    foot_01_pole_name = leg_rig_names["foot_01_pole"] + _side
    foot_01_pole = create_edit_bone(foot_01_pole_name)
    foot_01_pole.head = c_foot_01.head + (c_foot_01.z_axis * 0.05 * c_foot_01.length * 40)
    foot_01_pole.tail = foot_01_pole.head + (c_foot_01.z_axis * 0.05 * c_foot_01.length * 40)
    foot_01_pole.roll = radians(180)
    foot_01_pole.parent = c_foot_01
    set_bone_collection(rig, foot_01_pole, coll_intern_name)

    # Toe IK Ctrl
    c_toe_ik_name = c_prefix + leg_rig_names["toes_ik"] + _side
    c_toe_ik = create_edit_bone(c_toe_ik_name)
    copy_bone_transforms(toe, c_toe_ik)
    c_toe_ik.parent = toes_end
    set_bone_collection(rig, c_toe_ik, coll_ctrl_name)
    c_toe_ik["mixamo_ctrl"] = 1

    # Toe Track
    toe_track_name = leg_rig_names["toes_track"] + _side
    toe_track = create_edit_bone(toe_track_name)
    copy_bone_transforms(toe, toe_track)
    toe_track.parent = foot_ik
    set_bone_collection(rig, toe_track, coll_intern_name)

    # Toe_01 IK
    toe_01_ik_name = leg_rig_names["toes_01_ik"] + _side
    toe_01_ik = create_edit_bone(toe_01_ik_name)
    copy_bone_transforms(toe, toe_01_ik)
    toe_01_ik.tail = toe_01_ik.head + (toe_01_ik.tail - toe_01_ik.head) * 0.5
    toe_01_ik.parent = toe_track
    set_bone_collection(rig, toe_01_ik, coll_intern_name)

    # Toe_02
    toe_02_name = leg_rig_names["toes_02"] + _side
    toe_02 = create_edit_bone(toe_02_name)
    copy_bone_transforms(toe, toe_02)
    toe_02.head = toe_02.head + (toe_02.tail - toe_02.head) * 0.5
    toe_02.parent = toe_01_ik
    set_bone_collection(rig, toe_02, coll_intern_name)

    # Toe FK Ctrl
    c_toe_fk_name = c_prefix + leg_rig_names["toes_fk"] + _side
    c_toe_fk = create_edit_bone(c_toe_fk_name)
    copy_bone_transforms(toe, c_toe_fk)
    c_toe_fk.parent = foot_fk
    set_bone_collection(rig, c_toe_fk, coll_ctrl_name)
    c_toe_fk["mixamo_ctrl"] = 1

    # Foot Roll Cursor Ctrl
    c_foot_roll_cursor_name = c_prefix + leg_rig_names["foot_roll_cursor"] + _side
    c_foot_roll_cursor = create_edit_bone(c_foot_roll_cursor_name)
    copy_bone_transforms(c_foot_ik, c_foot_roll_cursor)
    vec = c_foot_roll_cursor.tail - c_foot_roll_cursor.head
    dist = 1.2
    c_foot_roll_cursor.head -= vec * dist
    c_foot_roll_cursor.tail -= vec * dist
    c_foot_roll_cursor.parent = c_foot_ik
    set_bone_collection(rig, c_foot_roll_cursor, coll_ctrl_name)
    c_foot_roll_cursor["mixamo_ctrl"] = 1

    # Pole IK Ctrl
    c_pole_ik_name = c_prefix + leg_rig_names["pole_ik"] + _side
    c_pole_ik = create_edit_bone(c_pole_ik_name)
    set_bone_collection(rig, c_pole_ik, coll_ctrl_name)
    c_pole_ik["mixamo_ctrl"] = 1

    plane_normal = (thigh_ik.head - calf_ik.tail)
    prepole_dir = calf_ik.head - leg_midpoint
    pole_pos = calf_ik.head + prepole_dir.normalized()
    pole_pos = project_point_onto_plane(pole_pos, calf_ik.head, plane_normal)
    pole_pos = calf_ik.head + ((pole_pos - calf_ik.head).normalized() * (calf_ik.head - thigh.head).magnitude * 1.7)

    c_pole_ik.head = pole_pos
    c_pole_ik.tail = [c_pole_ik.head[0], c_pole_ik.head[1], c_pole_ik.head[2] + (0.165 * thigh_ik.length * 2)]

    ik_pole_angle = get_pole_angle(thigh_ik, calf_ik, c_pole_ik.head)

    # -- Pose Mode --
    bpy.ops.object.mode_set(mode='POSE')

    # Setup constraints - call helper function
    _setup_leg_constraints(
        self, rig, side, _side,
        thigh_name, calf_name, foot_name, toe_name,
        thigh_ik_name, calf_ik_name, foot_ik_name, foot_fk_name,
        c_thigh_fk_name, c_calf_fk_name, c_foot_fk_name, c_foot_ik_name,
        c_pole_ik_name, c_foot_01_name, c_toe_ik_name, c_toe_fk_name,
        c_foot_roll_cursor_name, foot_ik_target_name, foot_01_pole_name,
        heel_out_name, heel_in_name, heel_mid_name,
        toes_end_name, toes_end_01_name, toe_track_name,
        toe_01_ik_name, toe_02_name, foot_snap_name,
        ik_pole_angle
    )


def _setup_leg_constraints(
    self, rig, side, _side,
    thigh_name, calf_name, foot_name, toe_name,
    thigh_ik_name, calf_ik_name, foot_ik_name, foot_fk_name,
    c_thigh_fk_name, c_calf_fk_name, c_foot_fk_name, c_foot_ik_name,
    c_pole_ik_name, c_foot_01_name, c_toe_ik_name, c_toe_fk_name,
    c_foot_roll_cursor_name, foot_ik_target_name, foot_01_pole_name,
    heel_out_name, heel_in_name, heel_mid_name,
    toes_end_name, toes_end_01_name, toe_track_name,
    toe_01_ik_name, toe_02_name, foot_snap_name,
    ik_pole_angle
):
    """Setup all constraints for leg bones."""
    
    cns_power = 8

    # Calf IK constraints
    calf_ik_pb = get_pose_bone(calf_ik_name)
    cns_name = "IK"
    ik_cns = calf_ik_pb.constraints.get(cns_name)
    if ik_cns is None:
        ik_cns = calf_ik_pb.constraints.new("IK")
        ik_cns.name = cns_name
    ik_cns.target = rig
    ik_cns.subtarget = foot_ik_target_name
    ik_cns.pole_target = rig
    ik_cns.pole_subtarget = c_pole_ik_name
    ik_cns.pole_angle = ik_pole_angle
    ik_cns.chain_count = 2
    ik_cns.use_tail = True
    ik_cns.use_stretch = False

    calf_ik_pb.lock_ik_y = True
    calf_ik_pb.lock_ik_z = True

    # Foot IK constraints
    foot_ik_pb = get_pose_bone(foot_ik_name)

    cns_name = "Copy Location"
    copy_loc_cns = foot_ik_pb.constraints.get(cns_name)
    if copy_loc_cns is None:
        copy_loc_cns = foot_ik_pb.constraints.new("COPY_LOCATION")
        copy_loc_cns.name = cns_name
    copy_loc_cns.target = rig
    copy_loc_cns.subtarget = calf_ik_name
    copy_loc_cns.head_tail = 1.0

    cns_name = "TrackTo"
    cns = foot_ik_pb.constraints.get(cns_name)
    if cns is None:
        cns = foot_ik_pb.constraints.new("TRACK_TO")
        cns.name = cns_name
    cns.target = rig
    cns.subtarget = c_foot_01_name
    cns.head_tail = 0.0
    cns.track_axis = "TRACK_Y"
    cns.up_axis = "UP_Z"
    cns.use_target_z = True

    cns_name = "Locked Track"
    cns = foot_ik_pb.constraints.get(cns_name)
    if cns is None:
        cns = foot_ik_pb.constraints.new("LOCKED_TRACK")
        cns.name = cns_name
    cns.target = rig
    cns.subtarget = foot_01_pole_name
    cns.head_tail = 0.0
    cns.track_axis = "TRACK_Z"
    cns.lock_axis = "LOCK_Y"

    cns_name = "Copy Scale"
    cns = foot_ik_pb.constraints.get(cns_name)
    if cns is None:
        cns = foot_ik_pb.constraints.new("COPY_SCALE")
        cns.name = cns_name
    cns.target = rig
    cns.subtarget = c_foot_ik_name

    # Foot Ctrl IK - Child Of
    c_foot_ik_pb = get_pose_bone(c_foot_ik_name)
    cns_name = "Child Of"
    cns = c_foot_ik_pb.constraints.get(cns_name)
    if cns is None:
        cns = c_foot_ik_pb.constraints.new("CHILD_OF")
        cns.name = cns_name
    cns.target = rig
    cns.subtarget = "Ctrl_Master"

    # Pole IK - Child Of
    c_pole_ik_pb = get_pose_bone(c_pole_ik_name)
    cns_name = "Child Of"
    child_cns = c_pole_ik_pb.constraints.get(cns_name)
    if child_cns is None:
        child_cns = c_pole_ik_pb.constraints.new("CHILD_OF")
        child_cns.name = cns_name
    child_cns.target = rig
    child_cns.subtarget = c_foot_ik_name

    # Toe End constraints
    toes_end_pb = get_pose_bone(toes_end_name)
    length = toes_end_pb.length * cns_power

    cns_name = "Transformation"
    cns = toes_end_pb.constraints.get(cns_name)
    if cns is None:
        cns = toes_end_pb.constraints.new("TRANSFORM")
        cns.name = cns_name
    cns.target = rig
    cns.subtarget = c_foot_roll_cursor_name
    cns.use_motion_extrapolate = True
    cns.target_space = cns.owner_space = "LOCAL"
    cns.map_from = "LOCATION"
    cns.from_min_z = 0.5 * length
    cns.from_max_z = -0.5 * length
    cns.map_to = "ROTATION"
    cns.map_to_x_from = "Z"
    cns.map_to_z_from = "X"
    cns.to_min_x_rot = -2.61
    cns.to_max_x_rot = 2.61
    cns.mix_mode_rot = "ADD"

    cns_name = "Limit Rotation"
    cns = toes_end_pb.constraints.get(cns_name)
    if cns is None:
        cns = toes_end_pb.constraints.new("LIMIT_ROTATION")
        cns.name = cns_name
    cns.owner_space = "LOCAL"
    cns.use_limit_x = True
    cns.min_x = -2 * pi
    cns.max_x = 0.0

    # Toe 01 IK constraints
    toe_01_ik_pb = get_pose_bone(toe_01_ik_name)
    cns_name = "Copy Transforms"
    cns = toe_01_ik_pb.constraints.get(cns_name)
    if cns is None:
        cns = toe_01_ik_pb.constraints.new("COPY_TRANSFORMS")
        cns.name = cns_name
    cns.target = rig
    cns.subtarget = c_toe_ik_name
    cns.mix_mode = "REPLACE"
    cns.target_space = cns.owner_space = "WORLD"

    # Toe 02 constraints
    toe_02_pb = get_pose_bone(toe_02_name)
    cns_name = "Copy CopyRotation"
    cns = toe_02_pb.constraints.get(cns_name)
    if cns is None:
        cns = toe_02_pb.constraints.new("COPY_ROTATION")
        cns.name = cns_name
    cns.target = rig
    cns.subtarget = c_toe_ik_name
    cns.mix_mode = "REPLACE"
    cns.target_space = cns.owner_space = "WORLD"

    # Toe Track constraints
    toe_track_pb = get_pose_bone(toe_track_name)
    cns_name = "TrackTo"
    cns = toe_track_pb.constraints.get(cns_name)
    if cns is None:
        cns = toe_track_pb.constraints.new("TRACK_TO")
        cns.name = cns_name
    cns.target = rig
    cns.subtarget = toes_end_01_name
    cns.head_tail = 0.0
    cns.track_axis = 'TRACK_Y'
    cns.up_axis = "UP_Z"
    cns.use_target_z = True

    # Heel Mid constraints
    heel_mid_pb = get_pose_bone(heel_mid_name)
    length = heel_mid_pb.length * cns_power

    cns_name = "Transformation"
    cns = heel_mid_pb.constraints.get(cns_name)
    if cns is None:
        cns = heel_mid_pb.constraints.new("TRANSFORM")
        cns.name = cns_name
    cns.target = rig
    cns.subtarget = c_foot_roll_cursor_name
    cns.owner_space = cns.target_space = "LOCAL"
    cns.map_from = "LOCATION"
    cns.from_min_z = -0.25 * length
    cns.from_max_z = 0.25 * length
    cns.map_to = "ROTATION"
    cns.map_to_x_from = "Z"
    cns.map_to_y_from = "X"
    cns.map_to_z_from = "Y"
    cns.to_min_x_rot = radians(100)
    cns.to_max_x_rot = -radians(100)
    cns.mix_mode_rot = 'ADD'

    cns_name = "Limit Rotation"
    cns = heel_mid_pb.constraints.get(cns_name)
    if cns is None:
        cns = heel_mid_pb.constraints.new("LIMIT_ROTATION")
        cns.name = cns_name
    cns.use_limit_x = True
    cns.min_x = radians(0)
    cns.max_x = radians(360)
    cns.owner_space = "LOCAL"

    # Heel In constraints
    heel_in_pb = get_pose_bone(heel_in_name)
    length = heel_in_pb.length * cns_power

    cns_name = "Transformation"
    cns = heel_in_pb.constraints.get(cns_name)
    if cns is None:
        cns = heel_in_pb.constraints.new("TRANSFORM")
        cns.name = cns_name
    cns.target = rig
    cns.subtarget = c_foot_roll_cursor_name
    cns.owner_space = cns.target_space = "LOCAL"
    cns.map_from = "LOCATION"
    cns.from_min_x = -0.25 * length
    cns.from_max_x = 0.25 * length
    cns.map_to = "ROTATION"
    cns.map_to_x_from = "Z"
    cns.map_to_y_from = "X"
    cns.map_to_z_from = "Y"
    cns.to_min_y_rot = -radians(100)
    cns.to_max_y_rot = radians(100)
    cns.mix_mode_rot = 'ADD'

    cns_name = "Limit Rotation"
    cns = heel_in_pb.constraints.get(cns_name)
    if cns is None:
        cns = heel_in_pb.constraints.new("LIMIT_ROTATION")
        cns.name = cns_name
    cns.use_limit_y = True
    if side == "Left":
        cns.min_y = 0.0
        cns.max_y = radians(90)
    elif side == "Right":
        cns.min_y = radians(-90)
        cns.max_y = radians(0.0)
    cns.owner_space = "LOCAL"

    # Heel Out constraints
    heel_out_pb = get_pose_bone(heel_out_name)
    length = heel_out_pb.length * cns_power

    cns_name = "Transformation"
    cns = heel_out_pb.constraints.get(cns_name)
    if cns is None:
        cns = heel_out_pb.constraints.new("TRANSFORM")
        cns.name = cns_name
    cns.target = rig
    cns.subtarget = c_foot_roll_cursor_name
    cns.owner_space = cns.target_space = "LOCAL"
    cns.map_from = "LOCATION"
    cns.from_min_x = -0.25 * length
    cns.from_max_x = 0.25 * length
    cns.map_to = "ROTATION"
    cns.map_to_x_from = "Z"
    cns.map_to_y_from = "X"
    cns.map_to_z_from = "Y"
    cns.to_min_y_rot = -radians(100)
    cns.to_max_y_rot = radians(100)
    cns.mix_mode_rot = 'ADD'

    cns_name = "Limit Rotation"
    cns = heel_out_pb.constraints.get(cns_name)
    if cns is None:
        cns = heel_out_pb.constraints.new("LIMIT_ROTATION")
        cns.name = cns_name
    cns.use_limit_y = True
    if side == "Left":
        cns.min_y = radians(-90)
        cns.max_y = radians(0.0)
    elif side == "Right":
        cns.min_y = radians(0.0)
        cns.max_y = radians(90)
    cns.owner_space = "LOCAL"

    # Mixamo bone constraints
    foot_pb = get_pose_bone(foot_name)
    thigh_pb = get_pose_bone(thigh_name)

    # IK-FK switch property
    if "ik_fk_switch" not in c_foot_ik_pb.keys():
        create_custom_prop(node=c_foot_ik_pb, prop_name="ik_fk_switch", prop_val=0.0, prop_min=0.0, prop_max=1.0, prop_description="IK-FK switch value")

    c_foot_ik_pb["ik_fk_switch"] = 0.0 if self.ik_legs else 1.0

    # Thigh constraints
    cns_name = "IK_follow"
    cns_ik = thigh_pb.constraints.get(cns_name)
    if cns_ik is None:
        cns_ik = thigh_pb.constraints.new("COPY_TRANSFORMS")
        cns_ik.name = cns_name
    cns_ik.target = rig
    cns_ik.subtarget = thigh_ik_name
    cns_ik.influence = 1.0

    cns_name = "FK_follow"
    cns_fk = thigh_pb.constraints.get(cns_name)
    if cns_fk is None:
        cns_fk = thigh_pb.constraints.new("COPY_TRANSFORMS")
        cns_fk.name = cns_name
    cns_fk.target = rig
    cns_fk.subtarget = c_thigh_fk_name
    cns_fk.influence = 0.0

    add_driver_to_prop(rig, 'pose.bones["' + thigh_name + '"].constraints["' + cns_name + '"].influence', 'pose.bones["' + c_foot_ik_name + '"]["ik_fk_switch"]', array_idx=-1, exp="var")

    # Calf constraints
    calf_pb = get_pose_bone(calf_name)

    cns_name = "IK_follow"
    cns_ik = calf_pb.constraints.get(cns_name)
    if cns_ik is None:
        cns_ik = calf_pb.constraints.new("COPY_TRANSFORMS")
        cns_ik.name = cns_name
    cns_ik.target = rig
    cns_ik.subtarget = calf_ik_name
    cns_ik.influence = 1.0

    cns_name = "FK_follow"
    cns_fk = calf_pb.constraints.get(cns_name)
    if cns_fk is None:
        cns_fk = calf_pb.constraints.new("COPY_TRANSFORMS")
        cns_fk.name = cns_name
    cns_fk.target = rig
    cns_fk.subtarget = c_calf_fk_name
    cns_fk.influence = 0.0

    add_driver_to_prop(rig, 'pose.bones["' + calf_name + '"].constraints["' + cns_name + '"].influence', 'pose.bones["' + c_foot_ik_name + '"]["ik_fk_switch"]', array_idx=-1, exp="var")

    # Foot constraints
    cns_name = "IK_follow"
    cns_ik = foot_pb.constraints.get(cns_name)
    if cns_ik is None:
        cns_ik = foot_pb.constraints.new("COPY_TRANSFORMS")
        cns_ik.name = cns_name
    cns_ik.target = rig
    cns_ik.subtarget = foot_ik_name
    cns_ik.influence = 1.0

    cns_name = "FK_follow"
    cns_fk = foot_pb.constraints.get(cns_name)
    if cns_fk is None:
        cns_fk = foot_pb.constraints.new("COPY_TRANSFORMS")
        cns_fk.name = cns_name
    cns_fk.target = rig
    cns_fk.subtarget = foot_fk_name
    cns_fk.influence = 0.0

    add_driver_to_prop(rig, 'pose.bones["' + foot_name + '"].constraints["' + cns_name + '"].influence', 'pose.bones["' + c_foot_ik_name + '"]["ik_fk_switch"]', array_idx=-1, exp="var")

    # Toe constraints
    toe_pb = get_pose_bone(toe_name)

    cns_name = "IK_Rot_follow"
    cns_ik_rot = toe_pb.constraints.get(cns_name)
    if cns_ik_rot is None:
        cns_ik_rot = toe_pb.constraints.new("COPY_ROTATION")
        cns_ik_rot.name = cns_name
    cns_ik_rot.target = rig
    cns_ik_rot.subtarget = c_toe_ik_name
    cns_ik_rot.influence = 1.0

    cns_name = "IK_Scale_follow"
    cns_ik_scale = toe_pb.constraints.get(cns_name)
    if cns_ik_scale is None:
        cns_ik_scale = toe_pb.constraints.new("COPY_SCALE")
        cns_ik_scale.name = cns_name
    cns_ik_scale.target = rig
    cns_ik_scale.subtarget = c_toe_ik_name
    cns_ik_scale.influence = 1.0

    cns_name_fk_rot = "FK_Rot_follow"
    cns_fk_rot = toe_pb.constraints.get(cns_name_fk_rot)
    if cns_fk_rot is None:
        cns_fk_rot = toe_pb.constraints.new("COPY_ROTATION")
        cns_fk_rot.name = cns_name_fk_rot
    cns_fk_rot.target = rig
    cns_fk_rot.subtarget = c_toe_fk_name
    cns_fk_rot.influence = 1.0

    cns_name_fk_scale = "FK_Scale_follow"
    cns_fk_scale = toe_pb.constraints.get(cns_name_fk_scale)
    if cns_fk_scale is None:
        cns_fk_scale = toe_pb.constraints.new("COPY_SCALE")
        cns_fk_scale.name = cns_name_fk_scale
    cns_fk_scale.target = rig
    cns_fk_scale.subtarget = c_toe_fk_name
    cns_fk_scale.influence = 1.0

    add_driver_to_prop(rig, 'pose.bones["' + toe_name + '"].constraints["' + cns_name_fk_rot + '"].influence', 'pose.bones["' + c_foot_ik_name + '"]["ik_fk_switch"]', array_idx=-1, exp="var")
    add_driver_to_prop(rig, 'pose.bones["' + toe_name + '"].constraints["' + cns_name_fk_scale + '"].influence', 'pose.bones["' + c_foot_ik_name + '"]["ik_fk_switch"]', array_idx=-1, exp="var")

    # Get pose bones for final setup
    c_foot_01_pb = get_pose_bone(c_foot_01_name)
    c_foot_roll_cursor_pb = get_pose_bone(c_foot_roll_cursor_name)
    c_thigh_fk_pb = get_pose_bone(c_thigh_fk_name)
    c_calf_fk_pb = get_pose_bone(c_calf_fk_name)
    c_foot_fk_pb = get_pose_bone(c_foot_fk_name)
    c_toe_ik_pb = get_pose_bone(c_toe_ik_name)
    c_toe_fk_pb = get_pose_bone(c_toe_fk_name)

    # Set transform locks
    lock_pbone_transform(c_foot_roll_cursor_pb, "location", [1])
    lock_pbone_transform(c_foot_roll_cursor_pb, "rotation", [0, 1, 2])
    lock_pbone_transform(c_foot_roll_cursor_pb, "scale", [0, 1, 2])

    lock_pbone_transform(c_foot_01_pb, "location", [0, 1, 2])
    lock_pbone_transform(c_foot_01_pb, "rotation", [1, 2])
    lock_pbone_transform(c_foot_01_pb, "scale", [0, 1, 2])

    lock_pbone_transform(c_foot_fk_pb, "location", [0, 1, 2])

    lock_pbone_transform(c_pole_ik_pb, "rotation", [0, 1, 2])
    lock_pbone_transform(c_pole_ik_pb, "scale", [0, 1, 2])

    lock_pbone_transform(c_thigh_fk_pb, "location", [0, 1, 2])
    lock_pbone_transform(c_calf_fk_pb, "location", [0, 1, 2])

    c_pbones_list = [c_foot_ik_pb, c_pole_ik_pb, c_foot_01_pb, c_foot_roll_cursor_pb, c_thigh_fk_pb, c_calf_fk_pb, c_foot_fk_pb, c_toe_fk_pb, c_toe_ik_pb]

    # Set custom shapes
    set_bone_custom_shape(c_thigh_fk_pb, "cs_thigh_fk")
    set_bone_custom_shape(c_calf_fk_pb, "cs_calf_fk")
    set_bone_custom_shape(c_foot_ik_pb, "cs_foot")
    set_bone_custom_shape(c_foot_fk_pb, "cs_foot")
    set_bone_custom_shape(c_pole_ik_pb, "cs_sphere_012")
    set_bone_custom_shape(c_foot_roll_cursor_pb, "cs_foot_roll")
    set_bone_custom_shape(c_foot_01_pb, "cs_foot_01")
    set_bone_custom_shape(c_toe_fk_pb, "cs_toe")
    set_bone_custom_shape(c_toe_ik_pb, "cs_toe")

    # Set custom shape drivers - Blender 5.0 always uses xyz array
    ik_controls_names = [c_foot_ik_name, c_foot_01_name, c_toe_ik_name, c_foot_roll_cursor_name, c_pole_ik_name]
    arr_ids = [0, 1, 2]

    for n in ik_controls_names:
        dr_dp = 'pose.bones["' + n + '"].' + get_custom_shape_scale_prop_name()
        tar_dp = 'pose.bones["' + c_foot_ik_name + '"]["ik_fk_switch"]'
        for arr_id in arr_ids:
            add_driver_to_prop(rig, dr_dp, tar_dp, array_idx=arr_id, exp="1-var")

    fk_controls_names = [c_foot_fk_name, c_thigh_fk_name, c_calf_fk_name, c_toe_fk_name]

    for n in fk_controls_names:
        dr_dp = 'pose.bones["' + n + '"].' + get_custom_shape_scale_prop_name()
        tar_dp = 'pose.bones["' + c_foot_ik_name + '"]["ik_fk_switch"]'
        for arr_id in arr_ids:
            add_driver_to_prop(rig, dr_dp, tar_dp, array_idx=arr_id, exp="var")

    # Set rotation mode and color group
    for pb in c_pbones_list:
        pb.rotation_mode = "XYZ"
        set_bone_color_group(rig, pb, "body" + _side.lower())
