# Mixamo Rig 5 - Arm Bone Creation
# Creates the arm control bones with IK/FK switching

import bpy
from math import *
from mathutils import *
from ..utils import *
from ..define import *


def add_arm(self, rig, side, use_name_prefix, c_master_name, coll_ctrl_name, coll_mix_name, coll_intern_name):
    """Add arm control bones with IK/FK switching to the rig.
    
    Args:
        self: The operator instance (for ik_arms property)
        rig: The armature object
        side: 'Left' or 'Right'
        use_name_prefix: Whether to use Mixamo naming prefix
        c_master_name: Name of the master control bone
        coll_ctrl_name: Name of the control bone collection
        coll_mix_name: Name of the mixamo bone collection
        coll_intern_name: Name of the internal/mechanical bone collection
    """
    print("  Add Arm", side)
    _side = "_" + side
    shoulder_name = get_mix_name(side + arm_names["shoulder"], use_name_prefix)
    arm_name = get_mix_name(side + arm_names["arm"], use_name_prefix)
    forearm_name = get_mix_name(side + arm_names["forearm"], use_name_prefix)
    hand_name = get_mix_name(side + arm_names["hand"], use_name_prefix)

    # -- Edit Mode --
    bpy.ops.object.mode_set(mode='EDIT')

    shoulder = get_edit_bone(shoulder_name)
    arm = get_edit_bone(arm_name)
    forearm = get_edit_bone(forearm_name)
    hand = get_edit_bone(hand_name)

    if not shoulder or not arm or not forearm or not hand:
        print("    Arm bones are missing, skip arm: " + side)
        return

    # Create finger bones
    fingers_names = []
    c_fingers_names = []
    fingers = []
    finger_leaves = []

    for fname in fingers_type:
        for i in range(1, 4):
            finger_name = get_mix_name(side + "Hand" + fname + str(i), use_name_prefix)
            finger = get_edit_bone(finger_name)
            if finger is None:
                continue

            fingers_names.append(finger_name)
            fingers.append(finger)
            c_finger_name = c_prefix + fname + str(i) + _side
            c_fingers_names.append(c_finger_name)
            c_finger = create_edit_bone(c_finger_name)
            copy_bone_transforms(finger, c_finger)
            set_bone_collection(rig, c_finger, coll_ctrl_name)
            c_finger["mixamo_ctrl"] = 1

            if i == 1:
                c_finger.parent = hand
            else:
                prev_finger_name = c_prefix + fname + str(i - 1) + _side
                prev_finger = get_edit_bone(prev_finger_name)
                c_finger.parent = prev_finger

    # Finger leaves/tip bones
    for fname in fingers_type:
        finger_name = get_mix_name(side + "Hand" + fname + "4", use_name_prefix)
        finger_leaf = get_edit_bone(finger_name)
        finger_leaves.append(finger_leaf)

    # Set Mixamo bones in DEF collection
    for b in [shoulder, arm, forearm, hand] + fingers + finger_leaves:
        set_bone_collection(rig, b, coll_mix_name)

    # Shoulder Ctrl
    c_shoulder_name = c_prefix + arm_rig_names["shoulder"] + _side
    c_shoulder = create_edit_bone(c_shoulder_name)
    copy_bone_transforms(shoulder, c_shoulder)
    c_shoulder.parent = get_edit_bone(c_prefix + spine_rig_names["spine3"])
    set_bone_collection(rig, c_shoulder, coll_ctrl_name)
    c_shoulder["mixamo_ctrl"] = 1

    # Arm IK
    arm_ik_name = arm_rig_names["arm_ik"] + _side
    arm_ik = create_edit_bone(arm_ik_name)
    copy_bone_transforms(arm, arm_ik)

    # Correct straight arms angle - need minimum 0.1 degrees for IK constraints
    angle_min = 0.1

    def get_arm_angle():
        vec1 = forearm.head - arm.head
        vec2 = hand.head - forearm.head
        return degrees(vec1.angle(vec2))

    arm_angle = get_arm_angle()

    if arm_angle < angle_min:
        print("    ! Straight arm bones, angle = " + str(arm_angle))
        max_iter = 10000
        i = 0

        while arm_angle < angle_min and i < max_iter:
            dir = ((arm.x_axis + forearm.x_axis) * 0.5).normalized()
            if side == "Right":
                dir *= -1

            forearm.head += dir * (forearm.tail - forearm.head).magnitude * 0.0001
            arm_angle = get_arm_angle()
            i += 1

        print("      corrected arm angle: " + str(arm_angle))

    # Auto-align elbow position with global Y axis for IK pole vector
    arm_axis = forearm.tail - arm.head
    arm_midpoint = (arm.head + forearm.tail) * 0.5

    dir = forearm.head - arm_midpoint
    cur_vec = project_vector_onto_plane(dir, arm_axis)
    global_y_vec = project_vector_onto_plane(Vector((0, 1, 0)), arm_axis)
    signed_cur_angle = signed_angle(cur_vec, global_y_vec, arm_axis)
    print("    IK correc angle:", degrees(signed_cur_angle))

    # Rotate
    rotated_point = rotate_point(forearm.head.copy(), -signed_cur_angle, arm_midpoint, arm_axis)

    # Check
    dir = rotated_point - arm_midpoint
    cur_vec = project_vector_onto_plane(dir, arm_axis)
    signed_cur_angle = signed_angle(cur_vec, global_y_vec, arm_axis)
    print("    IK corrected angle:", degrees(signed_cur_angle))

    arm_ik.tail = rotated_point
    arm_ik.parent = c_shoulder
    set_bone_collection(rig, arm_ik, coll_intern_name)

    # Arm FK Ctrl
    c_arm_fk_name = c_prefix + arm_rig_names["arm_fk"] + _side
    c_arm_fk = create_edit_bone(c_arm_fk_name)
    c_arm_fk.parent = get_edit_bone(c_prefix + spine_rig_names["spine3"])
    copy_bone_transforms(arm_ik, c_arm_fk)
    set_bone_collection(rig, c_arm_fk, coll_ctrl_name)
    c_arm_fk["mixamo_ctrl"] = 1

    # ForeArm IK
    forearm_ik_name = arm_rig_names["forearm_ik"] + _side
    forearm_ik = create_edit_bone(forearm_ik_name)
    copy_bone_transforms(forearm, forearm_ik)
    forearm_ik.head = arm_ik.tail.copy()
    forearm_ik.tail = hand.head.copy()
    forearm_ik.parent = arm_ik
    set_bone_collection(rig, forearm_ik, coll_intern_name)

    # Align arm and forearm IK roll
    align_bone_x_axis(forearm_ik, (forearm_ik.head - arm_midpoint))
    align_bone_x_axis(arm_ik, forearm_ik.x_axis)
    copy_bone_transforms(arm_ik, c_arm_fk)

    if side == "Right":
        forearm_ik.roll += radians(180)
        arm_ik.roll += radians(180)
        c_arm_fk.roll += radians(180)

    # Forearm FK Ctrl
    c_forearm_fk_name = c_prefix + arm_rig_names["forearm_fk"] + _side
    c_forearm_fk = create_edit_bone(c_forearm_fk_name)
    copy_bone_transforms(forearm_ik, c_forearm_fk)
    c_forearm_fk.parent = c_arm_fk
    set_bone_collection(rig, c_forearm_fk, coll_ctrl_name)
    c_forearm_fk["mixamo_ctrl"] = 1

    # Pole IK Ctrl
    c_pole_ik_name = c_prefix + arm_rig_names["pole_ik"] + _side
    c_pole_ik = create_edit_bone(c_pole_ik_name)
    set_bone_collection(rig, c_pole_ik, coll_ctrl_name)
    c_pole_ik["mixamo_ctrl"] = 1

    arm_midpoint = (arm_ik.head + forearm_ik.tail) * 0.5

    plane_normal = (arm_ik.head - forearm_ik.tail)
    prepole_dir = forearm_ik.head - arm_midpoint
    pole_pos = forearm_ik.head + prepole_dir.normalized()
    pole_pos = project_point_onto_plane(pole_pos, forearm_ik.head, plane_normal)
    pole_pos = forearm_ik.head + ((pole_pos - forearm_ik.head).normalized() * (forearm_ik.head - arm.head).magnitude * 1.0)

    c_pole_ik.head = pole_pos
    c_pole_ik.tail = [c_pole_ik.head[0], c_pole_ik.head[1], c_pole_ik.head[2] + (0.165 * arm_ik.length * 4)]

    ik_pole_angle = get_pole_angle(arm_ik, forearm_ik, c_pole_ik.head)

    # Hand IK Ctrl
    c_hand_ik_name = c_prefix + arm_rig_names["hand_ik"] + _side
    c_hand_ik = create_edit_bone(c_hand_ik_name)
    set_bone_collection(rig, c_hand_ik, coll_ctrl_name)
    copy_bone_transforms(hand, c_hand_ik)
    c_hand_ik["mixamo_ctrl"] = 1

    # Hand FK Ctrl
    c_hand_fk_name = c_prefix + arm_rig_names["hand_fk"] + _side
    c_hand_fk = create_edit_bone(c_hand_fk_name)
    copy_bone_transforms(hand, c_hand_fk)
    c_hand_fk.parent = c_forearm_fk
    set_bone_collection(rig, c_hand_fk, coll_ctrl_name)
    c_hand_fk["mixamo_ctrl"] = 1

    # -- Pose Mode --
    bpy.ops.object.mode_set(mode='POSE')

    # Setup constraints
    _setup_arm_constraints(
        self, rig, side, _side,
        shoulder_name, arm_name, forearm_name, hand_name,
        arm_ik_name, forearm_ik_name,
        c_shoulder_name, c_arm_fk_name, c_forearm_fk_name,
        c_pole_ik_name, c_hand_ik_name, c_hand_fk_name,
        c_master_name, fingers_names, c_fingers_names
    )


def _setup_arm_constraints(
    self, rig, side, _side,
    shoulder_name, arm_name, forearm_name, hand_name,
    arm_ik_name, forearm_ik_name,
    c_shoulder_name, c_arm_fk_name, c_forearm_fk_name,
    c_pole_ik_name, c_hand_ik_name, c_hand_fk_name,
    c_master_name, fingers_names, c_fingers_names
):
    """Setup all constraints for arm bones."""
    
    c_shoulder_pb = get_pose_bone(c_shoulder_name)
    shoulder_pb = get_pose_bone(shoulder_name)
    c_arm_fk_pb = get_pose_bone(c_arm_fk_name)
    forearm_ik_pb = get_pose_bone(forearm_ik_name)
    c_pole_ik_pb = get_pose_bone(c_pole_ik_name)
    c_hand_ik_pb = get_pose_bone(c_hand_ik_name)

    # Arm FK Ctrl - Copy Location from shoulder
    cns_name = "Copy Location"
    cns = c_arm_fk_pb.constraints.get(cns_name)
    if cns is None:
        cns = c_arm_fk_pb.constraints.new("COPY_LOCATION")
        cns.name = cns_name
    cns.head_tail = 1.0
    cns.target = rig
    cns.subtarget = c_shoulder_name

    # Forearm IK constraint
    cns_name = "IK"
    ik_cns = forearm_ik_pb.constraints.get(cns_name)
    if ik_cns is None:
        ik_cns = forearm_ik_pb.constraints.new("IK")
        ik_cns.name = cns_name
    ik_cns.target = rig
    ik_cns.subtarget = c_hand_ik_name
    ik_cns.pole_target = rig
    ik_cns.pole_subtarget = c_pole_ik_name
    ik_cns.pole_angle = 0.0
    if side == "Right":
        ik_cns.pole_angle = radians(180)
    ik_cns.chain_count = 2
    ik_cns.use_tail = True
    ik_cns.use_stretch = False

    forearm_ik_pb.lock_ik_y = True
    forearm_ik_pb.lock_ik_x = True

    # Pole IK Ctrl - Child Of
    cns_name = "Child Of"
    cns = c_pole_ik_pb.constraints.get(cns_name)
    if cns is None:
        cns = c_pole_ik_pb.constraints.new("CHILD_OF")
        cns.name = cns_name
    cns.target = rig
    cns.subtarget = c_prefix + spine_rig_names["pelvis"]

    # Hand IK Ctrl - Child Of
    cns_name = "Child Of"
    cns = c_hand_ik_pb.constraints.get(cns_name)
    if cns is None:
        cns = c_hand_ik_pb.constraints.new("CHILD_OF")
        cns.name = cns_name
    cns.target = rig
    cns.subtarget = c_master_name

    # Mixamo bone constraints
    hand_pb = get_pose_bone(hand_name)

    # Finger constraints
    for i, fname in enumerate(c_fingers_names):
        c_finger_pb = get_pose_bone(fname)
        finger_pb = get_pose_bone(fingers_names[i])
        add_copy_transf(finger_pb, rig, c_finger_pb.name)

    # Shoulder constraint
    add_copy_transf(shoulder_pb, rig, c_shoulder_pb.name)

    # IK-FK switch property
    if "ik_fk_switch" not in c_hand_ik_pb.keys():
        create_custom_prop(node=c_hand_ik_pb, prop_name="ik_fk_switch", prop_val=0.0, prop_min=0.0, prop_max=1.0, prop_description="IK-FK switch value")

    c_hand_ik_pb["ik_fk_switch"] = 0.0 if self.ik_arms else 1.0

    # Arm constraints
    arm_pb = get_pose_bone(arm_name)

    cns_ik_name = "IK_follow"
    cns_ik = arm_pb.constraints.get(cns_ik_name)
    if cns_ik is None:
        cns_ik = arm_pb.constraints.new("COPY_TRANSFORMS")
        cns_ik.name = cns_ik_name
    cns_ik.target = rig
    cns_ik.subtarget = arm_ik_name
    cns_ik.influence = 1.0

    cns_fk_name = "FK_Follow"
    cns_fk = arm_pb.constraints.get(cns_fk_name)
    if cns_fk is None:
        cns_fk = arm_pb.constraints.new("COPY_TRANSFORMS")
        cns_fk.name = cns_fk_name
    cns_fk.target = rig
    cns_fk.subtarget = c_arm_fk_name
    cns_fk.influence = 0.0

    add_driver_to_prop(rig, 'pose.bones["' + arm_name + '"].constraints["' + cns_fk_name + '"].influence', 'pose.bones["' + c_hand_ik_name + '"]["ik_fk_switch"]', array_idx=-1, exp="var")

    # ForeArm constraints
    forearm_pb = get_pose_bone(forearm_name)

    cns_ik_name = "IK_follow"
    cns_ik = forearm_pb.constraints.get(cns_ik_name)
    if cns_ik is None:
        cns_ik = forearm_pb.constraints.new("COPY_TRANSFORMS")
        cns_ik.name = cns_ik_name
    cns_ik.target = rig
    cns_ik.subtarget = forearm_ik_name
    cns_ik.influence = 1.0

    cns_fk_name = "FK_Follow"
    cns_fk = forearm_pb.constraints.get(cns_fk_name)
    if cns_fk is None:
        cns_fk = forearm_pb.constraints.new("COPY_TRANSFORMS")
        cns_fk.name = cns_fk_name
    cns_fk.target = rig
    cns_fk.subtarget = c_forearm_fk_name
    cns_fk.influence = 0.0

    add_driver_to_prop(rig, 'pose.bones["' + forearm_name + '"].constraints["' + cns_fk_name + '"].influence', 'pose.bones["' + c_hand_ik_name + '"]["ik_fk_switch"]', array_idx=-1, exp="var")

    c_arm_fk_pb = get_pose_bone(c_arm_fk_name)
    c_forearm_fk_pb = get_pose_bone(c_forearm_fk_name)

    lock_pbone_transform(c_forearm_fk_pb, "location", [0, 1, 2])

    # Hand constraints
    cns_ik_name = "IK_follow"
    cns_ik = hand_pb.constraints.get(cns_ik_name)
    if cns_ik is None:
        cns_ik = hand_pb.constraints.new("COPY_ROTATION")
        cns_ik.name = cns_ik_name
    cns_ik.target = rig
    cns_ik.subtarget = c_hand_ik_name
    cns_ik.influence = 1.0

    cns_fk_name = "FK_Follow"
    cns_fk = hand_pb.constraints.get(cns_fk_name)
    if cns_fk is None:
        cns_fk = hand_pb.constraints.new("COPY_ROTATION")
        cns_fk.name = cns_fk_name
    cns_fk.target = rig
    cns_fk.subtarget = c_hand_fk_name
    cns_fk.influence = 0.0

    add_driver_to_prop(rig, 'pose.bones["' + hand_name + '"].constraints["' + cns_fk_name + '"].influence', 'pose.bones["' + c_hand_ik_name + '"]["ik_fk_switch"]', array_idx=-1, exp="var")

    c_hand_fk_pb = get_pose_bone(c_hand_fk_name)
    lock_pbone_transform(c_hand_fk_pb, "location", [0, 1, 2])

    # Set custom shapes
    c_hand_ik_pb = get_pose_bone(c_hand_ik_name)
    set_bone_custom_shape(c_shoulder_pb, "cs_shoulder_" + side.lower())
    set_bone_custom_shape(c_arm_fk_pb, "cs_arm_fk")
    set_bone_custom_shape(c_forearm_fk_pb, "cs_forearm_fk")
    set_bone_custom_shape(c_pole_ik_pb, "cs_sphere_012")
    set_bone_custom_shape(c_hand_fk_pb, "cs_hand")
    set_bone_custom_shape(c_hand_ik_pb, "cs_hand")

    c_fingers_pb = []
    for fname in c_fingers_names:
        finger_pb = get_pose_bone(fname)
        c_fingers_pb.append(finger_pb)
        set_bone_custom_shape(finger_pb, "cs_circle_025")

    c_pbones_list = [c_shoulder_pb, c_arm_fk_pb, c_forearm_fk_pb, c_pole_ik_pb, c_hand_fk_pb, c_hand_ik_pb] + c_fingers_pb

    # Set custom shape drivers - Blender 5.0 always uses xyz array
    ik_controls_names = [c_pole_ik_name, c_hand_ik_name]
    arr_ids = [0, 1, 2]

    for n in ik_controls_names:
        dr_dp = 'pose.bones["' + n + '"].' + get_custom_shape_scale_prop_name()
        tar_dp = 'pose.bones["' + c_hand_ik_name + '"]["ik_fk_switch"]'
        for arr_id in arr_ids:
            add_driver_to_prop(rig, dr_dp, tar_dp, array_idx=arr_id, exp="1-var")

    fk_controls_names = [c_arm_fk_name, c_forearm_fk_name, c_hand_fk_name]

    for n in fk_controls_names:
        dr_dp = 'pose.bones["' + n + '"].' + get_custom_shape_scale_prop_name()
        tar_dp = 'pose.bones["' + c_hand_ik_name + '"]["ik_fk_switch"]'
        for arr_id in arr_ids:
            add_driver_to_prop(rig, dr_dp, tar_dp, array_idx=arr_id, exp="var")

    # Set rotation mode and color group
    for pb in c_pbones_list:
        pb.rotation_mode = "XYZ"
        set_bone_color_group(rig, pb, "body" + _side.lower())
