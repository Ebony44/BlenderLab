# Mixamo Rig 5 - Head Bone Creation
# Creates the head and neck control bones

import bpy
from ..utils import *
from ..define import *


def add_head(rig, use_name_prefix, coll_ctrl_name, coll_mix_name):
    """Add head and neck control bones to the rig.
    
    Args:
        rig: The armature object
        use_name_prefix: Whether to use Mixamo naming prefix
        coll_ctrl_name: Name of the control bone collection
        coll_mix_name: Name of the mixamo bone collection
    """
    print("  Add Head")

    # -- Edit Mode --
    bpy.ops.object.mode_set(mode='EDIT')

    # Get Mixamo bone names
    neck_name = get_mix_name(head_names["neck"], use_name_prefix)
    head_name = get_mix_name(head_names["head"], use_name_prefix)
    head_end_name = get_mix_name(head_names["head_end"], use_name_prefix)

    neck = get_edit_bone(neck_name)
    head = get_edit_bone(head_name)
    head_end = get_edit_bone(head_end_name)

    if not neck or not head:
        print("  Head or neck bones are missing, skip head")
        return

    # Set Mixamo bones to DEF collection
    for b in [neck, head, head_end]:
        set_bone_collection(rig, b, coll_mix_name)

    # Neck Ctrl
    c_neck_name = c_prefix + head_rig_names["neck"]
    c_neck = create_edit_bone(c_neck_name)
    copy_bone_transforms(neck, c_neck)
    c_neck.parent = get_edit_bone(c_prefix + spine_rig_names["spine3"])
    set_bone_collection(rig, c_neck, coll_ctrl_name)
    c_neck["mixamo_ctrl"] = 1  # tag as controller bone

    # Head Ctrl
    c_head_name = c_prefix + head_rig_names["head"]
    c_head = create_edit_bone(c_head_name)
    copy_bone_transforms(head, c_head)
    c_head.parent = c_neck
    set_bone_collection(rig, c_head, coll_ctrl_name)
    c_head["mixamo_ctrl"] = 1  # tag as controller bone

    # -- Pose Mode --
    bpy.ops.object.mode_set(mode='POSE')

    c_neck_pb = get_pose_bone(c_neck_name)
    c_head_pb = get_pose_bone(c_head_name)

    # Set custom shapes
    set_bone_custom_shape(c_neck_pb, "cs_neck")
    set_bone_custom_shape(c_head_pb, "cs_head")

    # Set rotation mode
    c_neck_pb.rotation_mode = "XYZ"
    c_head_pb.rotation_mode = "XYZ"

    # Set color group
    set_bone_color_group(rig, c_neck_pb, "neck")
    set_bone_color_group(rig, c_head_pb, "head")

    # Constraints
    neck_pb = get_pose_bone(neck_name)
    head_pb = get_pose_bone(head_name)

    add_copy_transf(neck_pb, rig, c_neck_name)
    add_copy_transf(head_pb, rig, c_head_name)
