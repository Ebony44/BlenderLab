# Mixamo Rig 5 - Rig Builder
# Main orchestrator for control rig creation

import bpy
from ..utils import *
from ..define import *

from .rig_master import add_master
from .rig_spine import add_spine
from .rig_head import add_head
from .rig_arm import add_arm
from .rig_leg import add_leg
from .rig_helpers import init_armature_transforms, clean_scene


def make_rig(self):
    """Build the complete control rig from a Mixamo skeleton.
    
    Args:
        self: The operator instance with properties:
            - ik_arms: Whether to use IK for arms
            - ik_legs: Whether to use IK for legs
    """
    print("\nBuilding control rig...")

    scn = bpy.context.scene
    rig_name = bpy.context.active_object.name
    rig = get_object(rig_name)

    # Bone collection names
    coll_mix_name = "DEF"
    coll_ctrl_name = "CTRL"
    coll_intern_name = "MCH"

    use_name_prefix = True

    c_master_name = c_prefix + master_rig_names["master"]

    # Initialize transforms
    init_armature_transforms(rig)

    # Build rig components
    add_master(rig, c_master_name, coll_ctrl_name)
    
    add_spine(rig, use_name_prefix, c_master_name, coll_ctrl_name, coll_mix_name, coll_intern_name)
    
    add_head(rig, use_name_prefix, coll_ctrl_name, coll_mix_name)
    
    add_arm(self, rig, "Left", use_name_prefix, c_master_name, coll_ctrl_name, coll_mix_name, coll_intern_name)
    add_arm(self, rig, "Right", use_name_prefix, c_master_name, coll_ctrl_name, coll_mix_name, coll_intern_name)
    
    add_leg(self, rig, "Left", use_name_prefix, c_master_name, coll_ctrl_name, coll_mix_name, coll_intern_name)
    add_leg(self, rig, "Right", use_name_prefix, c_master_name, coll_ctrl_name, coll_mix_name, coll_intern_name)

    # Tag the armature with a custom prop to specify the control rig is built
    rig.data["mr_control_rig"] = True

    # Set armature display: bones occluded by mesh (not X-Ray/In Front)
    rig.show_in_front = False

    print("Control rig built successfully.")