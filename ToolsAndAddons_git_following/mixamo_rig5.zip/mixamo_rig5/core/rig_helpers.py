# Mixamo Rig 5 - Rig Helper Functions
# Contains utility functions for rig updates and maintenance

import bpy
from ..utils import *
from ..define import *


def reset_inverse_constraints():
    """Reset inverse matrices for all Child Of constraints."""
    bpy.ops.object.mode_set(mode='POSE')

    rig_name = bpy.context.active_object.name
    rig = get_object(rig_name)

    for pb in rig.pose.bones:
        if len(pb.constraints):
            for cns in pb.constraints:
                if cns.type == 'CHILD_OF':
                    set_constraint_inverse_matrix(cns)

    bpy.ops.object.mode_set(mode='OBJECT')


def update_rig(self):
    """Update old control rig to current version."""
    if blender_version._float >= 300:
        convert_drivers_cs_to_xyz(bpy.context.active_object)


def convert_drivers_cs_to_xyz(armature):
    """Convert custom shape scale drivers from uniform to xyz array format.
    
    This function updates drivers that target 'custom_shape_scale' 
    to use 'custom_shape_scale_xyz' instead, with proper array indices.
    """
    if armature.animation_data is None:
        return
    
    drivers = armature.animation_data.drivers
    
    # Collect drivers to modify
    drivers_to_update = []
    
    for dr in drivers:
        if 'custom_shape_scale' in dr.data_path and 'xyz' not in dr.data_path:
            drivers_to_update.append(dr)
    
    # Remove old drivers and add new ones
    for dr in drivers_to_update:
        # Get driver info
        data_path = dr.data_path
        expression = dr.driver.expression
        
        # Get variables info
        var_info = []
        for var in dr.driver.variables:
            var_data = {
                'name': var.name,
                'type': var.type,
                'targets': []
            }
            for target in var.targets:
                var_data['targets'].append({
                    'id': target.id,
                    'data_path': target.data_path
                })
            var_info.append(var_data)
        
        # Create new data path with xyz
        new_data_path = data_path.replace('custom_shape_scale', 'custom_shape_scale_xyz')
        
        # Remove old driver
        try:
            armature.driver_remove(data_path)
        except:
            pass
        
        # Add new drivers for each axis
        for idx in range(3):
            try:
                new_dr = armature.driver_add(new_data_path, idx)
                new_dr.driver.expression = expression
                
                # Restore variables
                for var_d in var_info:
                    new_var = new_dr.driver.variables.new()
                    new_var.name = var_d['name']
                    new_var.type = var_d['type']
                    for i, target_d in enumerate(var_d['targets']):
                        if i < len(new_var.targets):
                            new_var.targets[i].id = target_d['id']
                            new_var.targets[i].data_path = target_d['data_path']
            except:
                pass


def clean_scene():
    """Clean up the scene after rig creation."""
    # Hide cs_grp
    cs_grp = get_object("cs_grp")
    if cs_grp:
        for c in cs_grp.children:
            hide_object(c)
        hide_object(cs_grp)

    # Display only CTRL collection
    for c in bpy.context.active_object.data.collections:
        if c.name in ('CTRL'):
            c.is_visible = True
        else:
            c.is_visible = False


def init_armature_transforms(rig):
    """Initialize armature transforms by applying rotation and scale."""
    bpy.ops.object.mode_set(mode='OBJECT')
    bpy.ops.object.select_all(action='DESELECT')
    set_active_object(rig.name)
    bpy.ops.object.mode_set(mode='OBJECT')

    # First unparent children meshes (init scale messes up children scale)
    child_par_dict = {}
    for child in bpy.data.objects[rig.name].children:
        bone_parent = None
        if child.parent_type == "BONE":
            bone_parent = child.parent_bone
        child_par_dict[child.name] = bone_parent
        child_mat = child.matrix_world.copy()
        child.parent = None
        bpy.context.evaluated_depsgraph_get().update()
        child.matrix_world = child_mat

    # Apply armature transforms
    bpy.ops.object.transform_apply(location=False, rotation=True, scale=True)

    bpy.context.evaluated_depsgraph_get().update()

    # Restore armature children
    for child_name in child_par_dict:
        child = bpy.data.objects.get(child_name)
        child_mat = child.matrix_world.copy()
        child.parent = bpy.data.objects[rig.name]
        if child_par_dict[child_name] is not None:  # bone parent
            child.parent_type = "BONE"
            child.parent_bone = child_par_dict[child_name]

        bpy.context.evaluated_depsgraph_get().update()
        child.matrix_world = child_mat


def remove_retarget_cns(armature):
    """Remove all retarget constraints from the armature."""
    for pb in armature.pose.bones:
        if len(pb.constraints):
            for cns in pb.constraints:
                if cns.name.endswith("_retarget") or cns.name == "temp":
                    pb.constraints.remove(cns)


def remove_temp_objects():
    """Remove all temporary objects created during rig generation."""
    for obj in bpy.data.objects:
        if "mix_to_del" in obj.keys():
            delete_object(obj)
