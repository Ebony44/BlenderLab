# Mixamo Rig 5 - Spine Bone Creation
# Creates the spine control bones (hips, spine, spine1, spine2)

import bpy
from ..utils import *
from ..define import *


def add_spine(rig, use_name_prefix, c_master_name, coll_ctrl_name, coll_mix_name, coll_intern_name):
    """Add spine control bones to the rig.
    
    Args:
        rig: The armature object
        use_name_prefix: Whether to use Mixamo naming prefix
        c_master_name: Name of the master control bone
        coll_ctrl_name: Name of the control bone collection
        coll_mix_name: Name of the mixamo bone collection
        coll_intern_name: Name of the internal/mechanical bone collection
    """
    print("  Add Spine")

    # -- Edit Mode --
    bpy.ops.object.mode_set(mode='EDIT')

    # Get Mixamo bone names
    hips_name = get_mix_name(spine_names["pelvis"], use_name_prefix)
    spine_name = get_mix_name(spine_names["spine1"], use_name_prefix)
    spine1_name = get_mix_name(spine_names["spine2"], use_name_prefix)
    spine2_name = get_mix_name(spine_names["spine3"], use_name_prefix)

    hips = get_edit_bone(hips_name)
    spine = get_edit_bone(spine_name)
    spine1 = get_edit_bone(spine1_name)
    spine2 = get_edit_bone(spine2_name)

    if not hips or not spine or not spine1 or not spine2:
        print("  Spine bones are missing, skip spine")
        return

    # Set Mixamo bones to DEF collection
    for b in [hips, spine, spine1, spine2]:
        set_bone_collection(rig, b, coll_mix_name)

    # Hips Ctrl
    c_hips_name = c_prefix + spine_rig_names["pelvis"]
    c_hips = create_edit_bone(c_hips_name)
    copy_bone_transforms(hips, c_hips)
    c_hips.parent = get_edit_bone(c_master_name)
    set_bone_collection(rig, c_hips, coll_ctrl_name)
    c_hips["mixamo_ctrl"] = 1  # tag as controller bone

    # Free Hips Ctrl
    c_hips_free_name = c_prefix + spine_rig_names["hips_free"]
    c_hips_free = create_edit_bone(c_hips_free_name)
    c_hips_free.head = hips.tail.copy()
    c_hips_free.tail = hips.head.copy()
    align_bone_x_axis(c_hips_free, hips.x_axis)
    c_hips_free["mixamo_ctrl"] = 1  # tag as controller bone

    c_hips_free.parent = c_hips
    set_bone_collection(rig, c_hips_free, coll_ctrl_name)

    # Free Hips helper
    hips_free_h_name = spine_rig_names["hips_free_helper"]
    hips_free_helper = create_edit_bone(hips_free_h_name)
    copy_bone_transforms(hips, hips_free_helper)
    hips_free_helper.parent = c_hips_free
    set_bone_collection(rig, hips_free_helper, coll_intern_name)

    # Spine Ctrl
    c_spine_name = c_prefix + spine_rig_names["spine1"]
    c_spine = create_edit_bone(c_spine_name)
    copy_bone_transforms(spine, c_spine)
    c_spine.parent = c_hips
    set_bone_collection(rig, c_spine, coll_ctrl_name)
    c_spine["mixamo_ctrl"] = 1  # tag as controller bone

    # Spine1 Ctrl
    c_spine1_name = c_prefix + spine_rig_names["spine2"]
    c_spine1 = create_edit_bone(c_spine1_name)
    copy_bone_transforms(spine1, c_spine1)
    c_spine1.parent = c_spine
    set_bone_collection(rig, c_spine1, coll_ctrl_name)
    c_spine1["mixamo_ctrl"] = 1  # tag as controller bone

    # Spine2 Ctrl
    c_spine2_name = c_prefix + spine_rig_names["spine3"]
    c_spine2 = create_edit_bone(c_spine2_name)
    copy_bone_transforms(spine2, c_spine2)
    c_spine2.parent = c_spine1
    set_bone_collection(rig, c_spine2, coll_ctrl_name)
    c_spine2["mixamo_ctrl"] = 1  # tag as controller bone

    # -- Pose Mode --
    bpy.ops.object.mode_set(mode='POSE')

    c_hips_pb = get_pose_bone(c_hips_name)
    hips_helper_pb = get_pose_bone(hips_free_h_name)
    c_hips_free_pb = get_pose_bone(c_hips_free_name)
    c_spine_pb = get_pose_bone(c_spine_name)
    c_spine1_pb = get_pose_bone(c_spine1_name)
    c_spine2_pb = get_pose_bone(c_spine2_name)

    # Set custom shapes
    set_bone_custom_shape(c_hips_pb, "cs_square_2")
    set_bone_custom_shape(c_hips_free_pb, "cs_hips")
    set_bone_custom_shape(c_spine_pb, "cs_circle")
    set_bone_custom_shape(c_spine1_pb, "cs_circle")
    set_bone_custom_shape(c_spine2_pb, "cs_circle")

    # Set rotation mode
    c_hips_pb.rotation_mode = "XYZ"
    c_hips_free_pb.rotation_mode = "XYZ"
    c_spine_pb.rotation_mode = "XYZ"
    c_spine1_pb.rotation_mode = "XYZ"
    c_spine2_pb.rotation_mode = "XYZ"

    # Set color group
    set_bone_color_group(rig, c_hips_pb, "root_master")
    set_bone_color_group(rig, c_hips_free_pb, "body_mid")
    set_bone_color_group(rig, c_spine_pb, "body_mid")
    set_bone_color_group(rig, c_spine1_pb, "body_mid")
    set_bone_color_group(rig, c_spine2_pb, "body_mid")

    # Constraints
    # Hips
    mixamo_spine_pb = get_pose_bone(hips_name)
    cns = mixamo_spine_pb.constraints.get("Copy Transforms")
    if cns is None:
        cns = mixamo_spine_pb.constraints.new("COPY_TRANSFORMS")
        cns.name = "Copy Transforms"
    cns.target = rig
    cns.subtarget = hips_free_h_name

    # Spine bones
    spine_bone_matches = {"1": c_spine_name, "2": c_spine1_name, "3": c_spine2_name}
    for str_idx in spine_bone_matches:
        c_name = spine_bone_matches[str_idx]
        mixamo_bname = get_mix_name(spine_names["spine" + str_idx], use_name_prefix)
        mixamo_spine_pb = get_pose_bone(mixamo_bname)
        cns = mixamo_spine_pb.constraints.get("Copy Transforms")
        if cns is None:
            cns = mixamo_spine_pb.constraints.new("COPY_TRANSFORMS")
            cns.name = "Copy Transforms"
        cns.target = rig
        cns.subtarget = c_name
