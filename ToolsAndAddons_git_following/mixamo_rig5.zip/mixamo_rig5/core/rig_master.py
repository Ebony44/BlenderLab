# Mixamo Rig 5 - Master Bone Creation
# Creates the master control bone for the rig

import bpy
from ..utils import *
from ..define import *


def add_master(rig, c_master_name, coll_ctrl_name):
    """Add the master control bone to the rig.
    
    Args:
        rig: The armature object
        c_master_name: Name for the master control bone
        coll_ctrl_name: Name of the control bone collection
    """
    print("  Add Master")

    # -- Edit Mode --
    bpy.ops.object.mode_set(mode='EDIT')

    # Create master bone
    c_master = create_edit_bone(c_master_name)
    c_master.head = [0, 0, 0]
    c_master.tail = [0, 0, 0.05 * rig.dimensions[2]]
    c_master.roll = 0.01
    set_bone_collection(rig, c_master, coll_ctrl_name)
    c_master["mixamo_ctrl"] = 1  # tag as controller bone

    # -- Pose Mode --
    bpy.ops.object.mode_set(mode='POSE')

    c_master_pb = get_pose_bone(c_master_name)

    # Set custom shapes
    set_bone_custom_shape(c_master_pb, "cs_master")

    # Set rotation mode
    c_master_pb.rotation_mode = "XYZ"

    # Set color group
    set_bone_color_group(rig, c_master_pb, "master")
