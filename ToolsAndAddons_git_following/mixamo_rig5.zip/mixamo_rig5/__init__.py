# Mixamo Rig 5 - Control Rig Generator for Blender 5.0
# Creates control rigs for Mixamo characters with IK/FK switching

bl_info = {
    "name": "Mixamo Rig 5",
    "author": "Mixanimo Team (The original version was developed by Adobe)",
    "version": (5, 0, 0),
    "blender": (5, 0, 0),
    "location": "3D View > UI > Mixamo",
    "description": "Generate control rigs for Mixamo characters. Blender 5.0+ exclusive.",
    "doc_url": "",
    "category": "Animation",
}

import bpy

# Module imports
from . import mixamo_rig_prefs
from . import mixamo_rig_functions
from .panels import classes as panel_classes, update_mixamo_tab
from .operators import classes as operator_classes


def register():
    from bpy.utils import register_class
    
    # Register preferences
    mixamo_rig_prefs.register()
    
    # Register operators
    for cls in operator_classes:
        register_class(cls)
    
    # Register panels
    for cls in panel_classes:
        register_class(cls)
    
    # Register mixamo_rig_functions (IK/FK snapping operators and rig settings panel)
    mixamo_rig_functions.register()
    
    # Update tab names
    update_mixamo_tab()
    
    # Scene properties
    bpy.types.Scene.mix_source_armature = bpy.props.PointerProperty(
        type=bpy.types.Object,
        name="Source Armature",
        description="Source armature for animation import",
        poll=lambda self, obj: obj.type == 'ARMATURE'
    )


def unregister():
    from bpy.utils import unregister_class
    
    # Unregister scene properties
    del bpy.types.Scene.mix_source_armature
    
    # Unregister mixamo_rig_functions
    mixamo_rig_functions.unregister()
    
    # Unregister panels
    for cls in reversed(panel_classes):
        unregister_class(cls)
    
    # Unregister operators
    for cls in reversed(operator_classes):
        unregister_class(cls)
    
    # Unregister preferences
    mixamo_rig_prefs.unregister()


if __name__ == "__main__":
    register()
