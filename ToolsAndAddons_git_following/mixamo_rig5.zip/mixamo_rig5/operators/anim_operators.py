# Mixamo Rig 5 - Animation Operators
# Operators for baking and importing animations

import bpy
from ..utils import *
from ..define import *
from ..core.rig_helpers import remove_retarget_cns, remove_temp_objects


class MR_OT_bake_anim(bpy.types.Operator):
    """Merge all animation layers (see NLA editor) into a single layer"""

    bl_idname = "mr.bake_anim"
    bl_label = "bake_anim"
    bl_options = {'UNDO'}

    @classmethod
    def poll(cls, context):
        if context.active_object:
            return context.active_object.type == "ARMATURE"
        return False

    def execute(self, context):
        try:
            bake_nla_anim(self)
        finally:
            pass

        return {'FINISHED'}


class MR_OT_import_anim(bpy.types.Operator):
    """Import an animation file (FBX) of the same character to the control rig"""

    bl_idname = "mr.import_anim_to_rig"
    bl_label = "import_anim_to_rig"
    bl_options = {'UNDO'}

    @classmethod
    def poll(cls, context):
        if context.active_object:
            if context.active_object.type == "ARMATURE":
                if "mr_control_rig" in context.active_object.data.keys():
                    return True
        return False

    def execute(self, context):
        from ..animation import import_anim
        
        scn = bpy.context.scene
        debug = False
        layer_select = []

        if scn.mix_source_armature is None:
            self.report({'ERROR'}, "Source armature must be set")
            return {'FINISHED'}

        try:
            layer_select = enable_all_armature_layers()
            tar_arm = get_object(bpy.context.active_object.name)
            src_arm = scn.mix_source_armature
            print("Source", src_arm.name)
            print("Target", tar_arm.name)

            import_anim(src_arm, tar_arm, import_only=True)

            # Assign action slot for Blender 5.0
            if tar_arm.animation_data and tar_arm.animation_data.action:
                if tar_arm.animation_data.action.slots:
                    tar_arm.animation_data.action_slot = tar_arm.animation_data.action.slots[0]

        finally:
            if not debug:
                restore_armature_layers(layer_select)
                remove_retarget_cns(bpy.context.active_object)

                if scn.mix_source_armature:
                    try:
                        remove_retarget_cns(scn.mix_source_armature)
                    except:
                        pass

                remove_temp_objects()

            self.report({"INFO"}, "Animation imported")

        return {'FINISHED'}


def bake_nla_anim(self):
    """Bake NLA tracks into a single action."""
    scn = bpy.context.scene
    rig = bpy.context.active_object

    if rig.animation_data is None:
        print("No animation data, exit bake")
        return

    if rig.animation_data.nla_tracks is None:
        print("No NLA tracks found, exit bake")
        return

    tracks = rig.animation_data.nla_tracks

    fs = None
    fe = None

    # Get frame range from NLA tracks
    for track in tracks:
        for strip in track.strips:
            if fs is None:
                fs = strip.frame_start
            if fe is None:
                fe = strip.frame_end

            if strip.frame_start < fs:
                fs = strip.frame_start
            if strip.frame_end > fe:
                fe = strip.frame_end

    if fs is None or fe is None:
        print("No NLA tracks found, exit")
        return

    # Get active action frame range
    act = rig.animation_data.action
    if act is not None:
        if act.frame_range[0] < fs:
            fs = act.frame_range[0]
        if act.frame_range[1] > fe:
            fe = act.frame_range[1]

    # Select only controller bones - collect names first
    bones_to_select = []
    
    for pbone in rig.pose.bones:
        if "mixamo_ctrl" in pbone.bone.keys():
            bones_to_select.append(pbone.name)

    if not bones_to_select:
        # Backward compatibility - use CTRL collection instead
        print("Ctrl bones not tagged, search in CTRL collection instead...")
        c0 = rig.data.collections.get("CTRL")
        if c0 is not None:
            for b in c0.bones:
                bones_to_select.append(b.name)

    # Blender 5.0: Select bones using Edit Mode (Bone.select removed from data block)
    bpy.ops.object.mode_set(mode='EDIT')
    bpy.ops.armature.select_all(action='DESELECT')
    
    for bone_name in bones_to_select:
        ebone = rig.data.edit_bones.get(bone_name)
        if ebone:
            ebone.select = True
            ebone.select_head = True
            ebone.select_tail = True
    
    # Switch back to Pose Mode (selection transfers)
    bpy.ops.object.mode_set(mode='POSE')

    fs, fe = int(fs), int(fe)

    scn.frame_set(fs)
    bpy.context.view_layer.update()

    # Bake NLA strips
    print("Baking, frame start:", fs, ",frame end", fe)
    try:
        bpy.ops.nla.bake(
            frame_start=fs,
            frame_end=fe,
            step=1,
            only_selected=True,
            visual_keying=False,
            clear_constraints=False,
            clear_parents=False,
            use_current_action=False,
            clean_curves=False,
            bake_types={'POSE'}
        )
    except TypeError as e:
        # Fallback for API changes - try with minimal parameters
        print(f"NLA bake warning: {e}, trying minimal parameters...")
        bpy.ops.nla.bake(
            frame_start=fs,
            frame_end=fe,
            only_selected=True,
            bake_types={'POSE'}
        )

    # Remove tracks
    while len(tracks):
        rig.animation_data.nla_tracks.remove(tracks[0])