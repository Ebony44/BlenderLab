# Mixamo Rig 5 - Export Operators
# Operators for exporting rigs and animations

import bpy


class MR_OT_export_gltf(bpy.types.Operator):
    """Export to GLTF format"""

    bl_idname = "mr.export_gltf"
    bl_label = "export_gltf"
    bl_options = {'UNDO'}

    @classmethod
    def poll(cls, context):
        if context.active_object:
            if context.active_object.type == "ARMATURE":
                return True

    def execute(self, context):
        try:
            bpy.ops.export_scene.gltf()
        finally:
            pass

        return {'FINISHED'}
