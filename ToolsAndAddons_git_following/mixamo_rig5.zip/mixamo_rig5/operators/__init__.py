# Mixamo Rig 5 - Operators Module
# Contains all Blender operator classes

from .rig_operators import (
    MR_OT_make_rig,
    MR_OT_zero_out,
    MR_OT_update
)

from .anim_operators import (
    MR_OT_bake_anim,
    MR_OT_import_anim
)

from .shape_operators import (
    MR_OT_edit_custom_shape,
    MR_OT_apply_shape
)

from .export_operators import (
    MR_OT_export_gltf
)

# All operator classes for registration
classes = (
    MR_OT_make_rig,
    MR_OT_zero_out,
    MR_OT_update,
    MR_OT_bake_anim,
    MR_OT_import_anim,
    MR_OT_edit_custom_shape,
    MR_OT_apply_shape,
    MR_OT_export_gltf,
)

__all__ = [
    'MR_OT_make_rig',
    'MR_OT_zero_out',
    'MR_OT_update',
    'MR_OT_bake_anim',
    'MR_OT_import_anim',
    'MR_OT_edit_custom_shape',
    'MR_OT_apply_shape',
    'MR_OT_export_gltf',
    'classes',
]
