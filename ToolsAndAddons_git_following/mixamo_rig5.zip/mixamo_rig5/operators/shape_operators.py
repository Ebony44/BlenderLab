# Mixamo Rig 5 - Shape Operators
# Operators for editing custom bone shapes

import bpy
from ..utils import *
from ..define import *


class MR_OT_edit_custom_shape(bpy.types.Operator):
    """Edit the selected bone shape"""

    bl_idname = "mr.edit_custom_shape"
    bl_label = "edit_custom_shape"
    bl_options = {'UNDO'}

    @classmethod
    def poll(cls, context):
        if context.mode == 'POSE':
            if bpy.context.active_pose_bone:
                return True

    def execute(self, context):
        try:
            cs = bpy.context.active_pose_bone.custom_shape
            if cs:
                edit_custom_shape()
            else:
                self.report({"ERROR"}, "No custom shapes set for this bone.")
        finally:
            pass

        return {'FINISHED'}


class MR_OT_apply_shape(bpy.types.Operator):
    """Apply the selected shape"""

    bl_idname = "mr.apply_shape"
    bl_label = "apply_shape"
    bl_options = {'UNDO'}

    @classmethod
    def poll(cls, context):
        if context.active_object:
            if context.mode == 'EDIT_MESH':
                if 'cs_user' in context.active_object.name:
                    return True

    def execute(self, context):
        use_global_undo = context.preferences.edit.use_global_undo
        context.preferences.edit.use_global_undo = False

        try:
            apply_shape()
        finally:
            context.preferences.edit.use_global_undo = use_global_undo

        return {'FINISHED'}


def edit_custom_shape():
    """Enter edit mode for the selected bone's custom shape."""
    bone = bpy.context.active_pose_bone
    rig_name = bpy.context.active_object.name
    rig = get_object(rig_name)

    cs = bone.custom_shape
    cs_mesh = cs.data

    bpy.ops.object.posemode_toggle()

    # Make sure the active collection is not hidden
    active_collec = bpy.context.layer_collection
    if not active_collec.is_visible:
        for col in rig.users_collection:
            layer_col = search_layer_collection(bpy.context.view_layer.layer_collection, col.name)
            if layer_col.hide_viewport == False and col.hide_viewport == False:
                bpy.context.view_layer.active_layer_collection = layer_col
                break

    # Create new mesh data
    bpy.ops.mesh.primitive_plane_add(
        size=1,
        enter_editmode=False,
        location=(-0, 0, 0.0),
        rotation=(0.0, 0.0, 0.0)
    )

    mesh_obj = bpy.context.active_object
    mesh_obj.name = 'cs_user_' + bone.name

    if cs.name == "cs_user_" + bone.name:
        # Make a mesh instance if it's already edited
        mesh_obj.data = cs_mesh
        mesh_obj['delete'] = 1.0
    else:
        # Create new object data
        mesh_obj.data = cs_mesh.copy()
        mesh_obj.data.name = mesh_obj.name
        bone.custom_shape = mesh_obj

    # Store the current armature name in a custom prop
    mesh_obj['mr_armature'] = rig_name

    if bone.custom_shape_transform:
        bone_transf = bone.custom_shape_transform
        mesh_obj.matrix_world = rig.matrix_world @ bone_transf.matrix
    else:
        mesh_obj.matrix_world = rig.matrix_world @ bone.matrix

    mesh_obj.scale *= get_custom_shape_scale(bone)
    mesh_obj.scale *= bone.length

    bpy.ops.object.mode_set(mode='EDIT')


def apply_shape():
    """Apply the edited custom shape and return to pose mode."""
    bpy.ops.object.mode_set(mode='OBJECT')
    obj = bpy.context.active_object
    obj_name = obj.name
    shape = bpy.data.objects.get(obj_name)
    delete_obj = False

    cs_grp = get_object('cs_grp')
    if cs_grp:
        shape.parent = bpy.data.objects['cs_grp']

    mr_armature_name = None
    mr_armature = None

    if len(shape.keys()) > 0:
        for key in shape.keys():
            if 'delete' in shape.keys():
                delete_obj = True
            if 'mr_armature' in key:
                mr_armature_name = shape['mr_armature']
                mr_armature = bpy.data.objects.get(mr_armature_name)

    if delete_obj:
        bpy.ops.object.delete(use_global=False)
    else:
        # Assign to collection
        if mr_armature:
            if len(mr_armature.users_collection) > 0:
                for collec in mr_armature.users_collection:
                    if len(collec.name.split('_')) == 1:
                        continue
                    if collec.name.split('_')[1] == "rig" or collec.name.split('_')[1] == "grp":
                        cs_collec = bpy.data.collections.get(collec.name.split('_')[0] + '_cs')
                        if cs_collec:
                            # Remove from root collection
                            if bpy.context.scene.collection.objects.get(shape.name):
                                bpy.context.scene.collection.objects.unlink(shape)
                            # Remove from other collections
                            for other_collec in shape.users_collection:
                                other_collec.objects.unlink(shape)
                            # Assign to cs collection
                            cs_collec.objects.link(shape)
                            print("assigned to collec", cs_collec.name)
                        else:
                            print("cs collec not found")
                    else:
                        print("rig collec not found")
            else:
                print("Armature has no collection")
        else:
            print("Armature not set")

    # Hide shape
    try:
        hide_object(shape)
    except:
        print("Error, could not hide shape")
        pass

    if mr_armature:
        set_active_object(mr_armature.name)
        bpy.ops.object.mode_set(mode='POSE')
