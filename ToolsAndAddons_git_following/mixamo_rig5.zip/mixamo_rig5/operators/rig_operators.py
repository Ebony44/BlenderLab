# Mixamo Rig 5 - Rig Operators
# Operators for creating and managing the control rig

import bpy
from ..utils import *
from ..define import *
from ..core import make_rig, clean_scene, update_rig
from ..core.rig_helpers import remove_retarget_cns, remove_temp_objects


class MR_OT_make_rig(bpy.types.Operator):
    """Generate a control rig from the selected Mixamo skeleton"""

    bl_idname = "mr.make_rig"
    bl_label = "Create control rig from selected armature"
    bl_options = {'UNDO'}

    bake_anim: bpy.props.BoolProperty(
        name="Bake Anim",
        description="Bake animation to the control bones",
        default=True
    )
    ik_arms: bpy.props.BoolProperty(
        name="IK Hands",
        description="Use IK for arm bones, otherwise use FK (can be toggled later using the rig properties)",
        default=True
    )
    ik_legs: bpy.props.BoolProperty(
        name="IK Legs",
        description="Use IK for leg bones, otherwise use FK (can be toggled later using the rig properties)",
        default=True
    )
    animated_armature = None

    @classmethod
    def poll(cls, context):
        if context.active_object:
            if context.active_object.type == "ARMATURE":
                if "mr_control_rig" not in context.active_object.data.keys():
                    return True
        return False

    def invoke(self, context, event):
        wm = context.window_manager
        return wm.invoke_props_dialog(self, width=450)

    def draw(self, context):
        layout = self.layout
        layout.prop(self, 'bake_anim', text="Apply Animation")
        layout.prop(self, 'ik_arms', text="IK Arms")
        layout.prop(self, 'ik_legs', text="IK Legs")

    def execute(self, context):
        from ..animation import import_anim
        
        debug = False
        layer_select = []

        try:
            # Only select the armature
            arm = get_object(context.active_object.name)
            bpy.ops.object.mode_set(mode='OBJECT')
            bpy.ops.object.select_all(action='DESELECT')
            set_active_object(arm.name)

            # Enable all armature layers
            layer_select = enable_all_armature_layers()

            # Animation import: initial steps
            if self.bake_anim:
                if "mr_control_rig" not in arm.data.keys():
                    # Duplicate current skeleton
                    duplicate_object()
                    copy_name = arm.name + "_TEMPANIM"
                    self.animated_armature = get_object(bpy.context.active_object.name)
                    self.animated_armature.name = copy_name
                    self.animated_armature["mix_to_del"] = True

                    bpy.ops.object.mode_set(mode='OBJECT')
                    bpy.ops.object.select_all(action='DESELECT')
                    set_active_object(arm.name)

            # Set to rest pose, clear animation
            zero_out()

            # Build control rig
            make_rig(self)

            # Animation import: retarget
            if self.bake_anim and self.animated_armature:
                import_anim(self.animated_armature, arm)

                # Assign action slot for Blender 5.0
                if arm.animation_data and arm.animation_data.action:
                    if arm.animation_data.action.slots:
                        arm.animation_data.action_slot = arm.animation_data.action.slots[0]

            # Set KeyingSet
            ks = context.scene.keying_sets_all
            try:
                ks.active = ks["Location & Rotation"]
            except:
                pass

        finally:
            bpy.ops.object.mode_set(mode='OBJECT')
            bpy.ops.object.select_all(action='DESELECT')
            set_active_object(arm.name)

            if not debug:
                restore_armature_layers(layer_select)
                remove_retarget_cns(bpy.context.active_object)
                remove_temp_objects()
                clean_scene()

            self.report({"INFO"}, "Control Rig Done!")

        return {'FINISHED'}


class MR_OT_zero_out(bpy.types.Operator):
    """Delete all keys and set every bones to (0,0,0) rotation"""

    bl_idname = "mr.zero_out"
    bl_label = "zero_out"
    bl_options = {'UNDO'}

    @classmethod
    def poll(cls, context):
        if context.active_object:
            return context.active_object.type == "ARMATURE"
        return False

    def execute(self, context):
        try:
            zero_out()
        finally:
            pass

        return {'FINISHED'}


class MR_OT_update(bpy.types.Operator):
    """Update old control rig to current version"""

    bl_idname = "mr.update"
    bl_label = "update"
    bl_options = {'UNDO'}

    @classmethod
    def poll(cls, context):
        if context.active_object:
            if context.active_object.type == "ARMATURE":
                return "mr_control_rig" in context.active_object.data.keys()

    def execute(self, context):
        try:
            update_rig(self)
        finally:
            pass

        return {'FINISHED'}


def zero_out():
    """Zero out the armature - clear animation and reset pose."""
    print("\nZeroing out...")
    scn = bpy.context.scene
    arm = bpy.data.objects.get(bpy.context.active_object.name)

    print("  Clear anim")
    # Clear animation data - remove the entire action in Blender 5.0
    if arm.animation_data:
        if arm.animation_data.action:
            arm.animation_data.action = None

    print("  Clear pose")
    # Reset pose
    bpy.ops.object.mode_set(mode='POSE')

    for b in arm.pose.bones:
        b.location = [0, 0, 0]
        b.rotation_euler = [0, 0, 0]
        b.rotation_quaternion = [1, 0, 0, 0]
        b.scale = [1, 1, 1]

    print("Zeroed out.")
