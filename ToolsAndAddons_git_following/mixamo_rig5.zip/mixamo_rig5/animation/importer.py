# Mixamo Rig 5 - Animation Importer
# Animation import and retargeting functions

import bpy
from mathutils import Matrix, Vector

from ..utils import (
    get_object, set_active_object, duplicate_object, delete_object,
    get_pose_bone, get_edit_bone, create_edit_bone
)
from ..define import c_prefix, arm_rig_names, leg_rig_names
from ..lib.mixamo import get_mix_name
from ..lib.maths_geo import vec_roll_to_mat3, mat3_to_vec_roll
from ..lib.animation import bake_anim


def import_anim(src_arm, tar_arm, import_only=False):
    """
    Import animation from source armature to control rig.
    
    Args:
        src_arm: Source armature with animation
        tar_arm: Target control rig armature
        import_only: If True, redefine source rest pose first
    """
    print("\nImporting animation...")
    scn = bpy.context.scene

    if src_arm.animation_data is None:
        print("  No action found on the source armature")
        return

    if src_arm.animation_data.action is None:
        print("  No action found on the source armature")
        return

    # Check for keyframes using Blender 5.0 API
    action = src_arm.animation_data.action
    has_fcurves = False
    
    # Check in channelbags (Blender 5.0 slotted actions)
    if action.layers:
        for layer in action.layers:
            for strip in layer.strips:
                for slot in action.slots:
                    cb = strip.channelbag(slot)
                    if cb and len(cb.fcurves) > 0:
                        has_fcurves = True
                        break
    
    # Fallback to legacy API (for imported FBX files)
    if not has_fcurves:
        try:
            if hasattr(action, 'fcurves') and len(action.fcurves) > 0:
                has_fcurves = True
        except (AttributeError, TypeError):
            pass
    
    if not has_fcurves:
        print("  No keyframes to import")
        return

    use_name_prefix = True

    # Redefine source armature rest pose if importing only animation
    if import_only:
        redefine_source_rest_pose(src_arm, tar_arm)

    bpy.ops.object.mode_set(mode='OBJECT')
    bpy.ops.object.select_all(action='DESELECT')
    set_active_object(tar_arm.name)
    bpy.ops.object.mode_set(mode='POSE')

    # Get IK control bones
    c_hand_ik_left_pb = get_pose_bone(c_prefix + arm_rig_names["hand_ik"] + "_Left")
    c_hand_ik_right_pb = get_pose_bone(c_prefix + arm_rig_names["hand_ik"] + "_Right")
    c_foot_ik_left_pb = get_pose_bone(c_prefix + leg_rig_names["foot_ik"] + "_Left")
    c_foot_ik_right_pb = get_pose_bone(c_prefix + leg_rig_names["foot_ik"] + "_Right")

    # Determine IK/FK mode from current ik_fk_switch values
    arm_left_kinematic = "IK" if c_hand_ik_left_pb["ik_fk_switch"] < 0.5 else "FK"
    arm_right_kinematic = "IK" if c_hand_ik_right_pb["ik_fk_switch"] < 0.5 else "FK"
    leg_left_kinematic = "IK" if c_foot_ik_left_pb["ik_fk_switch"] < 0.5 else "FK"
    leg_right_kinematic = "IK" if c_foot_ik_right_pb["ik_fk_switch"] < 0.5 else "FK"

    # Build bones mapping for retargeting
    bones_map = _build_bones_map(
        use_name_prefix,
        arm_left_kinematic, arm_right_kinematic,
        leg_left_kinematic, leg_right_kinematic
    )

    # Work on a source armature duplicate
    bpy.ops.object.mode_set(mode='OBJECT')
    bpy.ops.object.select_all(action='DESELECT')
    set_active_object(src_arm.name)

    duplicate_object()
    src_arm_copy_name = src_arm.name + "_COPY"
    bpy.context.active_object.name = src_arm_copy_name
    src_arm = get_object(src_arm_copy_name)
    src_arm["mix_to_del"] = True

    # Get anim data
    action = src_arm.animation_data.action
    fr_start = int(action.frame_range[0])
    fr_end = int(action.frame_range[1])

    bpy.ops.object.mode_set(mode='OBJECT')
    bpy.ops.object.select_all(action='DESELECT')
    set_active_object(tar_arm.name)

    # Store bones data from target armature
    bpy.ops.object.mode_set(mode='EDIT')

    ctrl_matrices = {}
    ik_bones_data = {}

    kinematics = {
        "HandLeft": ["Hand", arm_left_kinematic, "Left"],
        "HandRight": ["Hand", arm_right_kinematic, "Right"],
        "FootLeft": ["Foot", leg_left_kinematic, "Left"],
        "FootRight": ["Foot", leg_right_kinematic, "Right"]
    }

    for b in kinematics:
        limb_type, kin_mode, side = kinematics[b]
        ctrl_name = c_prefix + limb_type + '_' + kin_mode + '_' + side
        ctrl_ebone = get_edit_bone(ctrl_name)
        mix_bone_name = get_mix_name(side + limb_type, use_name_prefix)

        ctrl_matrices[ctrl_name] = ctrl_ebone.matrix.copy(), mix_bone_name

        # Store corrected IK bones
        if kin_mode == "IK":
            ik_bones = {}
            ik_chain = []

            if limb_type == "Foot":
                ik_chain = ["UpLeg_IK_" + side, "Leg_IK_" + side]
            elif limb_type == "Hand":
                ik_chain = ["Arm_IK_" + side, "ForeArm_IK_" + side]

            ik1 = get_edit_bone(ik_chain[0])
            ik2 = get_edit_bone(ik_chain[1])

            ik_bones["ik1"] = ik1.name, ik1.head.copy(), ik1.tail.copy(), ik1.roll
            ik_bones["ik2"] = ik2.name, ik2.head.copy(), ik2.tail.copy(), ik2.roll
            ik_bones_data[b] = limb_type, side, ik_bones

    # Init source armature rotation and scale
    bpy.ops.object.mode_set(mode='OBJECT')
    bpy.ops.object.select_all(action='DESELECT')
    set_active_object(src_arm.name)

    scale_fac = src_arm.scale[0]
    bpy.ops.object.transform_apply(location=False, rotation=True, scale=True)

    # Scale location keyframes - use Blender 5.0 slotted actions API
    fcurves_to_scale = []
    
    # Get fcurves from channelbags (Blender 5.0)
    if action.layers:
        for layer in action.layers:
            for strip in layer.strips:
                for slot in action.slots:
                    cb = strip.channelbag(slot)
                    if cb:
                        for fc in cb.fcurves:
                            fcurves_to_scale.append(fc)
    
    # Scale location keyframes
    for fc in fcurves_to_scale:
        dp = fc.data_path
        if dp.startswith('pose.bones') and dp.endswith(".location"):
            for k in fc.keyframe_points:
                k.co[1] *= scale_fac

    bpy.ops.object.mode_set(mode='EDIT')

    # Add helper source bones for feet/hands
    for name in ctrl_matrices:
        foot_ebone = create_edit_bone(name)
        foot_ebone.head, foot_ebone.tail = [0, 0, 0], [0, 0, 0.1]
        foot_ebone.matrix = ctrl_matrices[name][0]
        foot_ebone.parent = get_edit_bone(ctrl_matrices[name][1])

    # Add IK bones helpers
    for b in ik_bones_data:
        limb_type, side, ik_bones = ik_bones_data[b]
        for bone_type in ik_bones:
            bname, bhead, btail, broll = ik_bones[bone_type]
            ebone = create_edit_bone(bname)
            ebone.head, ebone.tail, ebone.roll = bhead, btail, broll

    # Set constraints
    bpy.ops.object.mode_set(mode='POSE')

    bake_ik_data = {"src_arm": src_arm}

    for b in ik_bones_data:
        limb_type, side, ik_bones = ik_bones_data[b]
        b1_name = ik_bones["ik1"][0]
        b2_name = ik_bones["ik2"][0]
        b1_pb = get_pose_bone(b1_name)
        b2_pb = get_pose_bone(b2_name)

        chain = []
        if limb_type == "Foot":
            chain = [get_mix_name(side + "UpLeg", use_name_prefix), 
                     get_mix_name(side + "Leg", use_name_prefix)]
            bake_ik_data["Leg" + side] = chain
        elif limb_type == "Hand":
            chain = [get_mix_name(side + "Arm", use_name_prefix), 
                     get_mix_name(side + "ForeArm", use_name_prefix)]
            bake_ik_data["Arm" + side] = chain

        cns = b1_pb.constraints.new("COPY_TRANSFORMS")
        cns.name = "Copy Transforms"
        cns.target = src_arm
        cns.subtarget = chain[0]

        cns = b2_pb.constraints.new("COPY_TRANSFORMS")
        cns.name = "Copy Transforms"
        cns.target = src_arm
        cns.subtarget = chain[1]

    # Retarget using constrained method
    bpy.ops.object.mode_set(mode='OBJECT')
    bpy.ops.object.select_all(action='DESELECT')
    set_active_object(tar_arm.name)
    bpy.ops.object.mode_set(mode='POSE')
    bpy.ops.pose.select_all(action='DESELECT')

    # Collect bones to select for baking
    bones_to_select = []

    # Add retarget constraints
    for src_name in bones_map:
        tar_name = bones_map[src_name]
        src_bone = src_arm.pose.bones.get(src_name)
        tar_bone = tar_arm.pose.bones.get(tar_name)

        if src_bone is None:
            continue
        if tar_bone is None:
            continue

        cns_name = "Copy Rotation_retarget"
        cns = tar_bone.constraints.new('COPY_ROTATION')
        cns.name = cns_name
        cns.target = src_arm
        cns.subtarget = src_name

        if "Hips" in src_name:
            cns_name = "Copy Location_retarget"
            cns = tar_bone.constraints.new('COPY_LOCATION')
            cns.name = cns_name
            cns.target = src_arm
            cns.subtarget = src_name
            cns.owner_space = cns.target_space = "LOCAL"

        # Foot IK, Hand IK
        is_foot_ik = (
            (leg_left_kinematic == "IK" and "Foot_IK_Left" in src_name) or
            (leg_right_kinematic == "IK" and "Foot_IK_Right" in src_name)
        )
        is_hand_ik = (
            (arm_left_kinematic == "IK" and "Hand_IK_Left" in src_name) or
            (arm_right_kinematic == "IK" and "Hand_IK_Right" in src_name)
        )

        if is_foot_ik or is_hand_ik:
            cns_name = "Copy Location_retarget"
            cns = tar_bone.constraints.new('COPY_LOCATION')
            cns.name = cns_name
            cns.target = src_arm
            cns.subtarget = src_name
            cns.target_space = cns.owner_space = "POSE"

            # Add IK poles to selection list
            _side = "_Left" if "Left" in src_name else "_Right"
            ik_pole_name = ""
            if "Hand" in src_name:
                ik_pole_name = c_prefix + arm_rig_names["pole_ik"] + _side
            elif "Foot" in src_name:
                ik_pole_name = c_prefix + leg_rig_names["pole_ik"] + _side

            if ik_pole_name:
                bones_to_select.append(ik_pole_name)

        # Add target bone to selection list
        bones_to_select.append(tar_name)

    # Blender 5.0: Select bones using Edit Mode (Bone.select removed from data block)
    bpy.ops.object.mode_set(mode='EDIT')
    bpy.ops.armature.select_all(action='DESELECT')
    
    for bone_name in bones_to_select:
        ebone = tar_arm.data.edit_bones.get(bone_name)
        if ebone:
            ebone.select = True
            ebone.select_head = True
            ebone.select_tail = True
    
    # Switch back to Pose Mode (selection transfers)
    bpy.ops.object.mode_set(mode='POSE')

    bpy.context.view_layer.update()

    # Bake animation
    bake_anim(
        frame_start=fr_start, 
        frame_end=fr_end, 
        only_selected=True, 
        bake_bones=True, 
        bake_object=False, 
        ik_data=bake_ik_data
    )

    bpy.ops.object.mode_set(mode='OBJECT')
    set_active_object(src_arm.name)
    set_active_object(tar_arm.name)
    print("Animation imported.")


def redefine_source_rest_pose(src_arm, tar_arm):
    """
    Redefine source armature rest pose to match target armature.
    Used when importing animation-only FBX files.
    """
    print("  Redefining source rest pose...")

    scn = bpy.context.scene

    src_arm_loc = src_arm.location.copy()
    src_arm.location = [0, 0, 0]
    fr_range = src_arm.animation_data.action.frame_range
    fr_start = int(fr_range[0])
    fr_end = int(fr_range[1])

    # Duplicate source armature
    bpy.ops.object.mode_set(mode='OBJECT')
    bpy.ops.object.select_all(action='DESELECT')
    set_active_object(src_arm.name)
    bpy.ops.object.mode_set(mode='OBJECT')
    duplicate_object()
    src_arm_dupli = get_object(bpy.context.active_object.name)
    src_arm_dupli["mix_to_del"] = True

    # Store target bones rest transforms
    bpy.ops.object.mode_set(mode='OBJECT')
    bpy.ops.object.select_all(action='DESELECT')
    set_active_object(tar_arm.name)
    bpy.ops.object.mode_set(mode='EDIT')

    rest_bones = {}

    for ebone in tar_arm.data.edit_bones:
        rest_bones[ebone.name] = (
            ebone.head.copy(), 
            ebone.tail.copy(), 
            vec_roll_to_mat3(ebone.y_axis, ebone.roll)
        )

    # Apply source bones rest transforms
    print("  Set rest pose...")
    bpy.ops.object.mode_set(mode='OBJECT')
    bpy.ops.object.select_all(action='DESELECT')
    set_active_object(src_arm.name)
    bpy.ops.object.mode_set(mode='EDIT')

    for bname in rest_bones:
        ebone = get_edit_bone(bname)

        if ebone is None:
            continue

        head, tail, mat3 = rest_bones[bname]
        inv_mat = src_arm.matrix_world.inverted()
        ebone.head = inv_mat @ head
        ebone.tail = inv_mat @ tail
        ebone.roll = mat3_to_vec_roll(inv_mat.to_3x3() @ mat3)

    # Add constraints
    bpy.ops.object.mode_set(mode='POSE')

    for pb in src_arm.pose.bones:
        cns = pb.constraints.new("COPY_TRANSFORMS")
        cns.name = "temp"
        cns.target = src_arm_dupli
        cns.subtarget = pb.name

    # Restore animation
    print("  Restore animation...")
    bake_anim(
        frame_start=fr_start, 
        frame_end=fr_end, 
        only_selected=False, 
        bake_bones=True, 
        bake_object=False
    )

    # Restore location
    src_arm.location = src_arm_loc

    # Delete temp data
    for pb in src_arm.pose.bones:
        if len(pb.constraints):
            cns = pb.constraints.get("temp")
            if cns:
                pb.constraints.remove(cns)

    delete_object(src_arm_dupli)

    print("  Source armature rest pose redefined.")


def _build_bones_map(use_name_prefix, arm_left_kin, arm_right_kin, leg_left_kin, leg_right_kin):
    """Build the bones mapping dictionary for retargeting."""
    bones_map = {}

    # Core bones
    bones_map[get_mix_name("Hips", use_name_prefix)] = c_prefix + "Hips"
    bones_map[get_mix_name("Spine", use_name_prefix)] = c_prefix + "Spine"
    bones_map[get_mix_name("Spine1", use_name_prefix)] = c_prefix + "Spine1"
    bones_map[get_mix_name("Spine2", use_name_prefix)] = c_prefix + "Spine2"
    bones_map[get_mix_name("Neck", use_name_prefix)] = c_prefix + "Neck"
    bones_map[get_mix_name("Head", use_name_prefix)] = c_prefix + "Head"
    bones_map[get_mix_name("LeftShoulder", use_name_prefix)] = c_prefix + "Shoulder_Left"
    bones_map[get_mix_name("RightShoulder", use_name_prefix)] = c_prefix + "Shoulder_Right"

    # Left Arm
    if arm_left_kin == "FK":
        bones_map[get_mix_name("LeftArm", use_name_prefix)] = c_prefix + "Arm_FK_Left"
        bones_map[get_mix_name("LeftForeArm", use_name_prefix)] = c_prefix + "ForeArm_FK_Left"
        bones_map[get_mix_name("LeftHand", use_name_prefix)] = c_prefix + "Hand_FK_Left"
    elif arm_left_kin == "IK":
        bones_map[c_prefix + "Hand_IK_Left"] = c_prefix + "Hand_IK_Left"

    # Right Arm
    if arm_right_kin == "FK":
        bones_map[get_mix_name("RightArm", use_name_prefix)] = c_prefix + "Arm_FK_Right"
        bones_map[get_mix_name("RightForeArm", use_name_prefix)] = c_prefix + "ForeArm_FK_Right"
        bones_map[get_mix_name("RightHand", use_name_prefix)] = c_prefix + "Hand_FK_Right"
    elif arm_right_kin == "IK":
        bones_map[c_prefix + "Hand_IK_Right"] = c_prefix + "Hand_IK_Right"

    # Fingers - Left
    for finger in ["Thumb", "Index", "Middle", "Ring", "Pinky"]:
        for i in [1, 2, 3]:
            src = get_mix_name(f"LeftHand{finger}{i}", use_name_prefix)
            tar = c_prefix + f"{finger}{i}_Left"
            bones_map[src] = tar

    # Fingers - Right
    for finger in ["Thumb", "Index", "Middle", "Ring", "Pinky"]:
        for i in [1, 2, 3]:
            src = get_mix_name(f"RightHand{finger}{i}", use_name_prefix)
            tar = c_prefix + f"{finger}{i}_Right"
            bones_map[src] = tar

    # Left Leg
    if leg_left_kin == "FK":
        bones_map[get_mix_name("LeftUpLeg", use_name_prefix)] = c_prefix + "UpLeg_FK_Left"
        bones_map[get_mix_name("LeftLeg", use_name_prefix)] = c_prefix + "Leg_FK_Left"
        bones_map[c_prefix + "Foot_FK_Left"] = c_prefix + "Foot_FK_Left"
        bones_map[get_mix_name("LeftToeBase", use_name_prefix)] = c_prefix + "Toe_FK_Left"
    elif leg_left_kin == "IK":
        bones_map[c_prefix + "Foot_IK_Left"] = c_prefix + "Foot_IK_Left"
        bones_map[get_mix_name("LeftToeBase", use_name_prefix)] = c_prefix + "Toe_IK_Left"

    # Right Leg
    if leg_right_kin == "FK":
        bones_map[get_mix_name("RightUpLeg", use_name_prefix)] = c_prefix + "UpLeg_FK_Right"
        bones_map[get_mix_name("RightLeg", use_name_prefix)] = c_prefix + "Leg_FK_Right"
        bones_map[c_prefix + "Foot_FK_Right"] = c_prefix + "Foot_FK_Right"
        bones_map[get_mix_name("RightToeBase", use_name_prefix)] = c_prefix + "Toe_FK_Right"
    elif leg_right_kin == "IK":
        bones_map[c_prefix + "Foot_IK_Right"] = c_prefix + "Foot_IK_Right"
        bones_map[get_mix_name("RightToeBase", use_name_prefix)] = c_prefix + "Toe_IK_Right"

    return bones_map