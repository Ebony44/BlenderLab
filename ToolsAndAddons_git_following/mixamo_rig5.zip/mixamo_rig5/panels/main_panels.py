# Mixamo Rig 5 - Main UI Panels
# UI panels for the Mixamo Control Rig addon

import bpy
from bpy.types import Panel


class MixamoRigPanel:
    """Base class for Mixamo Rig panels."""
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "Mixamo"


class MR_PT_MenuMain(Panel, MixamoRigPanel):
    """Main Mixamo Control Rig panel."""
    bl_label = "Mixamo Control Rig"
    bl_idname = "MR_PT_MenuMain"

    def draw(self, context):
        scn = context.scene

        layout = self.layout
        layout.use_property_split = True
        layout.use_property_decorate = False

        arm_name = "None"

        if context.active_object is not None:
            if context.active_object.type == "ARMATURE":
                arm_name = context.active_object.name

        layout.label(text="Character: " + arm_name)


class MR_PT_MenuRig(Panel, MixamoRigPanel):
    """Control Rig creation panel."""
    bl_label = "Control Rig"
    bl_idname = "MR_PT_MenuRig"
    bl_parent_id = "MR_PT_MenuMain"

    def draw(self, context):
        layout = self.layout
        layout.use_property_split = True
        layout.use_property_decorate = False

        obj = context.active_object
        scn = context.scene

        col = layout.column(align=True)
        col.scale_y = 1.3

        col.operator("mr.make_rig", text="Create Control Rig")
        col.operator("mr.zero_out", text="Zero Out Rig")

        col = layout.column(align=True)
        col.separator()

        if bpy.context.mode != 'EDIT_MESH':
            col.operator("mr.edit_custom_shape", text="Edit Control Shape")
        else:
            col.operator("mr.apply_shape", text="Apply Control Shape")


class MR_PT_MenuAnim(Panel, MixamoRigPanel):
    """Animation import and bake panel."""
    bl_label = "Animation"
    bl_idname = "MR_PT_MenuAnim"
    bl_parent_id = "MR_PT_MenuMain"

    def draw(self, context):
        layout = self.layout
        layout.use_property_split = True
        layout.use_property_decorate = False
        scn = context.scene

        col = layout.column(align=True)
        col.scale_y = 1
        col.label(text="Source Skeleton:")
        col.prop_search(scn, "mix_source_armature", scn, "objects", text="")
        col.separator()

        col = layout.column(align=True)
        col.scale_y = 1.3
        col.operator("mr.import_anim_to_rig", text="Apply Animation to Control Rig")

        col = layout.column(align=True)
        col.scale_y = 1.3
        col.operator("mr.bake_anim", text="Bake Animation")


class MR_PT_MenuUpdate(Panel, MixamoRigPanel):
    """Rig update panel."""
    bl_label = "Update"
    bl_idname = "MR_PT_MenuUpdate"
    bl_parent_id = "MR_PT_MenuMain"

    def draw(self, context):
        layout = self.layout
        layout.operator("mr.update", text="Update Control Rig")


class MR_PT_MenuExport(Panel, MixamoRigPanel):
    """Export panel."""
    bl_label = "Export"
    bl_idname = "MR_PT_MenuExport"
    bl_parent_id = "MR_PT_MenuMain"

    def draw(self, context):
        layout = self.layout
        layout.operator('export_scene.gltf', text="GLTF Export...")


def update_mixamo_tab():
    """Update the tab name for all Mixamo panels based on addon preferences."""
    try:
        bpy.utils.unregister_class(MR_PT_MenuMain)
        bpy.utils.unregister_class(MR_PT_MenuRig)
        bpy.utils.unregister_class(MR_PT_MenuAnim)
        bpy.utils.unregister_class(MR_PT_MenuExport)
        bpy.utils.unregister_class(MR_PT_MenuUpdate)
    except:
        pass

    # Get tab name from preferences
    try:
        tab_name = bpy.context.preferences.addons['mixamo_rig5'].preferences.mixamo_tab_name
    except:
        tab_name = "Mixamo"

    MixamoRigPanel.bl_category = tab_name
    
    bpy.utils.register_class(MR_PT_MenuMain)
    bpy.utils.register_class(MR_PT_MenuRig)
    bpy.utils.register_class(MR_PT_MenuAnim)
    bpy.utils.register_class(MR_PT_MenuExport)
    bpy.utils.register_class(MR_PT_MenuUpdate)
