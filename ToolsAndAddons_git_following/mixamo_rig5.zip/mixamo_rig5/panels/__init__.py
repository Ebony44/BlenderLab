# Mixamo Rig 5 - Panels Module
# Contains all Blender UI panel classes

from .main_panels import (
    MixamoRigPanel,
    MR_PT_MenuMain,
    MR_PT_MenuRig,
    MR_PT_MenuAnim,
    MR_PT_MenuExport,
    MR_PT_MenuUpdate,
    update_mixamo_tab,
)

# All panel classes for registration
classes = (
    MR_PT_MenuMain,
    MR_PT_MenuRig,
    MR_PT_MenuAnim,
    MR_PT_MenuExport,
    MR_PT_MenuUpdate,
)

__all__ = [
    'MixamoRigPanel',
    'MR_PT_MenuMain',
    'MR_PT_MenuRig',
    'MR_PT_MenuAnim',
    'MR_PT_MenuExport',
    'MR_PT_MenuUpdate',
    'update_mixamo_tab',
    'classes',
]
