# Mixamo Rig 5 - Definitions Module
# Naming conventions and definitions

from .naming import *
