# Mixamo Rig 5 – Control Rig Generator for Blender 5.0
Updated to Blender 5.0 by the Mixanimo Team  
Contact: mixanimoaddon@gmail.com

Based on:  
https://www.adobe.com/products/substance3d/plugins/mixamo-in-blender.html

---

## Version
- Blender Version: 5.0+
- Addon Version: 5.0.0
- Addon Name: mixamo_rig5

---

## Changes from Blender 3.x Version

This version has been fully updated for Blender 5.0 with the following improvements.

### API Updates
- Slotted Actions: Updated to use Blender 5.0's new slotted actions API with layers, strips, and channelbags
- Removed Legacy Action API: Deprecated action.fcurves no longer used
- Action Slot Assignment: Correct slot assignment after creation
- Custom Shape Scale: Uses custom_shape_scale_xyz (xyz array)
- Custom Properties: Now fully uses id_properties_ui() API
- Bone Collections: Uses Blender's bone collections API (armature layers removed)

### Removed Backward Compatibility
- All version checks for Blender versions earlier than 5.0 removed
- Addon does NOT work with Blender 4.x or earlier

### Modular Structure
The addon is organized into clear modular folders:

- core/ – Rig building logic (master, spine, head, arm, leg)
- operators/ – Blender operators
- panels/ – UI panels
- animation/ – Animation import and retargeting
- lib/ – Utility functions
- definitions/ – Naming conventions

---

## Installation

1. Download the addon as a ZIP file  
2. Open Blender → Edit > Preferences > Add-ons  
3. Click Install... and select the ZIP  
4. Enable Mixamo Rig 5

---

## Important Note
Include the file cs.blend inside the lib/ folder.  
This file contains the custom bone shapes required for the addon.

---

## Usage

1. Import a Mixamo character (FBX format)
2. Select the armature
3. Open View3D > Sidebar > Mixamo
4. Click Create Control Rig

---

## Features

- IK/FK Switching for arms and legs  
- IK/FK Snapping (single frame or entire animation)  
- Animation Import from other Mixamo FBX files  
- Custom Shape Editing inside Blender  
- Foot Roll Controls for advanced leg IK  

---

## License
GPL v2 or later
