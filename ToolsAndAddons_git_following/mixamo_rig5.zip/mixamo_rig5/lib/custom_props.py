import bpy


def get_prop_setting(node, prop_name, setting):
    """Get a custom property setting using Blender 5.0 API."""
    return node.id_properties_ui(prop_name).as_dict()[setting]


def set_prop_setting(node, prop_name, setting, value):
    """Set a custom property setting using Blender 5.0 API."""
    ui_data = node.id_properties_ui(prop_name)
    if setting == 'default':
        ui_data.update(default=value)
    elif setting == 'min':
        ui_data.update(min=value)
    elif setting == 'max':
        ui_data.update(max=value)     
    elif setting == 'soft_min':
        ui_data.update(soft_min=value)
    elif setting == 'soft_max':
        ui_data.update(soft_max=value)
    elif setting == 'description':
        ui_data.update(description=value)


def create_custom_prop(node=None, prop_name="", prop_val=1.0, prop_min=0.0, prop_max=1.0, 
                       prop_description="", soft_min=None, soft_max=None, default=None):
    """Create a custom property with settings using Blender 5.0 API."""
    if soft_min is None:
        soft_min = prop_min
    if soft_max is None:
        soft_max = prop_max
    
    node[prop_name] = prop_val    
    
    if default is None:
        default = prop_val
    
    # Set property settings using Blender 5.0 API
    set_prop_setting(node, prop_name, 'min', prop_min)
    set_prop_setting(node, prop_name, 'max', prop_max)
    set_prop_setting(node, prop_name, 'description', prop_description)
    set_prop_setting(node, prop_name, 'soft_min', soft_min)
    set_prop_setting(node, prop_name, 'soft_max', soft_max)
    set_prop_setting(node, prop_name, 'default', default)
        
    # Set as overridable
    node.property_overridable_library_set('["' + prop_name + '"]', True)
