import bpy

class ARP_blender_version:
    _string = bpy.app.version_string
    blender_v = bpy.app.version
    _float = blender_v[0]*100 + blender_v[1] + blender_v[2]*0.01

blender_version = ARP_blender_version()


def get_custom_shape_scale_prop_name():
    """Returns the custom shape scale property name for Blender 5.0+"""
    return 'custom_shape_scale_xyz'
