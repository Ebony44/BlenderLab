import bpy
from .objects import *


def get_custom_shape_scale(pbone, uniform=True):
    """Get custom shape scale for Blender 5.0+"""
    if uniform:
        # uniform scale - average of xyz
        val = 0
        for i in range(0, 3):
            val += pbone.custom_shape_scale_xyz[i]
        return val / 3
    else:
        # array scale
        return pbone.custom_shape_scale_xyz


def get_selected_pbone_name():
    try:
        return bpy.context.selected_pose_bones[0].name
    except:
        return None


def get_pose_bone(name):
    return bpy.context.active_object.pose.bones.get(name)


def lock_pbone_transform(pbone, type, list):
    for i in list:
        if type == "location":
            pbone.lock_location[i] = True
        elif type == "rotation":
            pbone.lock_rotation[i] = True
        elif type == "scale":
            pbone.lock_scale[i] = True


def set_bone_custom_shape(pbone, cs_name):
    cs = get_object(cs_name)
    if cs is None:
        result = append_cs(cs_name)
        if result is False:
            print(f"WARNING: Could not load custom shape '{cs_name}'. Bone will have no custom shape.")
            return
        cs = get_object(cs_name)

    if cs is not None:
        pbone.custom_shape = cs
    else:
        print(f"WARNING: Custom shape '{cs_name}' not found after append attempt.")


def set_bone_color_group(obj, pb, grp_name):
    """Set bone color using Blender 5.0 bone color API."""
    
    # Professional Rig Color Scheme
    # Left side: Blue (standard convention)
    # Right side: Red (standard convention)
    # Center: Green
    # Master/Root: Yellow/Orange
    
    # Convert RGB 0-255 to 0-1 range
    def rgb(r, g, b):
        return (r / 255.0, g / 255.0, b / 255.0)
    
    # Color definitions
    blue = rgb(50, 220, 255)         # #32dcff - Left side - Blue
    red = rgb(255, 50, 84)           # #ff3254 - Right side - Red
    green = (0.2, 0.8, 0.2)          # Center/Spine - Green
    yellow = (1.0, 0.8, 0.0)         # Master controls - Yellow
    orange = (1.0, 0.5, 0.1)         # Root master - Orange
    purple = rgb(180, 50, 255)       # #b432ff - Head/Neck - Purple
    
    # Color assignments
    grp_color_body_left = blue
    grp_color_body_right = red
    grp_color_body_mid = green
    grp_color_master = yellow
    grp_color_root_master = orange
    grp_color_head = purple
    grp_color_neck = purple

    grp_color = None
    if grp_name == "body_mid":
        grp_color = grp_color_body_mid
    elif grp_name == "body_left":
        grp_color = grp_color_body_left
    elif grp_name == "body_right":
        grp_color = grp_color_body_right
    elif grp_name == "master":
        grp_color = grp_color_master
    elif grp_name == "neck":
        grp_color = grp_color_head
    elif grp_name == "head":
        grp_color = grp_color_neck
    elif grp_name == "root_master":
        grp_color = grp_color_root_master

    # Set bone color using Blender 5.0 API
    pb.color.palette = 'CUSTOM'
    pb.color.custom.normal = grp_color
    for col_idx in range(0, 3):
        pb.color.custom.select[col_idx] = min(1.0, grp_color[col_idx] + 0.2)
        pb.color.custom.active[col_idx] = min(1.0, grp_color[col_idx] + 0.4)


def update_transform():
    bpy.ops.transform.rotate(
        value=0, 
        orient_axis='Z', 
        orient_type='VIEW', 
        orient_matrix=((0.0, 0.0, 0), (0, 0.0, 0.0), (0.0, 0.0, 0.0)), 
        orient_matrix_type='VIEW', 
        mirror=False
    )