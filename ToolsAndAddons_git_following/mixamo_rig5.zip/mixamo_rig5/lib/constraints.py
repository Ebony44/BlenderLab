import bpy

def add_copy_transf(p_bone, tgt, subtgt):
    """Add a Copy Transforms constraint to a pose bone."""
    cns_transf = p_bone.constraints.get("Copy Transforms")
    if cns_transf is None:
        cns_transf = p_bone.constraints.new("COPY_TRANSFORMS")
        cns_transf.name = "Copy Transforms"
    cns_transf.target = tgt
    cns_transf.subtarget = subtgt
    

def set_constraint_inverse_matrix(cns):
    """Set the inverse matrix of a Child Of constraint."""
    tar_obj = cns.target
    subtarget_pbone = tar_obj.pose.bones.get(cns.subtarget)
    if subtarget_pbone:
        print("reset child of cns", cns.name, cns.subtarget)
        cns.inverse_matrix = subtarget_pbone.bone.matrix_local.to_4x4().inverted()
