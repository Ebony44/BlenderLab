import bpy

def restore_armature_layers(layers_select):
    """Restore the armature bone collections visibility."""
    for c in bpy.context.active_object.data.collections:
        if c.name in layers_select:
            c.is_visible = layers_select[c.name]
        else:
            c.is_visible = False


def enable_all_armature_layers():
    """Enable all bone collections and return the list of each collection's visibility."""
    layers_select = {}
    for c in bpy.context.active_object.data.collections:
        layers_select[c.name] = c.is_visible
        c.is_visible = True

    return layers_select
