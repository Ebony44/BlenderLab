import bpy, os

def delete_object(obj):
    bpy.data.objects.remove(obj, do_unlink=True)
    
    
def duplicate_object():
    try:
        bpy.ops.object.duplicate(linked=False, mode='TRANSLATION')
    except:
        bpy.ops.object.duplicate('TRANSLATION', False)
        
        
def get_object(name):
    return bpy.data.objects.get(name)


def set_active_object(object_name):
    bpy.context.view_layer.objects.active = bpy.data.objects[object_name]
    bpy.data.objects[object_name].select_set(state=True)


def hide_object(obj_to_set):
    obj_to_set.hide_set(True)
    obj_to_set.hide_viewport = True


def is_object_hidden(obj_to_get):
    if obj_to_get.hide_get() == False and obj_to_get.hide_viewport == False:
        return False
    else:
        return True


def search_layer_collection(layer_collection, name):
    """Recursively search for a layer collection by name."""
    if layer_collection.name == name:
        return layer_collection
    for child in layer_collection.children:
        result = search_layer_collection(child, name)
        if result:
            return result
    return None


def append_cs(names=[]):
    """Append custom shapes from the cs.blend file."""
    context = bpy.context
    scene = context.scene
    addon_directory = os.path.dirname(os.path.abspath(__file__))
    filepath = addon_directory + "/cs.blend"

    # Check if cs.blend file exists
    if not os.path.exists(filepath):
        print(f"WARNING: Custom shapes file not found: {filepath}")
        print("Please ensure cs.blend is in the lib/ folder.")
        return False

    try:
        # load the objects data in file
        with bpy.data.libraries.load(filepath, link=False) as (data_from, data_to):
            data_to.objects = [name for name in data_from.objects if name in names]
    except Exception as e:
        print(f"ERROR: Failed to load custom shapes from {filepath}: {e}")
        return False

    # Add the objects in the scene
    for obj in data_to.objects:
        if obj:
            # link in collection
            scene.collection.objects.link(obj)

            cs_grp = bpy.data.objects.get("cs_grp")
            if cs_grp is None:
                cs_grp = bpy.data.objects.new(name="cs_grp", object_data=None)
                bpy.context.collection.objects.link(cs_grp)
                cs_grp.location = [0, 0, 0]
                cs_grp.rotation_euler = [0, 0, 0]
                cs_grp.scale = [1, 1, 1]

            # parent the custom shape
            obj.parent = cs_grp

            # assign to new collection
            assigned_collections = []
            for collec in cs_grp.users_collection:
                try:
                    collec.objects.link(obj)
                    assigned_collections.append(collec)
                except:  # already in collection
                    pass

            if len(assigned_collections):
                # remove previous collections
                for i in obj.users_collection:
                    if i not in assigned_collections:
                        i.objects.unlink(obj)
                # and the scene collection
                try:
                    scene.collection.objects.unlink(obj)
                except:
                    pass
    
    return True